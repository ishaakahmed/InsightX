from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.db import get_db
from app.deps import current_user, owned_dataset
from app.models import Alert, Dataset, Report, User
from app.services import analytics as A
from app.services import reports as svc
from app.services.datasets import dataset_dir

router = APIRouter(tags=["reports"])


class ReportBody(BaseModel):
    title: str = Field("Business performance report", max_length=200)
    date_from: str | None = Field(None, pattern=r"^\d{4}-\d{2}-\d{2}$")
    date_to: str | None = Field(None, pattern=r"^\d{4}-\d{2}-\d{2}$")


def _row(r: Report) -> dict:
    return {"id": r.id, "title": r.title, "date_from": r.date_from, "date_to": r.date_to, "created_at": r.created_at.isoformat(),
            "executive_summary": r.summary.get("executive_summary")}


@router.post("/datasets/{dataset_id}/reports", status_code=201)
def create_report(body: ReportBody, ds: Dataset = Depends(owned_dataset), user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not ds.capabilities.get("kpis", {}).get("available"):
        raise HTTPException(422, ds.capabilities.get("kpis", {}).get("reason") or "Reports need a mapped revenue column.")
    alerts = db.query(Alert).filter(Alert.dataset_id == ds.id, Alert.status == "open").all()
    try:
        summary = svc.build_summary(ds, alerts, body.date_from, body.date_to)
    except A.AnalyticsError as e:
        raise HTTPException(422, str(e))
    rep = Report(user_id=user.id, dataset_id=ds.id, title=body.title, date_from=body.date_from, date_to=body.date_to,
                 summary={"executive_summary": summary["executive_summary"]})
    db.add(rep)
    db.commit()
    folder = dataset_dir(user.id, ds.id) / "reports"
    folder.mkdir(parents=True, exist_ok=True)
    pdf, xlsx = folder / f"{rep.id}.pdf", folder / f"{rep.id}.xlsx"
    svc.write_pdf(pdf, body.title, summary)
    svc.write_xlsx(xlsx, body.title, summary)
    rep.pdf_path, rep.xlsx_path = str(pdf), str(xlsx)
    db.commit()
    return _row(rep)


@router.get("/datasets/{dataset_id}/reports")
def list_reports(ds: Dataset = Depends(owned_dataset), user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(Report).filter(Report.dataset_id == ds.id, Report.user_id == user.id).order_by(Report.created_at.desc()).all()
    return [_row(r) for r in rows]


@router.get("/reports/{rid}/download")
def download(rid: str, format: str = "pdf", user: User = Depends(current_user), db: Session = Depends(get_db)):
    r = db.get(Report, rid)
    if not r or r.user_id != user.id:
        raise HTTPException(404, "Report not found")
    if format not in ("pdf", "xlsx"):
        raise HTTPException(422, "format must be pdf or xlsx")
    path = Path(r.pdf_path if format == "pdf" else r.xlsx_path)
    if not path.exists():
        raise HTTPException(404, "Report file is missing")
    media = "application/pdf" if format == "pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    safe = "".join(ch for ch in r.title if ch.isalnum() or ch in " -_").strip() or "report"
    return FileResponse(path, media_type=media, filename=f"{safe}.{format}")
