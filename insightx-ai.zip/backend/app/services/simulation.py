"""Transparent what-if model: closed-form arithmetic on baseline KPIs with explicit, user-visible assumptions."""
from app.models import Dataset
from app.services import analytics as A
from app.services.util import jsonable


def _run(r0: float, c0: float | None, p: float, v: float, c: float, fixed: float) -> dict:
    r1 = r0 * (1 + p)
    r2 = r1 * (1 + v)
    out = {"revenue": r2}
    if c0 is not None:
        c2 = c0 * (1 + v)
        c3 = c2 * (1 + c)
        out.update(cost=c3 + fixed, profit=r2 - c3 - fixed, margin_pct=(r2 - c3 - fixed) / r2 * 100 if r2 else None)
        out["_steps"] = (r1, r2, c2, c3)
    return out


def simulate(ds: Dataset, assumptions: dict, date_from: str | None = None, date_to: str | None = None) -> dict:
    caps = ds.capabilities.get("simulation", {})
    if not caps.get("available"):
        raise A.AnalyticsError(caps.get("reason") or "Simulation is not available for this dataset.")
    k = A.kpis(ds, date_from, date_to)
    base = k["current"]
    if not base or base.get("revenue") is None:
        raise A.AnalyticsError("No baseline revenue in the selected period.")
    price = float(assumptions.get("price_change_pct", 0)) / 100
    volume = float(assumptions.get("volume_change_pct", 0)) / 100
    cost_chg = float(assumptions.get("unit_cost_change_pct", 0)) / 100
    fixed = float(assumptions.get("fixed_cost_change", 0))
    elasticity = float(assumptions.get("price_elasticity", 0))
    for name, val in (("price", price), ("volume", volume), ("unit cost", cost_chg)):
        if val <= -1:
            raise A.AnalyticsError(f"The {name} change cannot be -100% or lower.")
    demand_effect = elasticity * price
    total_v = (1 + volume) * (1 + demand_effect) - 1
    if total_v <= -1:
        raise A.AnalyticsError("These assumptions eliminate all volume.")
    r0 = float(base["revenue"])
    c0 = None
    if base.get("profit") is not None:
        c0 = r0 - float(base["profit"])
    scen = _run(r0, c0, price, total_v, cost_chg, fixed)
    waterfall = None
    if c0 is not None:
        r1, r2, c2, c3 = scen.pop("_steps")
        p0 = r0 - c0
        waterfall = [
            {"label": "Baseline profit", "value": p0},
            {"label": "Price change", "value": r0 * price},
            {"label": "Volume change", "value": (r2 - c2) - (r1 - c0)},
            {"label": "Unit cost change", "value": -(c3 - c2)},
            {"label": "Fixed cost change", "value": -fixed},
            {"label": "Scenario profit", "value": scen["profit"]},
        ]
    sens = []
    for step in range(-20, 21, 5):
        pp = step / 100
        row = _run(r0, c0, pp, (1 + volume) * (1 + elasticity * pp) - 1, cost_chg, fixed)
        row.pop("_steps", None)
        sens.append({"price_change_pct": step, **row})
    baseline = {"revenue": r0, "cost": c0, "profit": (r0 - c0) if c0 is not None else None,
                "margin_pct": ((r0 - c0) / r0 * 100) if c0 is not None and r0 else None}
    delta = {k2: (scen[k2] - baseline[k2]) if baseline.get(k2) is not None and scen.get(k2) is not None else None for k2 in ("revenue", "cost", "profit")}
    return jsonable({
        "period": k["period"], "baseline": baseline, "scenario": scen, "delta": delta, "waterfall": waterfall,
        "sensitivity": sens,
        "assumptions": {"price_change_pct": price * 100, "volume_change_pct": volume * 100, "unit_cost_change_pct": cost_chg * 100,
                        "fixed_cost_change": fixed, "price_elasticity": elasticity,
                        "effective_volume_change_pct": total_v * 100},
        "model": "scenario revenue = baseline revenue x (1+price) x (1+volume); variable cost scales with volume and unit cost; "
                 "volume also moves by elasticity x price change. All inputs are your assumptions, not predictions.",
        "notes": [] if c0 is not None else ["No cost or profit is mapped, so only revenue effects are shown."],
    })
