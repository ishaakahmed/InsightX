import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../lib/api";
import { useDataset } from "../lib/dataset";
import { ErrorBox, NoDataset, PageHeader, Section, Skeleton } from "../components/ui";

export default function Alerts() {
  const { current } = useDataset(); const qc = useQueryClient(); const id = current?.id;
  const q = useQuery({ queryKey: ["alerts", id], queryFn: () => api<any[]>(`/datasets/${id}/alerts`), enabled: !!id });
  const refresh = useMutation({ mutationFn: () => api(`/datasets/${id}/alerts/refresh`, { method: "POST" }), onSuccess: () => qc.invalidateQueries({ queryKey: ["alerts", id] }) });
  const patch = useMutation({ mutationFn: (v: { id: string; status: string }) => api(`/datasets/${id}/alerts/${v.id}`, { method: "PATCH", body: { status: v.status } }), onSuccess: () => qc.invalidateQueries({ queryKey: ["alerts", id] }) });
  if (!current) return <NoDataset />;
  return (
    <>
      <PageHeader title="Alerts" sub="Rule-based checks on revenue, margin, unusual days, customer concentration and data quality." actions={<button className="btn-ghost" onClick={() => refresh.mutate()} disabled={refresh.isPending}>{refresh.isPending ? "Checking…" : "Re-check now"}</button>} />
      <Section title="Open alerts">{q.isLoading ? <Skeleton h={120} /> : q.isError ? <ErrorBox error={q.error} /> : q.data?.length ? <ul className="divide-y divide-line">{q.data.map((a) => <li key={a.id} className="flex flex-wrap items-start justify-between gap-3 py-3">
        <div className="flex gap-3"><span className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${a.severity === "critical" ? "bg-down" : a.severity === "warning" ? "bg-warn" : "bg-muted"}`} /><div><p className="text-sm">{a.message}</p><p className="mt-0.5 text-xs capitalize text-muted">{a.severity} · {a.rule_type.replace("_", " ")}</p></div></div>
        <div className="flex gap-2"><button className="btn-ghost !py-1" onClick={() => patch.mutate({ id: a.id, status: "acknowledged" })}>Acknowledge</button><button className="btn-ghost !py-1" onClick={() => patch.mutate({ id: a.id, status: "resolved" })}>Resolve</button></div></li>)}</ul>
        : <p className="text-sm text-muted">Nothing needs attention. Alerts are raised when revenue falls 10% or more, margin drops 3 points, an unusual period appears in the latest data, or data quality is low.</p>}</Section>
    </>);
}
