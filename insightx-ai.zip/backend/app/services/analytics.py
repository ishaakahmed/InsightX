"""Deterministic analytics over a dataset's Parquet file, driven by confirmed semantic column roles."""
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

from app.models import Dataset
from app.services.util import jsonable, pct_change

METRICS = ("revenue", "profit", "quantity", "transactions", "customers")


class AnalyticsError(ValueError):
    pass


@lru_cache(maxsize=16)
def _read_cached(path: str, mtime: float) -> pd.DataFrame:
    return pd.read_parquet(path)


def read_frame(ds: Dataset) -> pd.DataFrame:
    p = Path(ds.parquet_path)
    return _read_cached(str(p), p.stat().st_mtime)


def role_map(ds: Dataset) -> dict[str, str]:
    return {c.semantic_role: c.name for c in ds.columns if c.semantic_role != "other"}


def canonical(ds: Dataset) -> pd.DataFrame:
    """Frame with __date/__revenue/__cost/__profit/__quantity/__customer/__product/__region/__category/__order."""
    df = read_frame(ds)
    r = role_map(ds)
    out = pd.DataFrame(index=df.index)
    num = lambda c: pd.to_numeric(df[c], errors="coerce")
    if "date" in r:
        out["__date"] = pd.to_datetime(df[r["date"]], errors="coerce").dt.floor("D")
    if "revenue" in r:
        out["__revenue"] = num(r["revenue"])
    elif "price" in r and "quantity" in r:
        out["__revenue"] = num(r["price"]) * num(r["quantity"])
    if "quantity" in r:
        out["__quantity"] = num(r["quantity"])
    if "cost" in r:
        out["__cost"] = num(r["cost"])
    if "profit" in r:
        out["__profit"] = num(r["profit"])
    elif "__revenue" in out and "__cost" in out:
        out["__profit"] = out["__revenue"] - out["__cost"]
    if "__cost" not in out and "__profit" in out and "__revenue" in out:
        out["__cost"] = out["__revenue"] - out["__profit"]
    for role in ("customer_id", "product", "region", "category", "order_id"):
        if role in r:
            key = {"customer_id": "__customer", "order_id": "__order"}.get(role, f"__{role}")
            out[key] = df[r[role]]
    return out


def _filter(c: pd.DataFrame, date_from: str | None, date_to: str | None) -> pd.DataFrame:
    if "__date" not in c:
        return c
    c = c[c["__date"].notna()]
    if date_from:
        c = c[c["__date"] >= pd.Timestamp(date_from)]
    if date_to:
        c = c[c["__date"] <= pd.Timestamp(date_to)]
    return c


def _metric_series(c: pd.DataFrame, metric: str):
    if metric == "revenue" and "__revenue" in c:
        return c["__revenue"]
    if metric == "profit" and "__profit" in c:
        return c["__profit"]
    if metric == "quantity" and "__quantity" in c:
        return c["__quantity"]
    return None


def _agg(c: pd.DataFrame, metric: str) -> float | None:
    if metric == "transactions":
        return float(c["__order"].nunique()) if "__order" in c else float(len(c))
    if metric == "customers":
        return float(c["__customer"].nunique()) if "__customer" in c else None
    s = _metric_series(c, metric)
    return None if s is None else float(s.sum())


def date_range(ds: Dataset) -> dict:
    c = canonical(ds)
    if "__date" not in c or c["__date"].dropna().empty:
        return {"min": None, "max": None}
    return {"min": c["__date"].min().date().isoformat(), "max": c["__date"].max().date().isoformat()}


def recent_window(ds: Dataset, days: int | None = None) -> tuple[str | None, str | None]:
    """Most recent window (default: 90 days, or half the data span if shorter) so period-over-period comparisons always have a prior period."""
    rng = date_range(ds)
    if not rng["min"]:
        return None, None
    end, start = pd.Timestamp(rng["max"]), pd.Timestamp(rng["min"])
    span = (end - start).days + 1
    days = days or min(90, max(span // 2, 1))
    return (end - pd.Timedelta(days=days - 1)).date().isoformat(), end.date().isoformat()


def kpis(ds: Dataset, date_from: str | None = None, date_to: str | None = None) -> dict:
    full = canonical(ds)
    cur = _filter(full, date_from, date_to)
    prev = None
    period = None
    if "__date" in full and not cur.empty:
        start = cur["__date"].min() if not date_from else pd.Timestamp(date_from)
        end = cur["__date"].max() if not date_to else pd.Timestamp(date_to)
        span = (end - start).days + 1
        pstart, pend = start - pd.Timedelta(days=span), start - pd.Timedelta(days=1)
        prev = _filter(full, pstart.date().isoformat(), pend.date().isoformat())
        period = {"from": start.date().isoformat(), "to": end.date().isoformat(), "days": span,
                  "previous_from": pstart.date().isoformat(), "previous_to": pend.date().isoformat()}

    def block(c: pd.DataFrame | None):
        if c is None or c.empty:
            return None
        rev, prof = _agg(c, "revenue"), _agg(c, "profit")
        tx = _agg(c, "transactions")
        return {
            "revenue": rev, "profit": prof,
            "margin_pct": (prof / rev * 100) if rev and prof is not None else None,
            "quantity": _agg(c, "quantity"), "transactions": tx, "customers": _agg(c, "customers"),
            "avg_order_value": (rev / tx) if rev is not None and tx else None,
        }

    b_cur, b_prev = block(cur), block(prev)
    change = {}
    if b_cur and b_prev:
        for k, v in b_cur.items():
            change[k] = pct_change(v, b_prev.get(k)) if k != "margin_pct" else (
                None if v is None or b_prev.get(k) is None else v - b_prev[k])
    return jsonable({"period": period, "current": b_cur, "previous": b_prev, "change_pct": change,
                     "margin_change_is_points": True, "rows": int(len(cur))})


_FREQ = {"day": "D", "week": "W-MON", "month": "MS", "quarter": "QS", "year": "YS"}


def trend(ds: Dataset, metric: str = "revenue", granularity: str = "month", date_from=None, date_to=None) -> dict:
    if granularity not in _FREQ:
        raise AnalyticsError("granularity must be day, week, month, quarter or year")
    c = _filter(canonical(ds), date_from, date_to)
    if "__date" not in c:
        raise AnalyticsError("A date column is required for trends.")
    if metric not in METRICS:
        raise AnalyticsError("Unknown metric.")
    g = c.set_index("__date")
    if metric == "transactions":
        s = (g["__order"].resample(_FREQ[granularity]).nunique() if "__order" in g else g.iloc[:, 0].resample(_FREQ[granularity]).size())
    elif metric == "customers":
        if "__customer" not in g:
            raise AnalyticsError("A customer column is required.")
        s = g["__customer"].resample(_FREQ[granularity]).nunique()
    else:
        col = {"revenue": "__revenue", "profit": "__profit", "quantity": "__quantity"}[metric]
        if col not in g:
            raise AnalyticsError(f"No column is mapped for {metric}.")
        s = g[col].resample(_FREQ[granularity]).sum(min_count=1)
    s = s.dropna()
    return jsonable({"metric": metric, "granularity": granularity,
                     "points": [{"date": d.date().isoformat(), "value": v} for d, v in s.items()]})


def resolve_dimension(ds: Dataset, dimension: str, c: pd.DataFrame) -> pd.Series:
    key = {"customer": "__customer", "customer_id": "__customer"}.get(dimension, f"__{dimension}")
    if key in c:
        return c[key]
    df = read_frame(ds)
    if dimension in df.columns:  # any real column can be a dimension
        return df.loc[c.index, dimension]
    raise AnalyticsError(f"Unknown dimension '{dimension}'.")


def breakdown(ds: Dataset, dimension: str, metric: str = "revenue", top: int = 10, date_from=None, date_to=None) -> dict:
    c = _filter(canonical(ds), date_from, date_to)
    dim = resolve_dimension(ds, dimension, c)
    c = c.assign(__dim=dim.astype("string").fillna("(missing)"))
    if metric not in METRICS:
        raise AnalyticsError("Unknown metric.")
    if metric == "transactions":
        agg = c.groupby("__dim").apply(lambda x: x["__order"].nunique() if "__order" in x else len(x), include_groups=False)
    elif metric == "customers":
        agg = c.groupby("__dim")["__customer"].nunique()
    else:
        col = {"revenue": "__revenue", "profit": "__profit", "quantity": "__quantity"}[metric]
        if col not in c:
            raise AnalyticsError(f"No column is mapped for {metric}.")
        agg = c.groupby("__dim")[col].sum()
    agg = agg.sort_values(ascending=False)
    total = float(agg.sum())
    rows = []
    for k, v in agg.head(top).items():
        row = {"name": str(k), "value": float(v), "share_pct": float(v / total * 100) if total else None}
        if metric == "revenue" and "__profit" in c:
            sub = c[c["__dim"] == k]
            rev, prof = sub["__revenue"].sum(), sub["__profit"].sum()
            row["profit"], row["margin_pct"] = float(prof), float(prof / rev * 100) if rev else None
        rows.append(row)
    other = float(agg.iloc[top:].sum()) if len(agg) > top else 0.0
    return jsonable({"dimension": dimension, "metric": metric, "total": total, "rows": rows,
                     "other_value": other, "distinct": int(len(agg))})


def correlation(ds: Dataset, max_cols: int = 15) -> dict:
    df = read_frame(ds)
    num = df.select_dtypes(include="number")
    num = num.loc[:, num.nunique() > 1]
    if num.shape[1] < 2:
        return {"columns": [], "matrix": [], "top_pairs": []}
    num = num[num.var().sort_values(ascending=False).head(max_cols).index]
    m = num.corr(numeric_only=True)
    cols = list(m.columns)
    pairs = [{"a": a, "b": b, "r": float(m.loc[a, b])} for i, a in enumerate(cols) for b in cols[i + 1:] if pd.notna(m.loc[a, b])]
    pairs.sort(key=lambda p: -abs(p["r"]))
    return jsonable({"columns": cols, "matrix": m.values.tolist(), "top_pairs": pairs[:8],
                     "note": "Correlation does not imply causation."})


def customers(ds: Dataset, date_to=None) -> dict:
    c = canonical(ds)
    if "__customer" not in c or "__revenue" not in c:
        raise AnalyticsError("Customer analytics needs customer and revenue columns.")
    c = c[c["__customer"].notna()]
    per = c.groupby("__customer")["__revenue"].agg(["sum", "count"]).sort_values("sum", ascending=False)
    total = float(per["sum"].sum())
    n = len(per)
    top10 = per.head(max(1, int(round(n * 0.1))))
    out = {
        "customer_count": n, "avg_revenue_per_customer": float(per["sum"].mean()),
        "top_decile_share_pct": float(top10["sum"].sum() / total * 100) if total else None,
        "repeat_customer_pct": float((per["count"] > 1).mean() * 100),
        "top_customers": [{"name": str(k), "revenue": float(v["sum"]), "transactions": int(v["count"])} for k, v in per.head(10).iterrows()],
    }
    return jsonable(out)


def segmentation(ds: Dataset, k_max: int = 6) -> dict:
    """RFM + KMeans. k chosen by silhouette. Returns segment profiles; no invented labels beyond RFM descriptors."""
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score
    from sklearn.preprocessing import StandardScaler

    c = canonical(ds)
    for need in ("__customer", "__date", "__revenue"):
        if need not in c:
            raise AnalyticsError("Segmentation needs customer, date and revenue columns.")
    c = c.dropna(subset=["__customer", "__date", "__revenue"])
    snap = c["__date"].max() + pd.Timedelta(days=1)
    g = c.groupby("__customer").agg(recency=("__date", lambda d: (snap - d.max()).days), frequency=("__date", "count"), monetary=("__revenue", "sum"))
    if len(g) < 30:
        raise AnalyticsError(f"Only {len(g)} customers; at least 30 are needed for segmentation.")
    X = StandardScaler().fit_transform(np.log1p(g[["recency", "frequency", "monetary"]].clip(lower=0)))
    best = None
    for k in range(2, min(k_max, len(g) // 10) + 1):
        km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
        sil = silhouette_score(X, km.labels_, sample_size=min(5000, len(g)), random_state=42)
        if best is None or sil > best[0]:
            best = (sil, k, km.labels_)
    sil, k, labels = best
    g["segment"] = labels
    total_rev = g["monetary"].sum()
    segs = []
    for s, sub in g.groupby("segment"):
        segs.append({"segment": int(s), "customers": int(len(sub)), "share_customers_pct": float(len(sub) / len(g) * 100),
                     "avg_recency_days": float(sub["recency"].mean()), "avg_frequency": float(sub["frequency"].mean()),
                     "avg_monetary": float(sub["monetary"].mean()), "revenue_share_pct": float(sub["monetary"].sum() / total_rev * 100)})
    segs.sort(key=lambda x: -x["revenue_share_pct"])
    for i, s in enumerate(segs):
        s["name"] = f"Segment {i + 1}"
        s["descriptor"] = ("high value" if s["revenue_share_pct"] > 100 / k else "lower value") + (", recent" if s["avg_recency_days"] < g["recency"].mean() else ", lapsing")
    return jsonable({"k": k, "silhouette": float(sil), "segments": segs, "customers_scored": int(len(g)),
                     "method": "RFM features (log-scaled) clustered with KMeans; k selected by silhouette score."})


def root_cause(ds: Dataset, date_from: str | None = None, date_to: str | None = None, metric: str = "revenue") -> dict:
    """Decompose the change in a metric vs the previous equal-length period into dimension contributions and price/volume."""
    if not date_from and not date_to:
        date_from, date_to = recent_window(ds)
    k = kpis(ds, date_from, date_to)
    if not k["period"] or not k["previous"]:
        raise AnalyticsError("There is no earlier period with data to compare against. Choose a range that starts after the beginning of your data.")
    p = k["period"]
    c = canonical(ds)
    cur = _filter(c, p["from"], p["to"])
    prev = _filter(c, p["previous_from"], p["previous_to"])
    col = {"revenue": "__revenue", "profit": "__profit", "quantity": "__quantity"}.get(metric)
    if col not in c:
        raise AnalyticsError(f"No column mapped for {metric}.")
    delta = float(cur[col].sum() - prev[col].sum())
    drivers = []
    for dim in ("product", "region", "category", "customer"):
        key = {"customer": "__customer"}.get(dim, f"__{dim}")
        if key not in c:
            continue
        a = cur.groupby(key)[col].sum()
        b = prev.groupby(key)[col].sum()
        diff = a.sub(b, fill_value=0).sort_values()
        for name, v in list(diff.head(3).items()) + list(diff.tail(3).items()):
            drivers.append({"dimension": dim, "name": str(name), "change": float(v),
                            "share_of_total_change_pct": float(v / delta * 100) if delta else None})
    drivers.sort(key=lambda d: abs(d["change"]), reverse=True)
    pv = None
    if metric == "revenue" and "__quantity" in c and cur["__quantity"].sum() and prev["__quantity"].sum():
        q0, q1 = prev["__quantity"].sum(), cur["__quantity"].sum()
        p0, p1 = prev[col].sum() / q0, cur[col].sum() / q1
        pv = {"volume_effect": float((q1 - q0) * p0), "price_mix_effect": float((p1 - p0) * q1),
              "avg_unit_value_prev": float(p0), "avg_unit_value_cur": float(p1)}
    return jsonable({"metric": metric, "period": p, "current_total": float(cur[col].sum()), "previous_total": float(prev[col].sum()),
                     "change": delta, "change_pct": pct_change(float(cur[col].sum()), float(prev[col].sum())),
                     "top_drivers": drivers[:8], "price_volume": pv})
