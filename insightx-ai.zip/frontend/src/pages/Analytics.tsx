import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "../lib/api";
import { useDataset } from "../lib/dataset";
import { useRange } from "../lib/range";
import { compact, num, pct } from "../lib/format";
import { Chart } from "../components/Chart";
import { Delta, ErrorBox, NoDataset, PageHeader, Section, Skeleton, Tabs, Unavailable } from "../components/ui";

const METRICS = [["revenue", "Revenue"], ["profit", "Profit"], ["quantity", "Quantity"], ["transactions", "Transactions"], ["customers", "Customers"]];

function Trend({ id, r }: { id: string; r: ReturnType<typeof useRange> }) {
  const [metric, setMetric] = useState("revenue"); const [g, setG] = useState("month");
  const q = useQuery({ queryKey: ["trend", id, metric, g, r.from, r.to], queryFn: () => api(`/datasets/${id}/analytics/trend`, { params: { metric, granularity: g, date_from: r.from, date_to: r.to } }) });
  const opt = (b: any) => ({ ...b, xAxis: { ...b.xAxis, type: "category", data: q.data.points.map((p: any) => p.date) }, yAxis: { ...b.yAxis, type: "value", axisLabel: { ...b.yAxis.axisLabel, formatter: (v: number) => compact(v) } }, dataZoom: [{ type: "inside" }], series: [{ type: g === "day" ? "line" : "bar", showSymbol: false, barMaxWidth: 22, data: q.data.points.map((p: any) => p.value), itemStyle: { borderRadius: [3, 3, 0, 0] } }] });
  return <Section title="Trend" right={<div className="flex gap-2"><select aria-label="Metric" className="input !w-auto !py-1" value={metric} onChange={(e) => setMetric(e.target.value)}>{METRICS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
    <select aria-label="Granularity" className="input !w-auto !py-1" value={g} onChange={(e) => setG(e.target.value)}>{["day", "week", "month", "quarter", "year"].map((x) => <option key={x}>{x}</option>)}</select></div>}>
    {q.isLoading ? <Skeleton h={300} /> : q.isError ? <ErrorBox error={q.error} /> : q.data.points.length ? <Chart height={300} label={`${metric} by ${g}`} option={opt} /> : <p className="text-sm text-muted">No data in range.</p>}</Section>;
}

function Breakdown({ id, r, dims }: { id: string; r: ReturnType<typeof useRange>; dims: string[] }) {
  const [dim, setDim] = useState(dims[0]); const [metric, setMetric] = useState("revenue");
  const q = useQuery({ queryKey: ["bd", id, dim, metric, r.from, r.to], queryFn: () => api(`/datasets/${id}/analytics/breakdown`, { params: { dimension: dim, metric, top: 15, date_from: r.from, date_to: r.to } }) });
  return <Section title="Breakdown" sub={q.data ? `${num(q.data.distinct)} distinct values` : undefined} right={<div className="flex gap-2"><select aria-label="Dimension" className="input !w-auto !py-1" value={dim} onChange={(e) => setDim(e.target.value)}>{dims.map((d) => <option key={d}>{d}</option>)}</select>
    <select aria-label="Metric" className="input !w-auto !py-1" value={metric} onChange={(e) => setMetric(e.target.value)}>{METRICS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></div>}>
    {q.isLoading ? <Skeleton h={260} /> : q.isError ? <ErrorBox error={q.error} /> : <div className="overflow-x-auto"><table className="w-full"><thead><tr className="border-b border-line"><th className="th">{dim}</th><th className="th text-right">{metric}</th><th className="th text-right">Share</th>{q.data.rows[0]?.margin_pct !== undefined && <th className="th text-right">Margin</th>}<th className="th w-40" /></tr></thead>
      <tbody>{q.data.rows.map((x: any) => <tr key={x.name} className="border-b border-line last:border-0"><td className="td font-medium">{x.name}</td><td className="td num text-right">{num(x.value)}</td><td className="td num text-right">{pct(x.share_pct)}</td>{x.margin_pct !== undefined && <td className="td num text-right">{pct(x.margin_pct)}</td>}
        <td className="td"><div className="h-1.5 rounded bg-sunken"><div className="h-1.5 rounded bg-accent" style={{ width: `${Math.min(100, x.share_pct ?? 0)}%` }} /></div></td></tr>)}</tbody></table></div>}</Section>;
}

function Explain({ id, r }: { id: string; r: ReturnType<typeof useRange> }) {
  const [metric, setMetric] = useState("revenue");
  const q = useQuery({ queryKey: ["explain", id, metric, r.from, r.to], queryFn: () => api(`/datasets/${id}/analytics/explain`, { params: { metric, date_from: r.from, date_to: r.to } }), retry: false });
  return <Section title="What changed?" sub="Contribution to the change versus the previous period of equal length" right={<select aria-label="Metric" className="input !w-auto !py-1" value={metric} onChange={(e) => setMetric(e.target.value)}><option value="revenue">Revenue</option><option value="profit">Profit</option><option value="quantity">Quantity</option></select>}>
    {q.isLoading ? <Skeleton h={160} /> : q.isError ? <p className="text-sm text-muted">{(q.error as Error).message}</p> : <div>
      <p className="text-sm">{metric} moved <span className="num font-semibold">{num(q.data.change)}</span> ({pct(q.data.change_pct, 1, true)}) from {num(q.data.previous_total)} to {num(q.data.current_total)}.</p>
      {q.data.price_volume && <p className="mt-1 text-sm text-muted">Volume effect <span className="num">{num(q.data.price_volume.volume_effect)}</span> · price and mix effect <span className="num">{num(q.data.price_volume.price_mix_effect)}</span></p>}
      <table className="mt-3 w-full"><tbody>{q.data.top_drivers.map((d: any, i: number) => <tr key={i} className="border-t border-line"><td className="td capitalize text-muted">{d.dimension}</td><td className="td font-medium">{d.name}</td><td className={`td num text-right ${d.change < 0 ? "text-down" : "text-up"}`}>{d.change > 0 ? "+" : ""}{num(d.change)}</td></tr>)}</tbody></table></div>}</Section>;
}

function Correlation({ id }: { id: string }) {
  const q = useQuery({ queryKey: ["corr", id], queryFn: () => api(`/datasets/${id}/analytics/correlation`) });
  if (q.isLoading) return <Skeleton h={300} />; if (q.isError) return <ErrorBox error={q.error} />;
  if (!q.data.columns.length) return <p className="text-sm text-muted">At least two numeric columns are needed.</p>;
  const cols: string[] = q.data.columns;
  const opt = (b: any) => ({ ...b, grid: { left: 8, right: 8, top: 8, bottom: 56, containLabel: true }, tooltip: { ...b.tooltip, trigger: "item", formatter: (p: any) => `${cols[p.value[1]]} × ${cols[p.value[0]]}: ${p.value[2].toFixed(2)}` },
    xAxis: { type: "category", data: cols, axisLabel: { ...b.xAxis.axisLabel, rotate: 40 }, splitArea: { show: false }, axisLine: b.xAxis.axisLine }, yAxis: { type: "category", data: cols, inverse: true, axisLabel: b.yAxis.axisLabel },
    visualMap: { min: -1, max: 1, show: false, inRange: { color: ["#C2371F", "#F4F5F8", "#2F3FD0"] } },
    series: [{ type: "heatmap", data: q.data.matrix.flatMap((row: number[], i: number) => row.map((v, j) => [j, i, v])), label: { show: cols.length <= 8, formatter: (p: any) => p.value[2].toFixed(2), fontSize: 10 } }] });
  return <div className="grid gap-4 lg:grid-cols-3"><Section className="lg:col-span-2" title="Correlation matrix" sub="Pearson, numeric columns"><Chart height={360} label="Correlation heatmap" option={opt} /></Section>
    <Section title="Strongest relationships"><ul className="space-y-2 text-sm">{q.data.top_pairs.map((p: any, i: number) => <li key={i} className="flex justify-between gap-3"><span>{p.a} × {p.b}</span><span className={`num font-medium ${p.r < 0 ? "text-down" : "text-up"}`}>{p.r.toFixed(2)}</span></li>)}</ul><p className="mt-3 text-xs text-muted">{q.data.note}</p></Section></div>;
}

function Customers({ id }: { id: string }) {
  const q = useQuery({ queryKey: ["customers", id], queryFn: () => api(`/datasets/${id}/analytics/customers`) });
  if (q.isLoading) return <Skeleton h={200} />; if (q.isError) return <ErrorBox error={q.error} />;
  const d = q.data;
  return <div className="grid gap-4 lg:grid-cols-3"><Section title="Customer base"><dl className="space-y-3 text-sm">{[["Customers", num(d.customer_count)], ["Avg revenue per customer", num(d.avg_revenue_per_customer)], ["Repeat customers", pct(d.repeat_customer_pct)], ["Revenue from top 10%", pct(d.top_decile_share_pct)]].map(([k, v]) => <div key={k} className="flex justify-between"><dt className="text-muted">{k}</dt><dd className="num font-medium">{v}</dd></div>)}</dl></Section>
    <Section className="lg:col-span-2" title="Top customers"><table className="w-full"><thead><tr className="border-b border-line"><th className="th">Customer</th><th className="th text-right">Revenue</th><th className="th text-right">Transactions</th></tr></thead><tbody>{d.top_customers.map((c: any) => <tr key={c.name} className="border-b border-line last:border-0"><td className="td font-medium">{c.name}</td><td className="td num text-right">{num(c.revenue)}</td><td className="td num text-right">{num(c.transactions)}</td></tr>)}</tbody></table></Section></div>;
}

export default function Analytics() {
  const { current, detail } = useDataset(); const r = useRange(); const [tab, setTab] = useState("Overview");
  if (!current) return <NoDataset />; if (!detail) return <Skeleton h={200} />;
  const caps = detail.capabilities; if (!caps.kpis.available) return <><PageHeader title="Analytics" /><Unavailable reason={caps.kpis.reason} /></>;
  const dims = detail.columns_detail.filter((c) => ["product", "region", "category", "customer_id"].includes(c.role) || (c.type === "category" && c.role === "other" && c.stats.unique_count <= 60)).map((c) => (c.role === "other" ? c.name : c.role === "customer_id" ? "customer" : c.role));
  return <><PageHeader title="Analytics" sub="Exploratory analysis calculated from your dataset" actions={r.ui} />
    <Tabs tabs={["Overview", "Customers", "Correlations"]} value={tab} onChange={setTab} />
    {tab === "Overview" && <div className="space-y-4">{caps.trends.available && <Trend id={current.id} r={r} />}{dims.length > 0 && caps.breakdowns.available && <Breakdown id={current.id} r={r} dims={dims} />}<Explain id={current.id} r={r} /></div>}
    {tab === "Customers" && (caps.customers.available ? <Customers id={current.id} /> : <Unavailable reason={caps.customers.reason} />)}
    {tab === "Correlations" && <Correlation id={current.id} />}</>;
}
