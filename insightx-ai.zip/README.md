# InsightX AI

AI-assisted business intelligence: upload sales data, get validated KPIs, backtested forecasts, anomaly detection, customer segments, what-if simulation, PDF/Excel reports, and an analyst that answers only from computed results.

## Run it (development)

```bash
# Backend  (Python 3.12)
cd backend && pip install -r requirements.txt
cp .env.example .env
python scripts/generate_sample_data.py          # creates synthetic demo data in sample_data/
uvicorn app.main:app --reload --port 8000       # API docs: http://localhost:8000/api/docs

# Frontend (Node 22)
cd frontend && npm install && npm run dev       # http://localhost:5173 (proxies /api to :8000)
```
Sign up in the UI, upload `backend/sample_data/retail_sales.csv`, confirm the column mapping.

Production-style: `POSTGRES_PASSWORD=... SECRET_KEY=... docker compose up --build` (UI on :8080).
Tests: `cd backend && python -m pytest -q` (59 tests).  Optional AI: set `ANTHROPIC_API_KEY`.

## Design decisions
- **Modular monolith** (FastAPI): routers -> services; no router touches analytics internals, no service imports a router.
- **Parquet + DuckDB for data, SQL database for metadata.** No table per upload. SQLite by default, PostgreSQL via `DATABASE_URL`.
- **Column roles drive everything.** Uploads are mapped to meanings (date, revenue, cost, ...). Each feature reports whether the dataset can support it, and why not.
- **The model never computes numbers.** The analyst calls deterministic tools and shows its evidence. With no API key it runs a built-in router over the same tools.
- **LLM SQL is sandboxed:** sqlglot allow-list (single SELECT on one table, no functions that touch files/network), in-memory DuckDB with external access disabled, 10 s timeout, 500-row cap.
- **Forecasts are scored honestly:** rolling-origin backtests, all models on the same folds, naive baselines always included, and the UI states when nothing beats them.

## Status
| Area | State |
|---|---|
| Auth (Argon2, JWT + rotating httpOnly refresh, lockout, CSRF header, account deletion) | Done, tested |
| Upload, validation, type inference, role mapping, profiling, quality score, replayable cleaning | Done, tested |
| Dashboard, analytics (trend, breakdown, root-cause, correlation, customers) | Done, tested |
| Forecasting, anomalies, RFM segmentation | Done, tested against known injected events |
| What-if simulator (price/volume/cost/elasticity, waterfall, sensitivity) | Done, math tested |
| AI analyst (tool-calling, evidence, history) | Offline mode tested; **LLM mode written but not tested against the live API** |
| PDF + Excel reports, alerts | Done, tested |
| Churn prediction | **Not built** |
| RAG / knowledge base, LangGraph report pipeline | **Not built** (deliberately deferred) |
| Dataset comparison UI | API only |
| Alembic migrations | Not set up (tables created at startup) |
| Background job queue | Not needed yet; processing is synchronous (<= 50 MB) |
| Browser end-to-end tests | Not written; UI type-checks and builds but was not exercised in a browser |
| PostgreSQL | Compose file provided; **not run** here |
