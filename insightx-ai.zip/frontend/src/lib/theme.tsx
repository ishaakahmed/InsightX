import { createContext, useContext, useEffect, useState, ReactNode } from "react";
type Theme = "light" | "dark";
const Ctx = createContext<{ theme: Theme; toggle: () => void }>({ theme: "light", toggle: () => {} });
export const useTheme = () => useContext(Ctx);
export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>((document.documentElement.dataset.theme as Theme) || "light");
  useEffect(() => { document.documentElement.dataset.theme = theme; try { localStorage.setItem("ix-theme", theme); } catch {} }, [theme]);
  return <Ctx.Provider value={{ theme, toggle: () => setTheme((t) => (t === "light" ? "dark" : "light")) }}>{children}</Ctx.Provider>;
}
export const cssVar = (name: string, alpha = 1) => `rgb(${getComputedStyle(document.documentElement).getPropertyValue(name).trim().split(" ").join(",")}${alpha < 1 ? "," + alpha : ""})`.replace("rgb(", alpha < 1 ? "rgba(" : "rgb(");
