"""Deterministic report generation (PDF + Excel). Narrative text is templated from computed numbers."""
import io
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from app.models import Alert, Dataset
from app.services import analytics as A
from app.services import forecasting as F

INK, ACCENT = "#1B2A41", "#3347D4"


def _n(x, d=0):
    return "n/a" if x is None else f"{x:,.{d}f}"


def _safe(v):
    """Neutralise spreadsheet formula injection in user-originated strings."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + v
    return v


def build_summary(ds: Dataset, alerts: list[Alert], date_from, date_to) -> dict:
    k = A.kpis(ds, date_from, date_to)
    s: dict = {"kpis": k, "dataset": ds.name, "quality_score": ds.quality_score, "alerts": [{"severity": a.severity, "message": a.message} for a in alerts]}
    caps = ds.capabilities
    if caps.get("trends", {}).get("available"):
        s["trend"] = A.trend(ds, "revenue", "month", date_from, date_to)
        if caps.get("profit", {}).get("available"):
            s["profit_trend"] = A.trend(ds, "profit", "month", date_from, date_to)
    s["breakdowns"] = {}
    if caps.get("breakdowns", {}).get("available"):
        for dim in ("product", "region", "category"):
            if any(c.semantic_role == dim for c in ds.columns):
                s["breakdowns"][dim] = A.breakdown(ds, dim, "revenue", 8, date_from, date_to)
    if caps.get("forecast", {}).get("available"):
        try:
            f = F.forecast(ds, "revenue", 6)
            s["forecast"] = {k2: f[k2] for k2 in ("model", "verdict", "metrics", "forecast", "total_forecast", "granularity", "horizon", "backtest")}
        except A.AnalyticsError:
            pass
    c, ch = k.get("current"), k.get("change_pct", {})
    parts = []
    if c:
        parts.append(f"Between {k['period']['from']} and {k['period']['to']}, revenue was {_n(c['revenue'])}"
                     + (f" ({ch['revenue']:+.1f}% versus the previous period)" if ch.get("revenue") is not None else "") + ".")
        if c.get("profit") is not None:
            parts.append(f"Profit was {_n(c['profit'])} at a {c['margin_pct']:.1f}% margin.")
        for dim, b in s["breakdowns"].items():
            if b["rows"]:
                t = b["rows"][0]
                parts.append(f"The leading {dim} was {t['name']} with {t['share_pct']:.1f}% of revenue.")
    if "forecast" in s:
        parts.append(f"The selected model ({s['forecast']['model']}) projects {_n(s['forecast']['total_forecast'])} over the next {s['forecast']['horizon']} {s['forecast']['granularity']}s. {s['forecast']['verdict']}")
    parts.append(f"{len(alerts)} open alert(s); data quality score {ds.quality_score:.0f}/100.")
    s["executive_summary"] = " ".join(parts)
    return s


def write_xlsx(path: Path, title: str, s: dict) -> None:
    wb = Workbook()
    head = Font(bold=True, color="FFFFFF")
    fill = PatternFill("solid", fgColor=INK.lstrip("#"))

    def sheet(name, rows, header):
        ws = wb.create_sheet(name)
        ws.append(header)
        for c in ws[1]:
            c.font, c.fill = head, fill
        for r in rows:
            ws.append([_safe(v) for v in r])
        for i, col in enumerate(ws.columns):
            ws.column_dimensions[col[0].column_letter].width = min(max(len(str(c.value or "")) for c in col) + 3, 48)
        return ws

    ws = wb.active
    ws.title = "Summary"
    ws["A1"], ws["A1"].font = title, Font(bold=True, size=14)
    ws["A3"] = _safe(s["executive_summary"])
    ws["A3"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.column_dimensions["A"].width = 110
    ws.row_dimensions[3].height = 120
    c = s["kpis"].get("current") or {}
    prev = s["kpis"].get("previous") or {}
    sheet("KPIs", [[k, c.get(k), prev.get(k), s["kpis"].get("change_pct", {}).get(k)] for k in c], ["Metric", "Current", "Previous", "Change %"])
    if "trend" in s:
        sheet("Revenue trend", [[p["date"], p["value"]] for p in s["trend"]["points"]], ["Month", "Revenue"])
    for dim, b in s["breakdowns"].items():
        sheet(f"By {dim}", [[r["name"], r["value"], r["share_pct"], r.get("profit"), r.get("margin_pct")] for r in b["rows"]], [dim.title(), "Revenue", "Share %", "Profit", "Margin %"])
    if "forecast" in s:
        sheet("Forecast", [[p["date"], p["value"], p["lower"], p["upper"]] for p in s["forecast"]["forecast"]], ["Period", "Forecast", "Lower (80%)", "Upper (80%)"])
    sheet("Alerts", [[a["severity"], a["message"]] for a in s["alerts"]], ["Severity", "Message"])
    wb.save(path)


def _chart(points, title, forecast=None):
    fig, ax = plt.subplots(figsize=(7.2, 2.8), dpi=150)
    ax.plot([p["date"] for p in points], [p["value"] for p in points], color=ACCENT, lw=1.6)
    if forecast:
        ax.plot([p["date"] for p in forecast], [p["value"] for p in forecast], color="#D98A1F", lw=1.6, ls="--")
        ax.fill_between([p["date"] for p in forecast], [p["lower"] for p in forecast], [p["upper"] for p in forecast], color="#D98A1F", alpha=0.18, lw=0)
    ax.set_title(title, fontsize=9, loc="left", color=INK)
    n = len(points) + (len(forecast) if forecast else 0)
    ax.set_xticks([p["date"] for p in (points + (forecast or []))][:: max(1, n // 8)])
    ax.tick_params(labelsize=7, colors="#555")
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)
    return buf


def write_pdf(path: Path, title: str, s: dict) -> None:
    ss = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=ss["Title"], textColor=colors.HexColor(INK), alignment=0, fontSize=20)
    h2 = ParagraphStyle("h2", parent=ss["Heading2"], textColor=colors.HexColor(INK), fontSize=12, spaceBefore=10)
    body = ParagraphStyle("b", parent=ss["BodyText"], fontSize=9.5, leading=13.5)
    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=1.8 * cm, rightMargin=1.8 * cm, topMargin=1.6 * cm, bottomMargin=1.6 * cm, title=title)
    el = [Paragraph(title, h1), Paragraph(f"Dataset: {s['dataset']}", body), Spacer(1, 6), Paragraph("Executive summary", h2), Paragraph(s["executive_summary"], body)]
    c = s["kpis"].get("current")
    if c:
        ch = s["kpis"].get("change_pct", {})
        rows = [["Metric", "Current", "Change vs previous"]]
        for k, label in (("revenue", "Revenue"), ("profit", "Profit"), ("margin_pct", "Margin %"), ("transactions", "Transactions"), ("customers", "Customers"), ("avg_order_value", "Avg order value")):
            if c.get(k) is not None:
                v = ch.get(k)
                rows.append([label, _n(c[k], 1 if k == "margin_pct" else 0), "n/a" if v is None else (f"{v:+.1f} pts" if k == "margin_pct" else f"{v:+.1f}%")])
        t = Table(rows, hAlign="LEFT", colWidths=[5 * cm, 4 * cm, 5 * cm])
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(INK)), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, -1), 9),
                               ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F4F8")]), ("ALIGN", (1, 0), (-1, -1), "RIGHT")]))
        el += [Paragraph("Key performance indicators", h2), t]
    if "trend" in s and s["trend"]["points"]:
        el += [Paragraph("Revenue trend", h2), Image(_chart(s["trend"]["points"], "Monthly revenue"), width=17 * cm, height=6.6 * cm)]
    if "forecast" in s:
        hist = s["trend"]["points"][-24:] if "trend" in s else []
        el += [Paragraph("Forecast", h2), Image(_chart(hist, f"Forecast ({s['forecast']['model']}, 80% interval)", s["forecast"]["forecast"]), width=17 * cm, height=6.6 * cm)]
        m = s["forecast"]["metrics"]["selected"]
        el.append(Paragraph(f"Backtest error: MAE {_n(m['mae'])}, RMSE {_n(m['rmse'])}, sMAPE {m['smape']:.1f}%. {s['forecast']['verdict']}", body))
    for dim, b in s["breakdowns"].items():
        rows = [[dim.title(), "Revenue", "Share %"]] + [[r["name"][:40], _n(r["value"]), f"{r['share_pct']:.1f}"] for r in b["rows"]]
        t = Table(rows, hAlign="LEFT", colWidths=[8 * cm, 4 * cm, 3 * cm])
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(INK)), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, -1), 8.5), ("ALIGN", (1, 0), (-1, -1), "RIGHT")]))
        el += [Paragraph(f"Revenue by {dim}", h2), t]
    if s["alerts"]:
        el.append(Paragraph("Alerts", h2))
        el += [Paragraph(f"[{a['severity']}] {a['message']}", body) for a in s["alerts"]]
    doc.build(el)
