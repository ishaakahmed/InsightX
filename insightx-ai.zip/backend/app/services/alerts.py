from sqlalchemy.orm import Session

from app.models import Alert, Dataset
from app.services import analytics as A
from app.services import forecasting as F


def generate_alerts(db: Session, ds: Dataset) -> list[Alert]:
    """Rule-based alerts computed from real data. Replaces previously open alerts for this dataset."""
    db.query(Alert).filter(Alert.dataset_id == ds.id, Alert.status == "open").delete()
    found: list[tuple[str, str, str, dict]] = []
    if ds.capabilities.get("kpis", {}).get("available") and ds.capabilities.get("trends", {}).get("available"):
        try:
            wf, wt = A.recent_window(ds)
            k = A.kpis(ds, wf, wt)
            ch = k["change_pct"]
            if ch.get("revenue") is not None and ch["revenue"] <= -10:
                sev = "critical" if ch["revenue"] <= -25 else "warning"
                found.append(("revenue_decline", sev, f"Revenue fell {abs(ch['revenue']):.1f}% in {k['period']['from']} to {k['period']['to']} versus the previous period of equal length. Check for seasonality before acting.", {"period": k["period"], "change_pct": ch["revenue"]}))
            if ch.get("margin_pct") is not None and ch["margin_pct"] <= -3:
                found.append(("margin_drop", "warning", f"Profit margin dropped {abs(ch['margin_pct']):.1f} percentage points versus the previous period.", {"period": k["period"], "points": ch["margin_pct"]}))
        except A.AnalyticsError:
            pass
        try:
            an = F.anomalies(ds, "revenue", "week") if ds.row_count >= 200 else F.anomalies(ds, "revenue", "day")
            last = [x for x in an["series"][-3:]]
            recent_dates = {p["date"] for p in last}
            recent = [a for a in an["anomalies"] if a["date"] in recent_dates]
            for a in recent[:3]:
                found.append(("anomaly", "warning" if a["severity"] == "medium" else "critical",
                              f"Unusual revenue {a['direction']} on {a['date']}: {a['value']:,.0f} versus about {a['expected']:,.0f} expected.", a))
        except A.AnalyticsError:
            pass
    if ds.capabilities.get("customers", {}).get("available"):
        try:
            c = A.customers(ds)
            if c["top_decile_share_pct"] and c["top_decile_share_pct"] >= 70:
                found.append(("concentration", "info", f"The top 10% of customers generate {c['top_decile_share_pct']:.0f}% of revenue.", {"share_pct": c["top_decile_share_pct"]}))
        except A.AnalyticsError:
            pass
    if ds.quality_score < 70:
        found.append(("data_quality", "warning", f"Data quality score is {ds.quality_score:.0f}/100. Analyses may be unreliable until issues are fixed.", {"score": ds.quality_score}))
    alerts = [Alert(dataset_id=ds.id, rule_type=r, severity=s, message=m, evidence=e) for r, s, m, e in found]
    db.add_all(alerts)
    db.commit()
    return alerts
