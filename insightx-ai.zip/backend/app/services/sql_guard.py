"""Safe execution of LLM- or user-authored SQL: parse, allow-list, sandbox, limit, time-box."""
import threading

import duckdb
import pandas as pd
import sqlglot
from sqlglot import exp

MAX_ROWS = 500
TIMEOUT_S = 10
BLOCKED_FUNC_PARTS = ("read_", "glob", "httpfs", "install", "load", "getenv", "current_setting", "duckdb_", "pragma",
                      "write_", "copy", "export", "attach", "sniff", "parquet_", "json_", "query", "system", "python")
TABLE = "data"


class UnsafeSQL(ValueError):
    pass


def validate_sql(sql: str) -> str:
    """Returns normalized single SELECT or raises UnsafeSQL."""
    if not sql or len(sql) > 4000:
        raise UnsafeSQL("Query is empty or too long.")
    try:
        stmts = [s for s in sqlglot.parse(sql, read="duckdb") if s is not None]
    except sqlglot.errors.ParseError as e:
        raise UnsafeSQL("The query could not be parsed.") from e
    if len(stmts) != 1:
        raise UnsafeSQL("Exactly one statement is allowed.")
    tree = stmts[0]
    if not isinstance(tree, (exp.Select, exp.Union, exp.Subquery)) or tree.find(exp.Command):
        raise UnsafeSQL("Only SELECT queries are allowed.")
    forbidden = (exp.Insert, exp.Update, exp.Delete, exp.Create, exp.Drop, exp.Alter, exp.Command, exp.Copy, exp.Set,
                 exp.Pragma, exp.Attach, exp.Use, exp.Merge, exp.Transaction, exp.Commit, exp.Rollback)
    for node in tree.walk():
        n = node[0] if isinstance(node, tuple) else node
        if isinstance(n, forbidden):
            raise UnsafeSQL("Only read-only SELECT queries are allowed.")
    ctes = {c.alias.lower() for c in tree.find_all(exp.CTE)}
    for t in tree.find_all(exp.Table):
        if not isinstance(t.this, exp.Identifier):
            raise UnsafeSQL("Table functions are not allowed.")
        if t.args.get("db") or t.args.get("catalog"):
            raise UnsafeSQL("Schema-qualified tables are not allowed.")
        name = t.name.lower()
        if name != TABLE and name not in ctes:
            raise UnsafeSQL(f"Unknown table '{t.name}'. Query the table named {TABLE}.")
    for f in tree.find_all(exp.Func):
        fname = (f.name if isinstance(f, exp.Anonymous) else type(f).__name__).lower()
        sql_name = (f.sql_name() if hasattr(f, "sql_name") else fname).lower()
        for part in BLOCKED_FUNC_PARTS:
            if part in fname or part in sql_name:
                raise UnsafeSQL(f"Function '{f.name or fname}' is not allowed.")
    return tree.sql(dialect="duckdb")


def run_query(df: pd.DataFrame, sql: str) -> dict:
    safe = validate_sql(sql)
    con = duckdb.connect(":memory:")
    try:
        con.register(TABLE, df)
        con.execute("SET threads=2")
        con.execute("SET memory_limit='768MB'")
        con.execute("SET enable_external_access=false")
        con.execute("SET lock_configuration=true")
        timer = threading.Timer(TIMEOUT_S, con.interrupt)
        timer.start()
        try:
            cur = con.execute(safe)
            cols = [d[0] for d in cur.description]
            rows = cur.fetchmany(MAX_ROWS + 1)
        except duckdb.InterruptException as e:
            raise UnsafeSQL("The query took too long and was stopped.") from e
        except duckdb.Error as e:
            raise UnsafeSQL(f"Query error: {str(e).splitlines()[0][:200]}") from e
        finally:
            timer.cancel()
        truncated = len(rows) > MAX_ROWS
        rows = rows[:MAX_ROWS]
        out = [[(v.isoformat() if hasattr(v, "isoformat") else (float(v) if hasattr(v, "__float__") and not isinstance(v, (int, float, bool, str)) else v)) for v in r] for r in rows]
        return {"sql": safe, "columns": cols, "rows": out, "row_count": len(out), "truncated": truncated}
    finally:
        con.close()
