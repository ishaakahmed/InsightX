import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "./api";
export type Cap = { available: boolean; reason: string };
export type Col = { name: string; type: string; role: string; role_confirmed: boolean; stats: any };
export type DatasetDetail = { id: string; name: string; rows: number; columns: number; quality_score: number; capabilities: Record<string, Cap>; date_range: { min: string; max: string } | null; columns_detail: Col[]; original_filename: string; created_at: string };
export type DatasetSummary = { id: string; name: string; rows: number; columns: number; quality_score: number; created_at: string; original_filename: string };
const Ctx = createContext<{ list: DatasetSummary[]; loading: boolean; current: DatasetSummary | null; select: (id: string) => void; detail: DatasetDetail | undefined } | null>(null);
export const useDataset = () => useContext(Ctx)!;
export function DatasetProvider({ children }: { children: ReactNode }) {
  const list = useQuery({ queryKey: ["datasets"], queryFn: () => api<DatasetSummary[]>("/datasets") });
  const [id, setId] = useState<string | null>(() => localStorage.getItem("ix-dataset"));
  const current = list.data?.find((d) => d.id === id) ?? list.data?.[0] ?? null;
  useEffect(() => { if (current) localStorage.setItem("ix-dataset", current.id); }, [current?.id]);
  const detail = useQuery({ queryKey: ["dataset", current?.id], queryFn: () => api<DatasetDetail>(`/datasets/${current!.id}`), enabled: !!current });
  return <Ctx.Provider value={{ list: list.data ?? [], loading: list.isLoading, current, select: setId, detail: detail.data }}>{children}</Ctx.Provider>;
}
