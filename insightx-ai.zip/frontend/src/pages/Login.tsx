import { FormEvent, useState } from "react";
import { useAuth } from "../lib/auth";

export default function Login() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState(""); const [password, setPassword] = useState(""); const [name, setName] = useState("");
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr(""); setBusy(true);
    try { mode === "login" ? await login(email, password) : await register(email, password, name); } catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
  };
  return (
    <div className="grid min-h-full lg:grid-cols-[1.1fr_1fr]">
      <div className="hidden flex-col justify-between bg-[rgb(16,24,40)] p-12 text-white lg:flex">
        <div className="flex items-center gap-2"><span className="grid h-8 w-8 place-items-center rounded-md bg-white text-sm font-bold text-[rgb(16,24,40)]">X</span><span className="text-lg font-semibold">InsightX AI</span></div>
        <div className="max-w-md"><h1 className="text-4xl font-semibold leading-tight tracking-tight">Your numbers, explained.</h1>
          <p className="mt-4 text-white/70">Upload sales data and get validated KPIs, backtested forecasts and an analyst that answers from your actual figures — never from guesses.</p></div>
        <p className="text-xs text-white/50">Every figure is computed from your dataset and traceable to its source.</p>
      </div>
      <div className="grid place-items-center p-6">
        <form onSubmit={submit} className="w-full max-w-sm space-y-4" aria-labelledby="auth-title">
          <h2 id="auth-title" className="text-2xl font-semibold tracking-tight">{mode === "login" ? "Sign in" : "Create your account"}</h2>
          {mode === "register" && <div><label className="mb-1 block text-sm font-medium" htmlFor="name">Name</label><input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" /></div>}
          <div><label className="mb-1 block text-sm font-medium" htmlFor="email">Email</label><input id="email" type="email" required className="input" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" /></div>
          <div><label className="mb-1 block text-sm font-medium" htmlFor="pw">Password</label><input id="pw" type="password" required minLength={mode === "register" ? 10 : 1} className="input" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === "login" ? "current-password" : "new-password"} />
            {mode === "register" && <p className="mt-1 text-xs text-muted">At least 10 characters with upper and lower case letters and a number.</p>}</div>
          {err && <p role="alert" className="text-sm text-down">{err}</p>}
          <button className="btn-primary w-full" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}</button>
          <p className="text-center text-sm text-muted">{mode === "login" ? "New here?" : "Already registered?"} <button type="button" className="font-medium text-accent" onClick={() => { setMode(mode === "login" ? "register" : "login"); setErr(""); }}>{mode === "login" ? "Create an account" : "Sign in"}</button></p>
        </form>
      </div>
    </div>);
}
