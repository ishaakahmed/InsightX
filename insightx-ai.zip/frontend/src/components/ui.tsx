import { ReactNode } from "react";
import { Link } from "react-router-dom";
import { AlertTriangle, Database } from "lucide-react";

export const Skeleton = ({ h = 16, w = "100%" }: { h?: number; w?: number | string }) => <div className="skeleton" style={{ height: h, width: w }} />;
export function ErrorBox({ error, retry }: { error: unknown; retry?: () => void }) {
  return <div role="alert" className="panel flex items-start gap-3 p-4 text-sm"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-down" />
    <div className="flex-1"><p className="font-medium">This could not be loaded</p><p className="text-muted">{(error as Error)?.message ?? "Unknown error"}</p></div>
    {retry && <button className="btn-ghost" onClick={retry}>Try again</button>}</div>;
}
export function Unavailable({ reason }: { reason: string }) {
  return <div className="panel p-6 text-sm"><p className="font-medium">Not available for this dataset</p><p className="mt-1 text-muted">{reason}</p>
    <Link to="/datasets" className="btn-ghost mt-3 inline-flex">Review column mapping</Link></div>;
}
export function NoDataset() {
  return <div className="panel mx-auto mt-10 max-w-lg p-8 text-center"><Database className="mx-auto h-8 w-8 text-accent" />
    <h2 className="mt-3 text-lg font-semibold">Upload a dataset to get started</h2>
    <p className="mt-1 text-sm text-muted">Everything in InsightX is calculated from your own data. Add a CSV or Excel file with sales, orders or transactions.</p>
    <Link to="/datasets" className="btn-primary mt-4 inline-flex">Upload dataset</Link></div>;
}
export const PageHeader = ({ title, sub, actions }: { title: string; sub?: string; actions?: ReactNode }) => (
  <div className="mb-5 flex flex-wrap items-end justify-between gap-3"><div><h1 className="text-xl font-semibold tracking-tight">{title}</h1>{sub && <p className="mt-0.5 text-sm text-muted">{sub}</p>}</div><div className="flex items-center gap-2">{actions}</div></div>
);
export const Section = ({ title, sub, right, children, className = "" }: { title: string; sub?: string; right?: ReactNode; children: ReactNode; className?: string }) => (
  <section className={`panel ${className}`}><header className="flex items-start justify-between gap-3 border-b border-line px-4 py-3"><div><h2 className="text-sm font-semibold">{title}</h2>{sub && <p className="text-xs text-muted">{sub}</p>}</div>{right}</header><div className="p-4">{children}</div></section>
);
export const Delta = ({ v, points = false, invert = false }: { v: number | null | undefined; points?: boolean; invert?: boolean }) => {
  if (v === null || v === undefined) return <span className="text-xs text-muted">no prior period</span>;
  const good = invert ? v < 0 : v > 0;
  return <span className={`num text-xs font-medium ${v === 0 ? "text-muted" : good ? "text-up" : "text-down"}`}>{v > 0 ? "▲" : v < 0 ? "▼" : "–"} {Math.abs(v).toFixed(1)}{points ? " pts" : "%"}</span>;
};
export const Tabs = ({ tabs, value, onChange }: { tabs: string[]; value: string; onChange: (t: string) => void }) => (
  <div role="tablist" className="mb-4 flex gap-1 border-b border-line">{tabs.map((t) => <button key={t} role="tab" aria-selected={t === value} onClick={() => onChange(t)} className={`-mb-px border-b-2 px-3 py-2 text-sm font-medium ${t === value ? "border-accent text-ink" : "border-transparent text-muted hover:text-ink"}`}>{t}</button>)}</div>
);
