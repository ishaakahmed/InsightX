import os
import tempfile
from pathlib import Path

_tmp = tempfile.mkdtemp(prefix="insightx_test_")
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
os.environ["STORAGE_DIR"] = f"{_tmp}/storage"
os.environ["ANTHROPIC_API_KEY"] = ""

import pandas as pd
import pytest
from fastapi.testclient import TestClient

from app.main import app
from scripts.generate_sample_data import generate

H = {"X-Requested-With": "InsightX"}


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


def _register(client, email):
    r = client.post("/api/v1/auth/register", json={"email": email, "password": "Str0ngPassw0rd!", "display_name": "T"})
    assert r.status_code == 201, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture(scope="session")
def auth_a(client):
    return _register(client, "a@example.com")


@pytest.fixture(scope="session")
def auth_b(client):
    return _register(client, "b@example.com")


@pytest.fixture(scope="session")
def sample_df():
    return generate()


@pytest.fixture(scope="session")
def sample_csv(tmp_path_factory, sample_df):
    p = tmp_path_factory.mktemp("data") / "retail.csv"
    sample_df.to_csv(p, index=False)
    return p


@pytest.fixture(scope="session")
def ds(client, auth_a, sample_csv):
    with open(sample_csv, "rb") as f:
        r = client.post("/api/v1/datasets", headers=auth_a, files={"file": ("retail.csv", f, "text/csv")}, data={"name": "Retail"})
    assert r.status_code == 201, r.text
    return r.json()
