from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import create_access_token, hash_password, hash_token, new_refresh_token, verify_password
from app.db import get_db
from app.deps import current_user
from app.models import RefreshToken, User

router = APIRouter(prefix="/auth", tags=["auth"])
COOKIE = "insightx_refresh"


class Credentials(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)
    display_name: str = Field(default="", max_length=120)


class Login(BaseModel):
    email: EmailStr
    password: str = Field(max_length=128)


def _issue(db: Session, user: User, response: Response) -> dict:
    s = get_settings()
    raw, hashed = new_refresh_token()
    db.add(RefreshToken(user_id=user.id, token_hash=hashed, expires_at=datetime.now(timezone.utc) + timedelta(days=s.refresh_token_days)))
    db.commit()
    response.set_cookie(COOKIE, raw, httponly=True, secure=s.cookie_secure, samesite="lax", max_age=s.refresh_token_days * 86400, path="/api/v1/auth")
    return {"access_token": create_access_token(user.id), "user": _user(user)}


def _user(u: User) -> dict:
    return {"id": u.id, "email": u.email, "display_name": u.display_name}


def _csrf(request: Request):
    if request.headers.get("x-requested-with") != "InsightX":
        raise HTTPException(403, "Missing CSRF header")


@router.post("/register", status_code=201)
def register(body: Credentials, response: Response, db: Session = Depends(get_db)):
    email = body.email.lower()
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(409, "An account with this email already exists.")
    pw = body.password
    if pw.lower() == pw or pw.upper() == pw or not any(ch.isdigit() for ch in pw):
        raise HTTPException(422, "Password needs upper and lower case letters and a number.")
    user = User(email=email, password_hash=hash_password(pw), display_name=body.display_name or email.split("@")[0])
    db.add(user)
    db.commit()
    return _issue(db, user, response)


@router.post("/login")
def login(body: Login, response: Response, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == body.email.lower()).first()
    now = datetime.now(timezone.utc)
    if user and user.locked_until and user.locked_until.replace(tzinfo=timezone.utc) > now:
        raise HTTPException(429, "Too many failed attempts. Try again in a few minutes.")
    if not user or not user.is_active or not verify_password(body.password, user.password_hash):
        if user:
            user.failed_logins += 1
            if user.failed_logins >= 5:
                user.locked_until, user.failed_logins = now + timedelta(minutes=15), 0
            db.commit()
        raise HTTPException(401, "Incorrect email or password.")
    user.failed_logins, user.locked_until = 0, None
    db.commit()
    return _issue(db, user, response)


@router.post("/refresh")
def refresh(request: Request, response: Response, db: Session = Depends(get_db)):
    _csrf(request)
    raw = request.cookies.get(COOKIE)
    tok = db.query(RefreshToken).filter(RefreshToken.token_hash == hash_token(raw)).first() if raw else None
    if not tok or tok.revoked_at or tok.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        raise HTTPException(401, "Session expired")
    tok.revoked_at = datetime.now(timezone.utc)  # rotation: each refresh token is single-use
    user = db.get(User, tok.user_id)
    if not user or not user.is_active:
        raise HTTPException(401, "Session expired")
    return _issue(db, user, response)


@router.post("/logout", status_code=204)
def logout(request: Request, response: Response, db: Session = Depends(get_db)):
    _csrf(request)
    raw = request.cookies.get(COOKIE)
    if raw:
        tok = db.query(RefreshToken).filter(RefreshToken.token_hash == hash_token(raw)).first()
        if tok:
            tok.revoked_at = datetime.now(timezone.utc)
            db.commit()
    response.delete_cookie(COOKIE, path="/api/v1/auth")


@router.get("/me")
def me(user: User = Depends(current_user)):
    return _user(user)


@router.delete("/me", status_code=204)
def delete_account(response: Response, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Delete the account and all of its datasets, files and derived data."""
    import shutil
    from app.models import Dataset
    from app.services.datasets import delete_dataset, dataset_dir
    for ds in db.query(Dataset).filter(Dataset.user_id == user.id).all():
        delete_dataset(db, ds)
    db.query(RefreshToken).filter(RefreshToken.user_id == user.id).delete()
    db.delete(user)
    db.commit()
    shutil.rmtree(get_settings().storage_dir / user.id, ignore_errors=True)
    response.delete_cookie(COOKIE, path="/api/v1/auth")
