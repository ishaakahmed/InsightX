import { useMemo, useState } from "react";
import { useDataset } from "./dataset";
import { ymd } from "./format";

export function useRange() {
  const { detail } = useDataset();
  const [preset, setPreset] = useState("all"); const [custom, setCustom] = useState<{ from: string; to: string }>({ from: "", to: "" });
  const max = detail?.date_range?.max; const min = detail?.date_range?.min;
  const range = useMemo(() => {
    if (!max || !min) return { from: undefined as string | undefined, to: undefined as string | undefined };
    const end = new Date(max); const back = (days: number) => { const d = new Date(end); d.setDate(d.getDate() - days + 1); return ymd(d) < min ? min : ymd(d); };
    if (preset === "90") return { from: back(90), to: max };
    if (preset === "365") return { from: back(365), to: max };
    if (preset === "custom") return { from: custom.from || undefined, to: custom.to || undefined };
    return { from: undefined, to: undefined };
  }, [preset, custom, max, min]);
  const days = range.from && range.to ? (new Date(range.to).getTime() - new Date(range.from).getTime()) / 864e5 + 1 : min && max ? (new Date(max).getTime() - new Date(min).getTime()) / 864e5 + 1 : 365;
  const ui = !max ? null : (
    <div className="flex flex-wrap items-center gap-2">
      <select className="input !w-auto !py-1.5" aria-label="Date range" value={preset} onChange={(e) => setPreset(e.target.value)}>
        <option value="all">All data</option><option value="365">Last 12 months</option><option value="90">Last 90 days</option><option value="custom">Custom range</option></select>
      {preset === "custom" && <><input type="date" aria-label="From" className="input !w-auto !py-1.5" min={min} max={max} value={custom.from} onChange={(e) => setCustom({ ...custom, from: e.target.value })} />
        <input type="date" aria-label="To" className="input !w-auto !py-1.5" min={min} max={max} value={custom.to} onChange={(e) => setCustom({ ...custom, to: e.target.value })} /></>}
    </div>);
  return { ...range, days, ui };
}
