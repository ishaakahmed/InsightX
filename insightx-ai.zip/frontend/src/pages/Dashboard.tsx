import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { api } from "../lib/api";
import { useDataset } from "../lib/dataset";
import { useRange } from "../lib/range";
import { compact, num, pct } from "../lib/format";
import { Chart } from "../components/Chart";
import { Delta, ErrorBox, NoDataset, PageHeader, Section, Skeleton, Unavailable } from "../components/ui";

export default function Dashboard() {
  const { current, detail, loading } = useDataset(); const r = useRange();
  const id = current?.id; const caps = detail?.capabilities;
  const params = { date_from: r.from, date_to: r.to };
  const kpis = useQuery({ queryKey: ["kpis", id, r.from, r.to], queryFn: () => api(`/datasets/${id}/analytics/kpis`, { params }), enabled: !!id && !!caps?.kpis.available });
  const gran = r.days <= 92 ? "day" : "month";
  const trend = useQuery({ queryKey: ["trend", id, "revenue", gran, r.from, r.to], queryFn: () => api(`/datasets/${id}/analytics/trend`, { params: { metric: "revenue", granularity: gran, ...params } }), enabled: !!id && !!caps?.trends.available });
  const ptrend = useQuery({ queryKey: ["trend", id, "profit", gran, r.from, r.to], queryFn: () => api(`/datasets/${id}/analytics/trend`, { params: { metric: "profit", granularity: gran, ...params } }), enabled: !!id && !!caps?.profit.available && !!caps?.trends.available });
  const prod = useQuery({ queryKey: ["bd", id, "product", r.from, r.to], queryFn: () => api(`/datasets/${id}/analytics/breakdown`, { params: { dimension: "product", top: 8, ...params } }), enabled: !!id && !!caps?.breakdowns.available && !!detail?.columns_detail.some((c) => c.role === "product") });
  const reg = useQuery({ queryKey: ["bd", id, "region", r.from, r.to], queryFn: () => api(`/datasets/${id}/analytics/breakdown`, { params: { dimension: "region", top: 8, ...params } }), enabled: !!id && !!caps?.breakdowns.available && !!detail?.columns_detail.some((c) => c.role === "region") });
  const alerts = useQuery({ queryKey: ["alerts", id], queryFn: () => api<any[]>(`/datasets/${id}/alerts`), enabled: !!id });
  const fc = useQuery({ queryKey: ["fc-latest", id], queryFn: () => api(`/datasets/${id}/ml/forecast/latest`), enabled: !!id && !!caps?.forecast.available, retry: false });

  if (loading) return <Skeleton h={200} />;
  if (!current) return <NoDataset />;
  if (!caps) return <Skeleton h={200} />;
  if (!caps.kpis.available) return <><PageHeader title="Dashboard" /><Unavailable reason={caps.kpis.reason} /></>;

  const c = kpis.data?.current; const ch = kpis.data?.change_pct ?? {}; const p = kpis.data?.period;
  const tiles: { k: string; label: string; v: string; d?: number | null; pts?: boolean }[] = c ? [
    { k: "revenue", label: "Revenue", v: compact(c.revenue), d: ch.revenue },
    ...(c.profit !== null ? [{ k: "profit", label: "Profit", v: compact(c.profit), d: ch.profit }, { k: "margin_pct", label: "Margin", v: pct(c.margin_pct), d: ch.margin_pct, pts: true }] : []),
    { k: "transactions", label: "Transactions", v: num(c.transactions), d: ch.transactions },
    ...(c.customers !== null ? [{ k: "customers", label: "Customers", v: num(c.customers), d: ch.customers }] : []),
    { k: "avg_order_value", label: "Avg order value", v: num(c.avg_order_value), d: ch.avg_order_value },
  ] : [];
  const fcf = fc.data;
  const trendOpt = (b: any) => {
    const x = trend.data.points.map((p: any) => p.date);
    const series: any[] = [{ name: "Revenue", type: "line", smooth: false, showSymbol: false, lineStyle: { width: 2 }, data: trend.data.points.map((p: any) => p.value), areaStyle: { opacity: 0.08 } }];
    if (ptrend.data) series.push({ name: "Profit", type: "line", showSymbol: false, lineStyle: { width: 2 }, data: ptrend.data.points.map((p: any) => p.value) });
    return { ...b, legend: { top: 0, right: 0, textStyle: { color: b.textStyle.color } }, xAxis: { ...b.xAxis, type: "category", data: x }, yAxis: { ...b.yAxis, type: "value", axisLabel: { ...b.yAxis.axisLabel, formatter: (v: number) => compact(v) } }, series };
  };
  const barOpt = (d: any) => (b: any) => ({ ...b, grid: { ...b.grid, left: 0 }, tooltip: { ...b.tooltip, trigger: "item" }, xAxis: { ...b.xAxis, type: "value", axisLabel: { ...b.xAxis.axisLabel, formatter: (v: number) => compact(v) }, splitLine: b.yAxis.splitLine }, yAxis: { type: "category", inverse: true, data: d.rows.map((r: any) => r.name), axisLabel: { color: b.textStyle.color, fontSize: 11, width: 110, overflow: "truncate" }, axisLine: { show: false }, axisTick: { show: false } }, series: [{ type: "bar", barMaxWidth: 16, data: d.rows.map((r: any) => r.value), itemStyle: { borderRadius: [0, 3, 3, 0] } }] });
  const open = alerts.data ?? [];
  return (
    <>
      <PageHeader title="Executive dashboard" sub={p ? `${p.from} to ${p.to} · compared with ${p.previous_from} to ${p.previous_to}` : current.name} actions={r.ui} />
      {kpis.isError ? <ErrorBox error={kpis.error} retry={() => kpis.refetch()} /> : (
        <div className="panel mb-4 grid grid-cols-2 divide-line sm:grid-cols-3 lg:grid-cols-6 lg:divide-x">
          {kpis.isLoading ? Array.from({ length: 6 }).map((_, i) => <div key={i} className="p-4"><Skeleton h={14} w={70} /><div className="mt-3"><Skeleton h={28} w={110} /></div></div>)
            : tiles.length ? tiles.map((t) => <div key={t.k} className="border-b border-line p-4 lg:border-b-0"><p className="text-xs font-medium text-muted">{t.label}</p><p className="num mt-1 text-2xl font-semibold tracking-tight">{t.v}</p><div className="mt-1"><Delta v={t.d} points={t.pts} /></div></div>)
            : <p className="col-span-full p-4 text-sm text-muted">No data in the selected range.</p>}
        </div>)}
      <div className="grid gap-4 lg:grid-cols-3">
        <Section className="lg:col-span-2" title="Revenue and profit" sub={`${gran === "day" ? "Daily" : "Monthly"} totals`}>
          {!caps.trends.available ? <p className="text-sm text-muted">{caps.trends.reason}</p> : trend.isLoading ? <Skeleton h={280} /> : trend.isError ? <ErrorBox error={trend.error} /> : trend.data.points.length ? <Chart label="Revenue and profit over time" option={trendOpt} /> : <p className="text-sm text-muted">No data in the selected range.</p>}
        </Section>
        <Section title="Forecast" sub={fcf ? `${fcf.model} · ${fcf.granularity}ly revenue` : undefined}>
          {!caps.forecast.available ? <p className="text-sm text-muted">{caps.forecast.reason}</p> : fcf ? (
            <div><p className="text-xs text-muted">Next {fcf.horizon} {fcf.granularity}s</p><p className="num text-2xl font-semibold">{compact(fcf.total_forecast)}</p>
              <p className="mt-2 text-xs text-muted">Backtest error (sMAPE) <span className="num font-medium text-ink">{fcf.metrics.selected.smape.toFixed(1)}%</span></p>
              <p className="mt-2 text-xs text-muted">{fcf.verdict}</p><Link to="/predictions" className="btn-ghost mt-3">Open forecast</Link></div>
          ) : <div className="text-sm"><p className="text-muted">No forecast has been run for this dataset yet.</p><Link to="/predictions" className="btn-primary mt-3">Run forecast</Link></div>}
        </Section>
        {prod.data && <Section title="Top products" sub="By revenue"><Chart height={260} label="Top products by revenue" option={barOpt(prod.data)} /></Section>}
        {reg.data && <Section title="Regions" sub="By revenue"><Chart height={260} label="Revenue by region" option={barOpt(reg.data)} /></Section>}
        <Section title="Alerts" right={<Link to="/alerts" className="text-xs font-medium text-accent">View all</Link>}>
          {alerts.isLoading ? <Skeleton h={80} /> : open.length ? <ul className="space-y-2.5">{open.slice(0, 4).map((a) => <li key={a.id} className="flex gap-2 text-sm"><span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${a.severity === "critical" ? "bg-down" : a.severity === "warning" ? "bg-warn" : "bg-muted"}`} aria-label={a.severity} />{a.message}</li>)}</ul> : <p className="text-sm text-muted">No open alerts. Alerts appear when revenue, margin or data quality changes materially.</p>}
        </Section>
      </div>
    </>);
}
