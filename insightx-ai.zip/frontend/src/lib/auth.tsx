import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { api, setToken, tryRestoreSession } from "./api";
export type User = { id: string; email: string; display_name: string };
const Ctx = createContext<{ user: User | null; loading: boolean; login: (e: string, p: string) => Promise<void>; register: (e: string, p: string, n: string) => Promise<void>; logout: () => Promise<void> } | null>(null);
export const useAuth = () => useContext(Ctx)!;
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    tryRestoreSession().then(async (ok) => { if (ok) { try { setUser(await api("/auth/me")); } catch {} } setLoading(false); });
    const out = () => { setToken(null); setUser(null); };
    window.addEventListener("ix-logout", out); return () => window.removeEventListener("ix-logout", out);
  }, []);
  const take = (r: any) => { setToken(r.access_token); setUser(r.user); };
  return <Ctx.Provider value={{ user, loading,
    login: async (email, password) => take(await api("/auth/login", { method: "POST", body: { email, password } })),
    register: async (email, password, display_name) => take(await api("/auth/register", { method: "POST", body: { email, password, display_name } })),
    logout: async () => { try { await fetch("/api/v1/auth/logout", { method: "POST", credentials: "include", headers: { "X-Requested-With": "InsightX" } }); } catch {} setToken(null); setUser(null); } }}>{children}</Ctx.Provider>;
}
