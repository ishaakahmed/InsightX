import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../lib/api";
import { useDataset } from "../lib/dataset";
import { useRange } from "../lib/range";
import { compact, num, pct } from "../lib/format";
import { Chart } from "../components/Chart";
import { Delta, ErrorBox, NoDataset, PageHeader, Section, Skeleton, Unavailable } from "../components/ui";
import { cssVar } from "../lib/theme";

const FIELDS: [string, string, number, number, number, string][] = [
  ["price_change_pct", "Price change", -50, 100, 1, "%"], ["volume_change_pct", "Sales volume change", -50, 100, 1, "%"], ["unit_cost_change_pct", "Unit cost change", -50, 100, 1, "%"], ["price_elasticity", "Price elasticity of demand", -5, 1, 0.1, ""],
];

export default function WhatIf() {
  const { current, detail } = useDataset(); const r = useRange(); const qc = useQueryClient();
  const [a, setA] = useState<Record<string, number>>({ price_change_pct: 0, volume_change_pct: 0, unit_cost_change_pct: 0, price_elasticity: 0, fixed_cost_change: 0 }); const [name, setName] = useState("");
  const id = current?.id; const ok = detail?.capabilities.simulation.available;
  const body = { ...a, date_from: r.from, date_to: r.to };
  const sim = useQuery({ queryKey: ["sim", id, a, r.from, r.to], queryFn: () => api(`/datasets/${id}/simulate`, { method: "POST", body }), enabled: !!id && !!ok, placeholderData: (p) => p });
  const saved = useQuery({ queryKey: ["sims", id], queryFn: () => api<any[]>(`/datasets/${id}/simulations`), enabled: !!id && !!ok });
  const save = useMutation({ mutationFn: () => api(`/datasets/${id}/simulate`, { method: "POST", body: { ...body, name: name || "Scenario", save: true } }), onSuccess: () => { setName(""); qc.invalidateQueries({ queryKey: ["sims", id] }); } });
  if (!current) return <NoDataset />; if (!detail) return <Skeleton h={200} />;
  if (!ok) return <><PageHeader title="What-if simulation" /><Unavailable reason={detail.capabilities.simulation.reason} /></>;
  const d = sim.data;
  const wf = d?.waterfall;
  const wfOpt = (b: any) => { let run = 0; const base: number[] = [], up: any[] = [], dn: any[] = [];
    wf.forEach((s: any, i: number) => { const total = i === 0 || i === wf.length - 1; if (total) { base.push(0); up.push(s.value); dn.push(0); run = s.value; } else { const next = run + s.value; base.push(Math.min(run, next)); up.push(s.value > 0 ? s.value : 0); dn.push(s.value < 0 ? -s.value : 0); run = next; } });
    return { ...b, tooltip: { ...b.tooltip, trigger: "axis", axisPointer: { type: "shadow" } }, xAxis: { ...b.xAxis, type: "category", data: wf.map((s: any) => s.label), axisLabel: { ...b.xAxis.axisLabel, interval: 0, fontSize: 10 } }, yAxis: { ...b.yAxis, type: "value", axisLabel: { ...b.yAxis.axisLabel, formatter: (v: number) => compact(v) } },
      series: [{ type: "bar", stack: "w", itemStyle: { color: "transparent" }, data: base, tooltip: { show: false } }, { name: "Increase / total", type: "bar", stack: "w", itemStyle: { color: cssVar("--accent") }, data: up }, { name: "Decrease", type: "bar", stack: "w", itemStyle: { color: cssVar("--down") }, data: dn }] }; };
  const sensOpt = (b: any) => ({ ...b, xAxis: { ...b.xAxis, type: "category", data: d.sensitivity.map((s: any) => `${s.price_change_pct > 0 ? "+" : ""}${s.price_change_pct}%`), name: "Price change", nameLocation: "middle", nameGap: 28 }, yAxis: { ...b.yAxis, type: "value", axisLabel: { ...b.yAxis.axisLabel, formatter: (v: number) => compact(v) } },
    series: [{ name: "Profit", type: "line", data: d.sensitivity.map((s: any) => s.profit ?? s.revenue), lineStyle: { width: 2 } }] });
  return (
    <>
      <PageHeader title="What-if simulation" sub="Transparent arithmetic on your baseline. Every input is an assumption you control, not a prediction." actions={r.ui} />
      <div className="grid gap-4 lg:grid-cols-[20rem_1fr]">
        <Section title="Assumptions" sub={d?.period ? `Baseline: ${d.period.from} to ${d.period.to}` : undefined}>
          <div className="space-y-5">{FIELDS.map(([k, label, min, max, step, unit]) => <div key={k}><div className="flex justify-between text-sm"><label htmlFor={k}>{label}</label><span className="num font-medium">{a[k] > 0 && unit ? "+" : ""}{a[k]}{unit}</span></div>
            <input id={k} type="range" min={min} max={max} step={step} value={a[k]} onChange={(e) => setA({ ...a, [k]: +e.target.value })} className="mt-2 w-full accent-[rgb(var(--accent))]" /></div>)}
            <div><label htmlFor="fixed" className="text-sm">Fixed cost change (amount)</label><input id="fixed" type="number" className="input mt-1" value={a.fixed_cost_change} onChange={(e) => setA({ ...a, fixed_cost_change: +e.target.value || 0 })} /></div>
            <p className="text-xs text-muted">Elasticity links price to volume. At −1.5, a 10% price rise reduces volume by 15%. It starts at 0 (no demand response) — set it from what you know of your market.</p>
            <button className="btn-ghost w-full" onClick={() => setA({ price_change_pct: 0, volume_change_pct: 0, unit_cost_change_pct: 0, price_elasticity: 0, fixed_cost_change: 0 })}>Reset</button></div></Section>
        <div className="space-y-4">
          {sim.isError ? <ErrorBox error={sim.error} /> : !d ? <Skeleton h={200} /> : <>
            <div className="panel grid grid-cols-1 divide-line sm:grid-cols-3 sm:divide-x">{(["revenue", "profit", "margin_pct"] as const).map((k) => d.baseline[k] === null ? null : <div key={k} className="p-4"><p className="text-xs font-medium capitalize text-muted">{k === "margin_pct" ? "Margin" : k}</p>
              <p className="num mt-1 text-2xl font-semibold">{k === "margin_pct" ? pct(d.scenario[k]) : compact(d.scenario[k])}</p><p className="num mt-0.5 text-xs text-muted">from {k === "margin_pct" ? pct(d.baseline[k]) : compact(d.baseline[k])} <Delta v={k === "margin_pct" ? d.scenario[k] - d.baseline[k] : d.baseline[k] ? (d.scenario[k] - d.baseline[k]) / Math.abs(d.baseline[k]) * 100 : null} points={k === "margin_pct"} /></p></div>)}</div>
            {wf && <Section title="Profit bridge" sub="How each assumption moves profit"><Chart height={280} label="Profit waterfall from baseline to scenario" option={wfOpt} /></Section>}
            <Section title="Price sensitivity" sub="Scenario outcome across price changes, holding your other assumptions"><Chart height={240} label="Profit versus price change" option={sensOpt} /></Section>
            {d.notes.map((n: string) => <p key={n} className="text-sm text-warn">{n}</p>)}
            <p className="text-xs text-muted">{d.model}</p></>}
          <Section title="Saved scenarios" right={<div className="flex gap-2"><input className="input !w-44 !py-1" aria-label="Scenario name" placeholder="Scenario name" value={name} onChange={(e) => setName(e.target.value)} maxLength={120} /><button className="btn-ghost !py-1" disabled={save.isPending} onClick={() => save.mutate()}>Save</button></div>}>
            {saved.data?.length ? <table className="w-full"><thead><tr className="border-b border-line"><th className="th">Scenario</th><th className="th">Assumptions</th><th className="th text-right">Profit change</th></tr></thead><tbody>{saved.data.map((s) => <tr key={s.id} className="border-b border-line last:border-0"><td className="td font-medium">{s.name}</td><td className="td text-xs text-muted">price {s.assumptions.price_change_pct}% · volume {s.assumptions.volume_change_pct}% · cost {s.assumptions.unit_cost_change_pct}%</td><td className="td num text-right">{s.outcome.delta.profit === null ? "—" : compact(s.outcome.delta.profit)}</td></tr>)}</tbody></table> : <p className="text-sm text-muted">Saved scenarios appear here for comparison.</p>}</Section>
        </div>
      </div>
    </>);
}
