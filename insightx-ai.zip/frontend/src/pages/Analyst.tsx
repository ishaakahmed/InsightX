import { FormEvent, useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronRight, Plus, Send } from "lucide-react";
import { api } from "../lib/api";
import { useDataset } from "../lib/dataset";
import { NoDataset, PageHeader, Skeleton } from "../components/ui";

type Msg = { id: string; role: "user" | "assistant"; content: string; evidence?: any[]; mode?: string };

function Evidence({ items }: { items: any[] }) {
  const [open, setOpen] = useState(false);
  if (!items?.length) return null;
  return (
    <div className="mt-2 border-t border-line pt-2">
      <button className="flex items-center gap-1 text-xs font-medium text-muted hover:text-ink" onClick={() => setOpen(!open)} aria-expanded={open}>{open ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}Evidence · {items.length} calculation{items.length > 1 ? "s" : ""}</button>
      {open && <div className="mt-2 space-y-2">{items.map((e, i) => (
        <div key={i} className="rounded-md bg-sunken p-2.5 text-xs">
          <p className="font-medium">{e.tool}<span className="font-normal text-muted"> {Object.keys(e.args ?? {}).length ? JSON.stringify(e.args) : ""}</span></p>
          {e.result?.sql && <pre className="mt-1 overflow-x-auto whitespace-pre-wrap text-muted">{e.result.sql}</pre>}
          {e.result?.columns ? <div className="mt-1 max-h-48 overflow-auto"><table className="w-full"><thead><tr>{e.result.columns.map((c: string) => <th key={c} className="px-2 py-1 text-left text-muted">{c}</th>)}</tr></thead><tbody>{e.result.rows.slice(0, 20).map((r: any[], j: number) => <tr key={j}>{r.map((v, k) => <td key={k} className="num px-2 py-1">{String(v)}</td>)}</tr>)}</tbody></table></div>
            : <pre className="mt-1 max-h-40 overflow-auto whitespace-pre-wrap text-muted">{JSON.stringify(e.result, null, 1).slice(0, 1800)}</pre>}
        </div>))}</div>}
    </div>);
}

export default function Analyst() {
  const { current, detail } = useDataset(); const qc = useQueryClient(); const [cid, setCid] = useState<string | null>(null); const [msgs, setMsgs] = useState<Msg[]>([]); const [text, setText] = useState(""); const end = useRef<HTMLDivElement>(null);
  const id = current?.id;
  const convs = useQuery({ queryKey: ["convs", id], queryFn: () => api<any[]>(`/datasets/${id}/conversations`), enabled: !!id });
  const health = useQuery({ queryKey: ["health"], queryFn: () => api<any>("/health"), staleTime: 300_000 });
  useEffect(() => { setCid(null); setMsgs([]); }, [id]);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs.length]);
  const send = useMutation({
    mutationFn: (m: string) => api(`/datasets/${id}/chat`, { method: "POST", body: { message: m, conversation_id: cid } }),
    onSuccess: (r: any) => { setCid(r.conversation_id); setMsgs((x) => [...x, r.message]); qc.invalidateQueries({ queryKey: ["convs", id] }); },
    onError: (e: Error) => setMsgs((x) => [...x, { id: crypto.randomUUID(), role: "assistant", content: `I could not answer that: ${e.message}` }]),
  });
  const ask = (m: string) => { if (!m.trim() || send.isPending) return; setMsgs((x) => [...x, { id: crypto.randomUUID(), role: "user", content: m }]); setText(""); send.mutate(m); };
  const open = async (c: string) => { const r = await api<any>(`/conversations/${c}`); setCid(c); setMsgs(r.messages); };
  if (!current) return <NoDataset />; if (!detail) return <Skeleton h={200} />;
  const caps = detail.capabilities;
  const suggestions = [caps.kpis.available && "How is the business performing?", caps.kpis.available && caps.trends.available && "Why did revenue change in the latest period?", detail.columns_detail.some((c) => c.role === "product") && (caps.profit.available ? "Which product generates the highest profit?" : "Which product generates the highest revenue?"),
    caps.forecast.available && "Predict next quarter's sales", caps.segmentation.available && "Which customer segment is most valuable?", caps.profit.available && "What actions can improve profitability?", "What are the major business risks?"].filter(Boolean) as string[];
  return (
    <>
      <PageHeader title="AI Analyst" sub={`Answers use only calculations from ${current.name}`} actions={health.data && <span className="rounded-full bg-sunken px-2.5 py-1 text-xs text-muted" title={health.data.ai_mode === "llm" ? "A language model chooses analyses and writes the explanation." : "No AI key is configured. Questions are routed to the built-in analyses."}>{health.data.ai_mode === "llm" ? "AI mode" : "Built-in analysis mode"}</span>} />
      <div className="grid gap-4 lg:grid-cols-[1fr_16rem]">
        <div className="panel flex h-[calc(100vh-13rem)] min-h-[420px] flex-col">
          <div className="flex-1 space-y-4 overflow-y-auto p-4" aria-live="polite">
            {!msgs.length && <div className="mx-auto max-w-lg pt-6"><p className="text-sm text-muted">Ask about performance, products, customers, forecasts or risks. Each answer shows the calculations behind it.</p>
              <div className="mt-4 flex flex-wrap gap-2">{suggestions.map((s) => <button key={s} className="btn-ghost !py-1.5 text-left" onClick={() => ask(s)}>{s}</button>)}</div></div>}
            {msgs.map((m) => <div key={m.id} className={m.role === "user" ? "flex justify-end" : ""}><div className={`max-w-[85%] rounded-lg px-3.5 py-2.5 text-sm ${m.role === "user" ? "bg-accent text-white [[data-theme=dark]_&]:text-[rgb(11,15,25)]" : "border border-line bg-surface"}`}><p className="whitespace-pre-wrap">{m.content}</p>{m.role === "assistant" && <Evidence items={m.evidence ?? []} />}</div></div>)}
            {send.isPending && <div className="text-sm text-muted">Analysing…</div>}<div ref={end} />
          </div>
          <form className="flex gap-2 border-t border-line p-3" onSubmit={(e: FormEvent) => { e.preventDefault(); ask(text); }}>
            <input className="input" aria-label="Ask a question" placeholder="Ask about your data…" value={text} onChange={(e) => setText(e.target.value)} maxLength={2000} />
            <button className="btn-primary" disabled={send.isPending || !text.trim()} aria-label="Send"><Send className="h-4 w-4" /></button>
          </form>
        </div>
        <aside className="panel p-3"><button className="btn-ghost w-full" onClick={() => { setCid(null); setMsgs([]); }}><Plus className="h-4 w-4" />New conversation</button>
          <p className="mb-1 mt-4 px-1 text-xs font-semibold text-muted">History</p>
          {convs.data?.length ? <ul className="space-y-0.5">{convs.data.map((c) => <li key={c.id}><button onClick={() => open(c.id)} className={`w-full truncate rounded-md px-2 py-1.5 text-left text-sm hover:bg-sunken ${c.id === cid ? "bg-sunken font-medium" : ""}`}>{c.title}</button></li>)}</ul> : <p className="px-1 text-xs text-muted">No conversations yet.</p>}</aside>
      </div>
    </>);
}
