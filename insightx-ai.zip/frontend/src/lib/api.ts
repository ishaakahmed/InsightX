const BASE = "/api/v1";
let accessToken: string | null = null;
let refreshing: Promise<boolean> | null = null;
export const setToken = (t: string | null) => { accessToken = t; };

export class ApiError extends Error { constructor(public status: number, message: string) { super(message); } }

async function refresh(): Promise<boolean> {
  if (!refreshing) {
    refreshing = fetch(`${BASE}/auth/refresh`, { method: "POST", credentials: "include", headers: { "X-Requested-With": "InsightX" } })
      .then(async (r) => { if (!r.ok) return false; accessToken = (await r.json()).access_token; return true; })
      .catch(() => false).finally(() => { setTimeout(() => (refreshing = null), 0); });
  }
  return refreshing;
}

function message(body: any, status: number): string {
  const d = body?.detail ?? body?.error?.message;
  if (typeof d === "string") return d;
  if (Array.isArray(d)) return d.map((e) => e.msg).join("; ");
  return status >= 500 ? "Something went wrong on the server." : "Request failed.";
}

export async function api<T = any>(path: string, opts: { method?: string; body?: unknown; form?: FormData; params?: Record<string, any> } = {}, retry = true): Promise<T> {
  const qs = opts.params ? "?" + new URLSearchParams(Object.entries(opts.params).filter(([, v]) => v !== undefined && v !== null && v !== "").map(([k, v]) => [k, String(v)])).toString() : "";
  const headers: Record<string, string> = {};
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  if (opts.body) headers["Content-Type"] = "application/json";
  const res = await fetch(`${BASE}${path}${qs}`, { method: opts.method ?? "GET", headers, credentials: "include", body: opts.form ?? (opts.body ? JSON.stringify(opts.body) : undefined) });
  if (res.status === 401 && retry && !path.startsWith("/auth/")) {
    if (await refresh()) return api<T>(path, opts, false);
    window.dispatchEvent(new Event("ix-logout"));
  }
  if (!res.ok) { let b: any = null; try { b = await res.json(); } catch {} throw new ApiError(res.status, message(b, res.status)); }
  return res.status === 204 ? (undefined as T) : res.json();
}

export async function download(path: string, filename: string) {
  const res = await fetch(`${BASE}${path}`, { headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : {}, credentials: "include" });
  if (!res.ok) throw new ApiError(res.status, "Download failed.");
  const url = URL.createObjectURL(await res.blob());
  const a = document.createElement("a"); a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url);
}

export const tryRestoreSession = () => refresh();
