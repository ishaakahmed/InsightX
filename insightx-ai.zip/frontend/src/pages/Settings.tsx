import { useMutation, useQuery } from "@tanstack/react-query";
import { useAuth } from "../lib/auth";
import { useTheme } from "../lib/theme";
import { api } from "../lib/api";
import { PageHeader, Section } from "../components/ui";

export default function Settings() {
  const { user, logout } = useAuth(); const { theme, toggle } = useTheme();
  const health = useQuery({ queryKey: ["health"], queryFn: () => api<any>("/health") });
  const del = useMutation({ mutationFn: () => api("/auth/me", { method: "DELETE" }), onSuccess: () => logout() });
  return (
    <>
      <PageHeader title="Settings" />
      <div className="grid max-w-3xl gap-4">
        <Section title="Account"><dl className="space-y-2 text-sm"><div className="flex justify-between"><dt className="text-muted">Name</dt><dd>{user?.display_name}</dd></div><div className="flex justify-between"><dt className="text-muted">Email</dt><dd>{user?.email}</dd></div></dl></Section>
        <Section title="Appearance"><div className="flex items-center justify-between text-sm"><span>Theme: {theme}</span><button className="btn-ghost" onClick={toggle}>Switch to {theme === "dark" ? "light" : "dark"}</button></div></Section>
        <Section title="AI analyst"><p className="text-sm">{health.data?.ai_mode === "llm" ? "A language model is connected. It chooses which analyses to run and explains results; numbers still come from your data." : "No AI key is configured on the server, so the analyst uses the built-in analysis router. All dashboards, forecasts, simulations and reports work without it."}</p><p className="mt-2 text-xs text-muted">Raw rows are never sent to an AI provider by default. Only schema and computed aggregates are shared.</p></Section>
        <Section title="Delete account" sub="Permanently removes your account, datasets, files, models, reports and conversations.">
          <button className="btn-ghost text-down" disabled={del.isPending} onClick={() => confirm("Delete your account and all data? This cannot be undone.") && del.mutate()}>Delete account and all data</button></Section>
      </div>
    </>);
}
