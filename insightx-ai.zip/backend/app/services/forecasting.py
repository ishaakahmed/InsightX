"""Time-series forecasting with honest evaluation: rolling-origin backtests against naive baselines."""
import warnings

import numpy as np
import pandas as pd

from app.models import Dataset
from app.services import analytics as A
from app.services.util import jsonable

warnings.filterwarnings("ignore")
SEASON = {"month": 12, "week": 52}
FREQ = {"month": "MS", "week": "W-MON"}


def _period_series(ds: Dataset, metric: str, granularity: str) -> pd.Series:
    t = A.trend(ds, metric, granularity)
    s = pd.Series({pd.Timestamp(p["date"]): p["value"] for p in t["points"]}).sort_index()
    s = s.asfreq(FREQ[granularity])
    return s


def _drop_partial(ds: Dataset, s: pd.Series, granularity: str) -> pd.Series:
    rng = A.date_range(ds)
    if not rng["max"] or s.empty:
        return s
    last_day, first_day = pd.Timestamp(rng["max"]), pd.Timestamp(rng["min"])
    step = pd.offsets.MonthBegin(1) if granularity == "month" else pd.Timedelta(days=7)
    if s.index[-1] + step - pd.Timedelta(days=1) > last_day + pd.Timedelta(days=2):
        s = s.iloc[:-1]
    if len(s) and first_day > s.index[0] + pd.Timedelta(days=3):
        s = s.iloc[1:]
    return s


def _fit_predict(name: str, train: pd.Series, h: int, m: int, alpha: float = 0.2):
    """Returns (mean, lower, upper) arrays of length h."""
    y = train.astype(float)
    if name == "naive":
        mean = np.repeat(y.iloc[-1], h)
        sd = y.diff().dropna().std() or 0.0
        width = 1.2816 * sd * np.sqrt(np.arange(1, h + 1))
        return mean, mean - width, mean + width
    if name == "seasonal_naive":
        mean = np.array([y.iloc[-m + (i % m)] for i in range(h)])
        sd = y.diff(m).dropna().std() or 0.0
        width = np.repeat(1.2816 * sd, h)
        return mean, mean - width, mean + width
    from statsmodels.tsa.exponential_smoothing.ets import ETSModel
    seasonal = name == "ets_seasonal"
    trend = None if name == "ets_level" else "add"
    kw = dict(error="add", trend=trend, damped_trend=trend is not None,
              seasonal="add" if seasonal else None, seasonal_periods=m if seasonal else None)
    fit = ETSModel(y, **kw).fit(disp=False, maxiter=200)
    pred = fit.get_prediction(start=len(y), end=len(y) + h - 1).summary_frame(alpha=alpha)
    return pred["mean"].values, pred["pi_lower"].values, pred["pi_upper"].values


def _metrics(actual: np.ndarray, pred: np.ndarray) -> dict:
    err = actual - pred
    denom = (np.abs(actual) + np.abs(pred)) / 2
    smape = float(np.mean(np.where(denom == 0, 0, np.abs(err) / denom)) * 100)
    return {"mae": float(np.mean(np.abs(err))), "rmse": float(np.sqrt(np.mean(err ** 2))), "smape": smape}


def forecast(ds: Dataset, metric: str = "revenue", horizon: int = 6, granularity: str | None = None) -> dict:
    caps = ds.capabilities.get("forecast", {})
    if not caps.get("available"):
        raise A.AnalyticsError(caps.get("reason") or "Forecasting is not available for this dataset.")
    if metric not in ("revenue", "profit", "quantity"):
        raise A.AnalyticsError("Forecast metric must be revenue, profit or quantity.")
    if not 1 <= horizon <= 24:
        raise A.AnalyticsError("Horizon must be between 1 and 24 periods.")
    granularity = granularity or "month"
    if granularity not in FREQ:
        raise A.AnalyticsError("Forecast granularity must be month or week.")
    s = _drop_partial(ds, _period_series(ds, metric, granularity), granularity)
    gaps = int(s.isna().sum())
    s = s.fillna(0.0)
    m = SEASON[granularity]
    n = len(s)
    min_len = 12 if granularity == "month" else 26
    if n < min_len:
        raise A.AnalyticsError(f"Only {n} complete {granularity}s of history; need at least {min_len}.")
    warnings_out = []
    if gaps:
        warnings_out.append(f"{gaps} periods had no data and were treated as zero.")

    candidates = ["naive", "ets_level", "ets_trend"]
    if n >= m:
        candidates.insert(1, "seasonal_naive")
    if n >= 2 * m:
        candidates.append("ets_seasonal")
    eh = min(horizon, max(2, n // 6))
    if n >= 2 * m + 3:
        # Give the seasonal model two full cycles in every fold so all models are scored on the SAME folds.
        eh = max(1, min(eh, (n - 2 * m) // 3))
        min_train = 2 * m
    else:
        min_train = max(10, min(2 * m, n // 2))
    folds = [n - eh * f for f in range(3, 0, -1) if n - eh * f >= min_train] or [n - eh]
    results: dict[str, dict] = {}
    for name in candidates:
        acts, preds = [], []
        try:
            for origin in folds:
                mean, _, _ = _fit_predict(name, s.iloc[:origin], eh, m)
                acts.append(s.iloc[origin:origin + eh].values); preds.append(mean[:len(acts[-1])])
            met = _metrics(np.concatenate(acts), np.concatenate(preds))
            met["folds"] = len(folds)
            results[name] = met
        except Exception as e:
            warnings_out.append(f"Model {name} could not be evaluated ({type(e).__name__}).")
    if not results:
        raise A.AnalyticsError("No forecasting model could be fitted to this series.")
    baselines = {k: v for k, v in results.items() if k in ("naive", "seasonal_naive")}
    best = min(results, key=lambda k: results[k]["mae"])
    best_base = min(baselines, key=lambda k: baselines[k]["mae"]) if baselines else None
    improvement = None
    if best_base and best not in baselines:
        improvement = (1 - results[best]["mae"] / baselines[best_base]["mae"]) * 100 if baselines[best_base]["mae"] else None
    verdict = ("The selected model is a baseline: no statistical model beat the naive forecast on this series, so treat the forecast as low-skill."
               if best in baselines else
               f"{best} reduced backtest MAE by {improvement:.1f}% versus the best naive baseline ({best_base})." if improvement is not None else "")

    mean, lo, hi = _fit_predict(best, s, horizon, m)
    step = pd.offsets.MonthBegin(1) if granularity == "month" else pd.Timedelta(days=7)
    future_idx = [s.index[-1] + step * (i + 1) for i in range(horizon)]
    last_origin = folds[-1]
    bt_mean, _, _ = _fit_predict(best, s.iloc[:last_origin], eh, m)
    backtest = [{"date": s.index[last_origin + i].date().isoformat(), "actual": float(s.iloc[last_origin + i]), "predicted": float(bt_mean[i])}
                for i in range(min(eh, n - last_origin))]
    if best == "ets_level":
        lo, hi = np.maximum(lo, -np.inf), hi
    return jsonable({
        "metric": metric, "granularity": granularity, "horizon": horizon, "model": best, "baseline": best_base,
        "verdict": verdict, "improvement_vs_baseline_pct": improvement,
        "metrics": {"selected": results[best], "all_models": results},
        "evaluation": {"method": "rolling-origin backtest", "horizon": eh, "folds": len(folds), "interval": "80% prediction interval"},
        "history": [{"date": d.date().isoformat(), "value": float(v)} for d, v in s.items()],
        "forecast": [{"date": d.date().isoformat(), "value": float(a), "lower": float(b), "upper": float(c)} for d, a, b, c in zip(future_idx, mean, lo, hi)],
        "backtest": backtest, "warnings": warnings_out,
        "total_forecast": float(np.sum(mean)),
    })


def anomalies(ds: Dataset, metric: str = "revenue", granularity: str = "day", threshold: float = 3.5) -> dict:
    t = A.trend(ds, metric, granularity)
    s = pd.Series({pd.Timestamp(p["date"]): p["value"] for p in t["points"]}).sort_index()
    if len(s) < 14:
        raise A.AnalyticsError("At least 14 periods are needed for anomaly detection.")
    period = {"day": 7, "week": 52, "month": 12}[granularity]
    # Business series have multiplicative noise (a bad day is a % shortfall, not a fixed amount), so detect on a log scale when possible.
    use_log = bool((s >= 0).all())
    y = np.log1p(s) if use_log else s
    if len(y) >= 2 * period:
        from statsmodels.tsa.seasonal import STL
        y_full = y.asfreq({"day": "D", "week": "W-MON", "month": "MS"}[granularity]).interpolate()
        # Daily data: a month-long trend window stops the trend chasing day-to-day noise (which would shrink residuals and over-flag).
        stl_kw = {"trend": 31} if granularity == "day" else {}
        resid = STL(y_full, period=period, robust=True, **stl_kw).fit().resid.reindex(y.index)
        method = f"STL robust decomposition (period {period}) with median-absolute-deviation z-scores"
    else:
        resid = y - y.rolling(7 if granularity == "day" else 5, center=True, min_periods=3).median()
        method = "deviation from rolling median with median-absolute-deviation z-scores"
    if use_log:
        method += " on a log scale"
    resid = resid.dropna()
    mad = float(np.median(np.abs(resid - resid.median()))) or float(resid.std() or 1.0)
    z = 0.6745 * (resid - resid.median()) / mad
    flagged = z[np.abs(z) >= threshold]
    items = []
    for d, zz in flagged.items():
        expected = float(np.expm1(y[d] - resid[d])) if use_log else float(s[d] - resid[d])
        items.append({"date": d.date().isoformat(), "value": float(s[d]), "expected": expected, "z_score": float(zz),
                      "direction": "spike" if zz > 0 else "drop", "severity": "high" if abs(zz) >= threshold * 1.5 else "medium"})
    items.sort(key=lambda x: -abs(x["z_score"]))
    return jsonable({"metric": metric, "granularity": granularity, "method": method, "threshold": threshold,
                     "points_checked": int(len(s)), "anomaly_count": len(items), "anomalies": items[:50],
                     "series": [{"date": d.date().isoformat(), "value": float(v)} for d, v in s.items()],
                     "note": "Flagged points are statistically unusual, not confirmed errors or fraud."})
