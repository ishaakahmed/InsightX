import { useEffect, useRef } from "react";
import * as echarts from "echarts/core";
import { BarChart, HeatmapChart, LineChart, ScatterChart } from "echarts/charts";
import { DataZoomComponent, GridComponent, LegendComponent, TooltipComponent, VisualMapComponent } from "echarts/components";
import { CanvasRenderer } from "echarts/renderers";
echarts.use([BarChart, HeatmapChart, LineChart, ScatterChart, DataZoomComponent, GridComponent, LegendComponent, TooltipComponent, VisualMapComponent, CanvasRenderer]);
import { cssVar, useTheme } from "../lib/theme";

export const palette = () => [cssVar("--accent"), cssVar("--warn"), cssVar("--up"), "#8B5CF6", "#0EA5B7", cssVar("--down"), "#64748B"];
export function baseOption() {
  const ink = cssVar("--muted"), line = cssVar("--line");
  return { textStyle: { fontFamily: "Instrument Sans, system-ui, sans-serif", color: ink }, color: palette(), animationDuration: 350,
    grid: { left: 8, right: 12, top: 28, bottom: 8, containLabel: true },
    tooltip: { trigger: "axis", backgroundColor: cssVar("--surface"), borderColor: line, textStyle: { color: cssVar("--ink"), fontSize: 12 }, confine: true },
    xAxis: { axisLine: { lineStyle: { color: line } }, axisLabel: { color: ink, fontSize: 11 }, axisTick: { show: false } },
    yAxis: { splitLine: { lineStyle: { color: line, type: "dashed" } }, axisLabel: { color: ink, fontSize: 11 } } };
}
export function Chart({ option, height = 280, label }: { option: (b: ReturnType<typeof baseOption>) => any; height?: number; label: string }) {
  const ref = useRef<HTMLDivElement>(null); const inst = useRef<echarts.ECharts>();
  const { theme } = useTheme();
  useEffect(() => {
    if (!ref.current) return;
    inst.current = inst.current ?? echarts.init(ref.current);
    inst.current.setOption(option(baseOption()), true);
  }, [option, theme]);
  useEffect(() => {
    const ro = new ResizeObserver(() => inst.current?.resize()); if (ref.current) ro.observe(ref.current);
    return () => { ro.disconnect(); inst.current?.dispose(); inst.current = undefined; };
  }, []);
  return <div ref={ref} role="img" aria-label={label} style={{ height, width: "100%" }} />;
}
