import logging
import time
import uuid

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import get_settings
from app.db import Base, engine
from app.routers import analysis, assistant, auth, datasets, reports

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("insightx")
settings = get_settings()

app = FastAPI(title=settings.app_name, version="0.1.0", docs_url="/api/docs" if settings.environment != "production" else None, redoc_url=None, openapi_url="/api/openapi.json" if settings.environment != "production" else None)
app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()], allow_credentials=True,
                   allow_methods=["GET", "POST", "PATCH", "DELETE"], allow_headers=["Authorization", "Content-Type", "X-Requested-With"])


@app.middleware("http")
async def observe(request: Request, call_next):
    rid = uuid.uuid4().hex[:12]
    start = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception:
        log.exception("unhandled error rid=%s path=%s", rid, request.url.path)
        response = JSONResponse({"error": {"code": "internal_error", "message": "Something went wrong.", "request_id": rid}}, status_code=500)
    response.headers.update({"X-Request-ID": rid, "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
                             "Referrer-Policy": "same-origin", "Cache-Control": "no-store"})
    log.info("rid=%s %s %s -> %s %.0fms", rid, request.method, request.url.path, response.status_code, (time.perf_counter() - start) * 1000)
    return response


@app.on_event("startup")
def startup():
    Base.metadata.create_all(engine)


for r in (auth.router, datasets.router, analysis.router, assistant.router, reports.router):
    app.include_router(r, prefix="/api/v1")


@app.get("/api/v1/health")
def health():
    return {"status": "ok", "ai_mode": "llm" if settings.anthropic_api_key else "offline"}
