import { DragEvent, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, Trash2, UploadCloud, XCircle } from "lucide-react";
import { api } from "../lib/api";
import { DatasetDetail, useDataset } from "../lib/dataset";
import { num } from "../lib/format";
import { ErrorBox, PageHeader, Section, Skeleton, Tabs } from "../components/ui";

const ROLES = ["other", "date", "revenue", "cost", "profit", "quantity", "price", "order_id", "customer_id", "product", "region", "category"];
const ROLE_LABEL: Record<string, string> = { other: "Not mapped", date: "Date", revenue: "Revenue", cost: "Cost", profit: "Profit", quantity: "Quantity", price: "Unit price", order_id: "Order ID", customer_id: "Customer", product: "Product", region: "Region", category: "Category" };

function Upload({ onDone }: { onDone: (id: string) => void }) {
  const qc = useQueryClient(); const input = useRef<HTMLInputElement>(null); const [drag, setDrag] = useState(false);
  const m = useMutation({ mutationFn: (f: File) => { const fd = new FormData(); fd.append("file", f); return api<DatasetDetail>("/datasets", { method: "POST", form: fd }); },
    onSuccess: async (d) => { await qc.invalidateQueries({ queryKey: ["datasets"] }); onDone(d.id); } });
  const pick = (f?: File) => f && m.mutate(f);
  return (
    <div onDragOver={(e: DragEvent) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={(e: DragEvent) => { e.preventDefault(); setDrag(false); pick(e.dataTransfer.files[0]); }}
      className={`panel flex flex-col items-center justify-center gap-2 border-dashed p-8 text-center ${drag ? "border-accent bg-accent/5" : ""}`}>
      <UploadCloud className="h-7 w-7 text-accent" />
      <p className="text-sm font-medium">{m.isPending ? "Validating and profiling your file…" : "Drop a CSV or Excel file here"}</p>
      <p className="text-xs text-muted">.csv or .xlsx, up to 50 MB, first row must be column headers</p>
      <input ref={input} type="file" accept=".csv,.xlsx" className="sr-only" aria-label="Choose file" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ""; }} />
      <button className="btn-primary mt-1" disabled={m.isPending} onClick={() => input.current?.click()}>Choose file</button>
      {m.isError && <p role="alert" className="mt-2 text-sm text-down">{(m.error as Error).message}</p>}
    </div>);
}

function Mapping({ d }: { d: DatasetDetail }) {
  const qc = useQueryClient();
  const m = useMutation({ mutationFn: (v: { col: string; role: string }) => api(`/datasets/${d.id}/columns/${encodeURIComponent(v.col)}`, { method: "PATCH", body: { role: v.role } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["dataset", d.id] }); qc.invalidateQueries(); } });
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <div className="panel overflow-x-auto lg:col-span-2"><table className="w-full"><thead><tr className="border-b border-line"><th className="th">Column</th><th className="th">Detected type</th><th className="th">Meaning</th></tr></thead>
        <tbody>{d.columns_detail.map((c) => <tr key={c.name} className="border-b border-line last:border-0"><td className="td font-medium">{c.name}</td><td className="td text-muted">{c.type}</td>
          <td className="td"><select aria-label={`Meaning of ${c.name}`} className="input !w-44 !py-1" value={c.role} onChange={(e) => m.mutate({ col: c.name, role: e.target.value })}>{ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}</select>
            {c.role !== "other" && !c.role_confirmed && <span className="ml-2 text-xs text-muted">auto-detected</span>}</td></tr>)}</tbody></table>
        {m.isError && <p role="alert" className="p-3 text-sm text-down">{(m.error as Error).message}</p>}</div>
      <Section title="What this dataset supports" sub="Based on the mapping">
        <ul className="space-y-2 text-sm">{Object.entries(d.capabilities).map(([k, v]) => <li key={k} className="flex gap-2">{v.available ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-up" /> : <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-muted" />}
          <div><p className="font-medium capitalize">{k.replace("_", " ")}</p>{!v.available && <p className="text-xs text-muted">{v.reason}</p>}</div></li>)}</ul>
      </Section>
    </div>);
}

function Preview({ d }: { d: DatasetDetail }) {
  const [offset, setOffset] = useState(0); const [sort, setSort] = useState<string>(); const [order, setOrder] = useState<"asc" | "desc">("asc");
  const [fcol, setFcol] = useState(""); const [fop, setFop] = useState("contains"); const [fval, setFval] = useState(""); const [applied, setApplied] = useState<string[]>([]);
  const fetchPreview = () => { const sp = new URLSearchParams({ offset: String(offset), limit: "25", order }); if (sort) sp.set("sort", sort); applied.forEach((f) => sp.append("filter", f)); return api(`/datasets/${d.id}/preview?${sp.toString()}`); };
  const q = useQuery({ queryKey: ["preview", d.id, d.rows, offset, sort, order, applied], queryFn: fetchPreview });
  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <select aria-label="Filter column" className="input !w-44 !py-1.5" value={fcol} onChange={(e) => setFcol(e.target.value)}><option value="">Filter column…</option>{d.columns_detail.map((c) => <option key={c.name}>{c.name}</option>)}</select>
        <select aria-label="Operator" className="input !w-32 !py-1.5" value={fop} onChange={(e) => setFop(e.target.value)}>{["contains", "eq", "ne", "gt", "gte", "lt", "lte", "isnull", "notnull"].map((o) => <option key={o}>{o}</option>)}</select>
        <input aria-label="Value" className="input !w-40 !py-1.5" value={fval} onChange={(e) => setFval(e.target.value)} placeholder="Value" />
        <button className="btn-ghost" disabled={!fcol} onClick={() => { setApplied([...applied, `${fcol}|${fop}|${fval}`]); setOffset(0); }}>Add filter</button>
        {applied.map((f, i) => <button key={f} className="rounded-full bg-sunken px-2.5 py-1 text-xs" onClick={() => setApplied(applied.filter((_, j) => j !== i))}>{f.replaceAll("|", " ")} ✕</button>)}
      </div>
      {q.isLoading ? <Skeleton h={300} /> : q.isError ? <ErrorBox error={q.error} /> : (
        <div className="panel overflow-x-auto"><table className="w-full"><thead><tr className="border-b border-line">{q.data.columns.map((c: string) => <th key={c} className="th"><button className="font-semibold" onClick={() => { setOrder(sort === c && order === "asc" ? "desc" : "asc"); setSort(c); }}>{c}{sort === c ? (order === "asc" ? " ↑" : " ↓") : ""}</button></th>)}</tr></thead>
          <tbody>{q.data.rows.map((r: any[], i: number) => <tr key={i} className="border-b border-line last:border-0">{r.map((v, j) => <td key={j} className={`td ${typeof v === "number" ? "num text-right" : ""}`}>{v === null ? <span className="text-muted">—</span> : String(v).slice(0, 40)}</td>)}</tr>)}</tbody></table></div>)}
      {q.data && <div className="mt-3 flex items-center justify-between text-sm text-muted"><span>{num(q.data.total)} rows{applied.length ? " match" : ""}</span>
        <div className="flex gap-2"><button className="btn-ghost" disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - 25))}>Previous</button><button className="btn-ghost" disabled={offset + 25 >= q.data.total} onClick={() => setOffset(offset + 25)}>Next</button></div></div>}
    </div>);
}

function Profile({ d }: { d: DatasetDetail }) {
  return <div className="panel overflow-x-auto"><table className="w-full"><thead><tr className="border-b border-line">{["Column", "Type", "Missing", "Unique", "Min", "Median", "Mean", "Max"].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
    <tbody>{d.columns_detail.map((c) => { const s = c.stats; return <tr key={c.name} className="border-b border-line last:border-0"><td className="td font-medium">{c.name}</td><td className="td text-muted">{c.type}</td>
      <td className="td num">{s.null_pct}%</td><td className="td num">{num(s.unique_count)}</td><td className="td num">{s.min ?? "—"}</td><td className="td num">{s.median !== undefined ? num(s.median, 2) : "—"}</td><td className="td num">{s.mean !== undefined ? num(s.mean, 2) : "—"}</td><td className="td num">{s.max ?? "—"}</td></tr>; })}</tbody></table></div>;
}

function Quality({ d }: { d: DatasetDetail }) {
  const q = useQuery({ queryKey: ["quality", d.id, d.quality_score], queryFn: () => api(`/datasets/${d.id}/quality`) });
  if (q.isLoading) return <Skeleton h={160} />; if (q.isError) return <ErrorBox error={q.error} />;
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Section title="Quality score"><p className="num text-4xl font-semibold">{q.data.score.toFixed(0)}<span className="text-lg text-muted"> / 100</span></p>
        <div className="mt-4 space-y-3">{Object.entries(q.data.breakdown as Record<string, number>).map(([k, v]) => <div key={k}><div className="flex justify-between text-xs"><span className="capitalize">{k}</span><span className="num text-muted">{v}</span></div><div className="mt-1 h-1.5 rounded bg-sunken"><div className="h-1.5 rounded bg-accent" style={{ width: `${v}%` }} /></div></div>)}</div></Section>
      <Section className="lg:col-span-2" title="Issues found">{q.data.issues.length ? <ul className="divide-y divide-line text-sm">{q.data.issues.map((i: any, n: number) => <li key={n} className="flex justify-between gap-3 py-2"><span><span className="font-medium">{i.column ?? "Dataset"}</span> <span className="text-muted">· {i.type.replace("_", " ")}</span></span><span className="text-muted">{i.detail}</span></li>)}</ul> : <p className="text-sm text-muted">No issues were found.</p>}</Section>
    </div>);
}

function Cleaning({ d }: { d: DatasetDetail }) {
  const qc = useQueryClient(); const [op, setOp] = useState("drop_duplicates"); const [col, setCol] = useState(""); const [strat, setStrat] = useState("median"); const [val, setVal] = useState("");
  const body = (dry: boolean) => ({ operation: op, dry_run: dry, params: op === "impute" ? { column: col, strategy: strat, ...(strat === "constant" ? { value: val } : {}) } : op === "drop_column" ? { column: col } : op === "drop_missing_rows" && col ? { columns: [col] } : {} });
  const preview = useMutation({ mutationFn: () => api(`/datasets/${d.id}/clean`, { method: "POST", body: body(true) }) });
  const apply = useMutation({ mutationFn: () => api(`/datasets/${d.id}/clean`, { method: "POST", body: body(false) }), onSuccess: () => { preview.reset(); qc.invalidateQueries(); } });
  const log = useQuery({ queryKey: ["clog", d.id, d.rows, d.quality_score], queryFn: () => api<any[]>(`/datasets/${d.id}/cleaning-log`) });
  const needsCol = ["impute", "drop_column"].includes(op);
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Section title="Clean this dataset" sub="Your original upload is never modified. Preview an operation first.">
        <div className="space-y-3">
          <select aria-label="Operation" className="input" value={op} onChange={(e) => { setOp(e.target.value); preview.reset(); }}>
            <option value="drop_duplicates">Remove duplicate rows</option><option value="drop_missing_rows">Remove rows with missing values</option><option value="impute">Fill missing values in a column</option><option value="trim_text">Trim extra spaces in text</option><option value="drop_column">Remove a column</option></select>
          {(needsCol || op === "drop_missing_rows") && <select aria-label="Column" className="input" value={col} onChange={(e) => setCol(e.target.value)}><option value="">{op === "drop_missing_rows" ? "Any column" : "Choose column…"}</option>{d.columns_detail.map((c) => <option key={c.name}>{c.name}</option>)}</select>}
          {op === "impute" && <div className="flex gap-2"><select aria-label="Method" className="input" value={strat} onChange={(e) => setStrat(e.target.value)}><option value="median">Median</option><option value="mean">Mean</option><option value="mode">Most common value</option><option value="constant">Fixed value</option></select>{strat === "constant" && <input className="input" aria-label="Value" value={val} onChange={(e) => setVal(e.target.value)} placeholder="Value" />}</div>}
          <div className="flex gap-2"><button className="btn-ghost" disabled={(needsCol && !col) || preview.isPending} onClick={() => preview.mutate()}>Preview effect</button>
            <button className="btn-primary" disabled={!preview.data || apply.isPending} onClick={() => apply.mutate()}>Apply</button></div>
          {preview.data && <p className="rounded-md bg-sunken p-3 text-sm">Rows: <span className="num font-medium">{num(preview.data.rows_before)}</span> → <span className="num font-medium">{num(preview.data.rows_after)}</span>{preview.data.cells_changed ? <> · {num(preview.data.cells_changed)} cells changed</> : null}</p>}
          {(preview.isError || apply.isError) && <p role="alert" className="text-sm text-down">{((preview.error || apply.error) as Error).message}</p>}
        </div></Section>
      <Section title="Cleaning history">{log.data?.length ? <ol className="space-y-2 text-sm">{log.data.map((l) => <li key={l.sequence} className="flex justify-between"><span>{l.sequence}. {l.operation.replaceAll("_", " ")}</span><span className="num text-muted">{num(l.rows_before)} → {num(l.rows_after)} rows</span></li>)}</ol> : <p className="text-sm text-muted">No cleaning has been applied.</p>}</Section>
    </div>);
}

export default function Datasets() {
  const { list, current, select, detail } = useDataset(); const qc = useQueryClient(); const [tab, setTab] = useState("Column mapping");
  const del = useMutation({ mutationFn: (id: string) => api(`/datasets/${id}`, { method: "DELETE" }), onSuccess: () => { localStorage.removeItem("ix-dataset"); qc.invalidateQueries(); } });
  return (
    <>
      <PageHeader title="Datasets" sub="Upload, review and prepare the data every other page is calculated from." />
      <Upload onDone={(id) => { select(id); setTab("Column mapping"); }} />
      {list.length > 0 && <div className="panel mt-4 overflow-x-auto"><table className="w-full"><thead><tr className="border-b border-line">{["Name", "Rows", "Columns", "Quality", "Uploaded", ""].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
        <tbody>{list.map((d) => <tr key={d.id} className={`border-b border-line last:border-0 ${d.id === current?.id ? "bg-accent/5" : ""}`}><td className="td"><button className="font-medium text-left hover:underline" onClick={() => select(d.id)}>{d.name}</button></td><td className="td num">{num(d.rows)}</td><td className="td num">{d.columns}</td><td className="td num">{d.quality_score.toFixed(0)}/100</td><td className="td text-muted">{new Date(d.created_at).toLocaleDateString()}</td>
          <td className="td text-right"><button className="btn-ghost !p-1.5 text-down" aria-label={`Delete ${d.name}`} onClick={() => confirm(`Delete "${d.name}" and all analysis, reports and chats based on it? This cannot be undone.`) && del.mutate(d.id)}><Trash2 className="h-4 w-4" /></button></td></tr>)}</tbody></table></div>}
      {current && detail && <div className="mt-6"><h2 className="mb-3 text-base font-semibold">{detail.name}</h2>
        <Tabs tabs={["Column mapping", "Preview", "Profile", "Quality", "Cleaning"]} value={tab} onChange={setTab} />
        {tab === "Column mapping" && <Mapping d={detail} />}{tab === "Preview" && <Preview d={detail} />}{tab === "Profile" && <Profile d={detail} />}{tab === "Quality" && <Quality d={detail} />}{tab === "Cleaning" && <Cleaning d={detail} />}</div>}
    </>);
}
