import pandas as pd
import pytest

from app.services import sql_guard
from tests.conftest import H

API = "/api/v1"


# ---------------- forecasting & anomalies ----------------
def test_forecast_is_evaluated_and_honest(client, auth_a, ds):
    r = client.post(f"{API}/datasets/{ds['id']}/ml/forecast", headers=auth_a, json={"metric": "revenue", "horizon": 6})
    assert r.status_code == 200, r.text
    f = r.json()
    assert len(f["forecast"]) == 6 and f["granularity"] == "month"
    assert {"mae", "rmse", "smape"} <= set(f["metrics"]["selected"])
    assert "naive" in f["metrics"]["all_models"]            # baseline always evaluated
    assert f["evaluation"]["method"] == "rolling-origin backtest"
    for p in f["forecast"]:
        assert p["lower"] <= p["value"] <= p["upper"]
    assert f["verdict"]
    # incomplete final month (data ends 30 Sep, complete) and all history periods are real data
    assert f["history"][-1]["date"] == "2026-09-01"


def test_forecast_rejects_insufficient_history(client, auth_a, tmp_path):
    from scripts.generate_sample_data import generate
    df = generate()
    short = df[df["Order Date"] < "2024-07-01"]
    p = tmp_path / "short.csv"
    short.to_csv(p, index=False)
    with open(p, "rb") as f:
        d = client.post(f"{API}/datasets", headers=auth_a, files={"file": ("short.csv", f, "text/csv")}).json()
    assert d["capabilities"]["forecast"]["available"] is False
    r = client.post(f"{API}/datasets/{d['id']}/ml/forecast", headers=auth_a, json={"metric": "revenue", "horizon": 3})
    assert r.status_code == 422 and "12 months" in r.json()["detail"]


def test_anomaly_detection_recovers_known_events(client, auth_a, ds):
    base = f"{API}/datasets/{ds['id']}/ml/anomalies"
    rev = client.get(base, params={"metric": "revenue", "granularity": "day"}, headers=auth_a).json()
    found = {a["date"]: a for a in rev["anomalies"]}
    assert found["2026-03-10"]["direction"] == "drop"        # injected outage is visible in revenue
    assert rev["anomaly_count"] < 0.05 * rev["points_checked"]  # does not flag everything
    # Revenue is lumpy (order values vary 1000x), so a 3x flash-sale day hides in revenue noise but is obvious in order counts.
    tx = client.get(base, params={"metric": "transactions", "granularity": "day"}, headers=auth_a).json()
    tfound = {a["date"]: a for a in tx["anomalies"]}
    assert tfound["2025-07-15"]["direction"] == "spike" and tfound["2026-03-10"]["direction"] == "drop"
    assert tx["anomaly_count"] < 0.05 * tx["points_checked"]


def test_segmentation(client, auth_a, ds):
    r = client.post(f"{API}/datasets/{ds['id']}/ml/segmentation", headers=auth_a)
    assert r.status_code == 200, r.text
    s = r.json()
    assert 2 <= s["k"] <= 6 and -1 <= s["silhouette"] <= 1
    assert sum(x["revenue_share_pct"] for x in s["segments"]) == pytest.approx(100, abs=0.01)


def test_models_are_registered(client, auth_a, ds):
    tasks = {m["task"] for m in client.get(f"{API}/datasets/{ds['id']}/ml/models", headers=auth_a).json()}
    assert {"forecast", "anomaly", "segmentation"} <= tasks


# ---------------- SQL guard ----------------
@pytest.mark.parametrize("sql", [
    "DROP TABLE data",
    "DELETE FROM data",
    "SELECT * FROM data; DROP TABLE data",
    "SELECT * FROM read_csv('/etc/passwd')",
    "SELECT * FROM read_parquet('/tmp/x.parquet')",
    "SELECT * FROM '/etc/passwd'",
    "COPY data TO '/tmp/out.csv'",
    "ATTACH '/tmp/x.db' AS x",
    "INSTALL httpfs",
    "PRAGMA database_list",
    "SELECT * FROM information_schema.tables",
    "SELECT * FROM duckdb_settings()",
    "SELECT * FROM other_table",
    "SELECT getenv('SECRET_KEY')",
    "SET enable_external_access=true",
    "CREATE TABLE x AS SELECT 1",
    "",
])
def test_sql_guard_blocks(sql):
    with pytest.raises(sql_guard.UnsafeSQL):
        sql_guard.validate_sql(sql)


def test_sql_guard_allows_analytics(sample_df):
    out = sql_guard.run_query(sample_df, 'SELECT "Region", SUM("Sales") AS s FROM data GROUP BY 1 ORDER BY 2 DESC')
    assert out["columns"] == ["Region", "s"]
    assert out["rows"][0][1] == pytest.approx(sample_df.groupby("Region")["Sales"].sum().max())
    cte = sql_guard.run_query(sample_df, 'WITH t AS (SELECT "Region", COUNT(*) c FROM data GROUP BY 1) SELECT * FROM t')
    assert cte["row_count"] == 5


def test_sql_guard_row_limit_and_errors(sample_df):
    out = sql_guard.run_query(sample_df, "SELECT * FROM data")
    assert out["truncated"] and out["row_count"] == sql_guard.MAX_ROWS
    with pytest.raises(sql_guard.UnsafeSQL):
        sql_guard.run_query(sample_df, "SELECT nonexistent_col FROM data")


# ---------------- simulation ----------------
def test_simulation_arithmetic(client, auth_a, ds):
    base = client.get(f"{API}/datasets/{ds['id']}/analytics/kpis", headers=auth_a).json()["current"]
    R, P = base["revenue"], base["profit"]
    C = R - P
    r = client.post(f"{API}/datasets/{ds['id']}/simulate", headers=auth_a, json={"price_change_pct": 10}).json()
    assert r["scenario"]["revenue"] == pytest.approx(R * 1.1)
    assert r["scenario"]["profit"] == pytest.approx(R * 1.1 - C)
    wf = r["waterfall"]
    assert sum(x["value"] for x in wf[:-1]) == pytest.approx(wf[-1]["value"])  # waterfall ties out exactly
    # volume +15% scales revenue and variable cost, so profit scales by 1.15
    v = client.post(f"{API}/datasets/{ds['id']}/simulate", headers=auth_a, json={"volume_change_pct": 15}).json()
    assert v["scenario"]["profit"] == pytest.approx(P * 1.15)
    # elasticity: +10% price with elasticity -1.5 cuts volume 15%
    e = client.post(f"{API}/datasets/{ds['id']}/simulate", headers=auth_a, json={"price_change_pct": 10, "price_elasticity": -1.5}).json()
    assert e["assumptions"]["effective_volume_change_pct"] == pytest.approx(-15)
    assert e["scenario"]["revenue"] == pytest.approx(R * 1.1 * 0.85)


def test_simulation_validation(client, auth_a, ds):
    assert client.post(f"{API}/datasets/{ds['id']}/simulate", headers=auth_a, json={"price_change_pct": -100}).status_code == 422
    assert client.post(f"{API}/datasets/{ds['id']}/simulate", headers=auth_a, json={"price_elasticity": 99}).status_code == 422


# ---------------- assistant (offline mode) ----------------
def _ask(client, auth, ds_id, q, cid=None):
    r = client.post(f"{API}/datasets/{ds_id}/chat", headers=auth, json={"message": q, "conversation_id": cid})
    assert r.status_code == 200, r.text
    return r.json()


def test_assistant_numbers_come_from_tools(client, auth_a, ds, sample_df):
    top = sample_df.groupby("Product")["Profit"].sum().idxmax()
    r = _ask(client, auth_a, ds["id"], "Which product generates the highest profit?")
    msg = r["message"]
    assert msg["mode"] == "offline" and msg["evidence"][0]["tool"] == "get_breakdown"
    assert top in msg["content"]
    ev_total = msg["evidence"][0]["result"]["total"]
    assert ev_total == pytest.approx(sample_df["Profit"].sum())


@pytest.mark.parametrize("q,tool", [
    ("Why did revenue decline last month?", "explain_change"),
    ("Predict next quarter's sales", "get_forecast"),
    ("What are the major business risks?", "get_alerts"),
    ("Which customer segment is most valuable?", "get_segments"),
    ("What if prices decrease by 10%?", "run_simulation"),
    ("What actions can improve profitability?", "get_breakdown"),
    ("Any unusual spikes?", "get_anomalies"),
])
def test_assistant_routes_to_tools(client, auth_a, ds, q, tool):
    r = _ask(client, auth_a, ds["id"], q)
    assert r["message"]["evidence"][0]["tool"] == tool
    assert "error" not in r["message"]["evidence"][0]["result"] or tool == "explain_change"


def test_assistant_history_and_isolation(client, auth_a, auth_b, ds):
    r = _ask(client, auth_a, ds["id"], "Give me a KPI overview")
    cid = r["conversation_id"]
    _ask(client, auth_a, ds["id"], "And by region?", cid)
    conv = client.get(f"{API}/conversations/{cid}", headers=auth_a).json()
    assert [m["role"] for m in conv["messages"]] == ["user", "assistant", "user", "assistant"]
    assert client.get(f"{API}/conversations/{cid}", headers=auth_b).status_code == 404


def test_assistant_resists_sql_via_tool(client, auth_a, ds):
    from app.services.assistant import run_tool
    from app.db import SessionLocal
    from app.models import Dataset
    with SessionLocal() as db:
        d = db.get(Dataset, ds["id"])
        out = run_tool(db, d, "run_sql", {"query": "SELECT * FROM read_csv('/etc/passwd')"})
    assert "error" in out


# ---------------- reports ----------------
def test_report_pdf_and_xlsx(client, auth_a, auth_b, ds):
    r = client.post(f"{API}/datasets/{ds['id']}/reports", headers=auth_a, json={"title": "Q3 Review", "date_from": "2026-07-01", "date_to": "2026-09-30"})
    assert r.status_code == 201, r.text
    rep = r.json()
    assert "Between 2026-07-01 and 2026-09-30" in rep["executive_summary"]
    pdf = client.get(f"{API}/reports/{rep['id']}/download", params={"format": "pdf"}, headers=auth_a)
    assert pdf.status_code == 200 and pdf.content[:4] == b"%PDF" and len(pdf.content) > 5000
    xl = client.get(f"{API}/reports/{rep['id']}/download", params={"format": "xlsx"}, headers=auth_a)
    assert xl.status_code == 200 and xl.content[:2] == b"PK"
    import io, openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(xl.content))
    assert {"Summary", "KPIs", "Alerts"} <= set(wb.sheetnames)
    assert client.get(f"{API}/reports/{rep['id']}/download", headers=auth_b).status_code == 404
    assert client.get(f"{API}/reports/{rep['id']}/download", params={"format": "exe"}, headers=auth_a).status_code == 422


def test_xlsx_formula_injection_neutralised():
    from app.services.reports import _safe
    assert _safe("=HYPERLINK(\"http://evil\")").startswith("'") and _safe("+cmd") == "'+cmd" and _safe("normal") == "normal"


# ---------------- alerts & deletion ----------------
def test_alerts_from_real_data(client, auth_a, ds):
    alerts = client.get(f"{API}/datasets/{ds['id']}/alerts", headers=auth_a).json()
    assert alerts == [] or all(a["message"] for a in alerts)
    assert client.post(f"{API}/datasets/{ds['id']}/alerts/refresh", headers=auth_a).status_code == 200


def test_delete_dataset_removes_files(client, auth_a, tmp_path):
    from pathlib import Path
    p = tmp_path / "d.csv"
    p.write_text("Date,Sales\n" + "\n".join(f"2024-01-{i:02d},{i * 10}" for i in range(1, 29)))
    with open(p, "rb") as f:
        d = client.post(f"{API}/datasets", headers=auth_a, files={"file": ("d.csv", f, "text/csv")}).json()
    from app.db import SessionLocal
    from app.models import Dataset
    with SessionLocal() as db:
        folder = Path(db.get(Dataset, d["id"]).raw_path).parent
    assert folder.exists()
    assert client.delete(f"{API}/datasets/{d['id']}", headers=auth_a).status_code == 204
    assert not folder.exists()


# ---------------- regressions found in live smoke test ----------------
def test_forecast_evaluates_seasonal_model_on_same_folds(client, auth_a, ds):
    f = client.post(f"{API}/datasets/{ds['id']}/ml/forecast", headers=auth_a, json={"metric": "revenue", "horizon": 6}).json()
    assert "ets_seasonal" in f["metrics"]["all_models"], f["warnings"]   # 33 months of history supports a seasonal model
    assert all(m["folds"] == f["evaluation"]["folds"] for m in f["metrics"]["all_models"].values())  # fair comparison


def test_explain_defaults_to_recent_window(client, auth_a, ds):
    r = client.get(f"{API}/datasets/{ds['id']}/analytics/explain", headers=auth_a)
    assert r.status_code == 200, r.text
    assert r.json()["period"]["to"] == "2026-09-30" and r.json()["period"]["days"] == 90
    chat = _ask(client, auth_a, ds["id"], "Why did revenue change in the latest period?")
    assert "error" not in chat["message"]["evidence"][0]["result"]


def test_revenue_decline_alert_fires(client, auth_a, tmp_path, sample_df):
    df = sample_df.copy()
    late = df["Order Date"] >= "2026-07-03"
    df.loc[late, ["Sales", "Cost", "Profit"]] *= 0.5   # last 90 days at half the prior level
    p = tmp_path / "decline.csv"
    df.to_csv(p, index=False)
    with open(p, "rb") as f:
        d = client.post(f"{API}/datasets", headers=auth_a, files={"file": ("decline.csv", f, "text/csv")}).json()
    alerts = client.get(f"{API}/datasets/{d['id']}/alerts", headers=auth_a).json()
    assert any(a["rule_type"] == "revenue_decline" and a["severity"] == "critical" for a in alerts), alerts
