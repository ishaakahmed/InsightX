import math
from datetime import date, datetime

import numpy as np
import pandas as pd


def jsonable(o):
    """Recursively convert numpy/pandas values to JSON-safe Python (NaN/inf -> None)."""
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating, float)):
        f = float(o)
        return None if math.isnan(f) or math.isinf(f) else f
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, (pd.Timestamp, datetime, date)):
        return None if pd.isna(o) else o.isoformat()[:10] if isinstance(o, date) and not isinstance(o, datetime) else pd.Timestamp(o).isoformat()
    if o is pd.NaT:
        return None
    return o


def pct_change(cur: float | None, prev: float | None) -> float | None:
    if cur is None or prev is None or prev == 0 or pd.isna(cur) or pd.isna(prev):
        return None
    return float((cur - prev) / abs(prev) * 100)
