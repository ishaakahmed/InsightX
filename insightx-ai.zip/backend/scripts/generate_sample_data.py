"""Generates a SYNTHETIC but realistic retail transactions dataset for demos and tests.
Seasonality, growth, regional mix and two known anomalies are built in so that analytics can be validated against known truth.
Not real business data."""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def generate(seed: int = 7, messy: bool = False) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    days = pd.date_range("2024-01-01", "2026-09-30", freq="D")
    products = {
        "Furniture": [("Ergo Office Chair", 220, .55), ("Standing Desk", 480, .6), ("Bookshelf", 130, .62), ("Filing Cabinet", 150, .7), ("Desk Lamp", 45, .5), ("Conference Table", 900, .72)],
        "Technology": [("Laptop 14in", 850, .82), ("Wireless Mouse", 25, .45), ("Monitor 27in", 310, .78), ("Mechanical Keyboard", 95, .55), ("Webcam HD", 60, .6), ("USB-C Dock", 120, .68)],
        "Office Supplies": [("Notebook Pack", 12, .4), ("Gel Pens Box", 9, .35), ("Printer Paper Ream", 6, .8), ("Stapler", 15, .5), ("Whiteboard", 70, .6), ("Label Printer", 85, .65)],
        "Apparel": [("Branded Hoodie", 48, .45), ("Polo Shirt", 28, .4), ("Cap", 15, .38), ("Jacket", 95, .5), ("Tote Bag", 14, .35), ("Sneakers", 85, .58)],
    }
    flat = [(c, n, p, k) for c, items in products.items() for n, p, k in items]
    regions = ["North", "South", "East", "West", "Central"]
    region_w = np.array([.24, .27, .16, .23, .10])
    customers = [f"C{10000 + i}" for i in range(1800)]
    cust_w = rng.pareto(1.6, len(customers)) + 1
    cust_w /= cust_w.sum()
    rows = []
    oid = 100000
    for d in days:
        t = (d - days[0]).days / 365
        season = 1 + 0.35 * (d.month in (11, 12)) + 0.12 * (d.month in (3, 4)) - 0.12 * (d.month in (6, 7))
        dow = 0.8 if d.dayofweek >= 5 else 1.05
        lam = 17 * (1 + 0.14 * t) * season * dow
        if d == pd.Timestamp("2025-07-15"):
            lam *= 3.2   # flash-sale spike (known anomaly)
        if d == pd.Timestamp("2026-03-10"):
            lam *= 0.08  # outage (known anomaly)
        n = rng.poisson(lam)
        for _ in range(n):
            w = region_w.copy()
            if d >= pd.Timestamp("2026-08-01"):
                w[3] *= 0.55  # West declines in the last two months (root-cause demo)
            w = w / w.sum()
            region = rng.choice(regions, p=w)
            cat, name, price, cost_ratio = flat[rng.integers(len(flat))]
            qty = int(rng.choice([1, 1, 1, 2, 2, 3, 5, 10], p=[.3, .2, .15, .12, .1, .06, .04, .03]))
            disc = float(rng.choice([0, 0, 0, .05, .1, .2], p=[.5, .15, .1, .1, .1, .05]))
            unit = round(price * (1 + 0.03 * t) * rng.normal(1, .03), 2)
            sales = round(qty * unit * (1 - disc), 2)
            cost = round(qty * price * cost_ratio * rng.normal(1, .02), 2)
            rows.append((oid, d.strftime("%Y-%m-%d"), rng.choice(customers, p=cust_w), region, cat, name, qty, unit, disc, sales, cost, round(sales - cost, 2)))
            oid += 1
    df = pd.DataFrame(rows, columns=["Order ID", "Order Date", "Customer ID", "Region", "Category", "Product", "Quantity", "Unit Price", "Discount", "Sales", "Cost", "Profit"])
    if messy:
        idx = rng.choice(len(df), int(len(df) * .03), replace=False)
        df.loc[idx[: len(idx) // 2], "Region"] = None
        df.loc[idx[len(idx) // 2:], "Quantity"] = None
        df = pd.concat([df, df.sample(150, random_state=1)], ignore_index=True)
        df["Sales"] = df["Sales"].map(lambda v: f"${v:,.2f}")
        df["Region"] = df["Region"].map(lambda v: v if v is None or rng.random() > .05 else f"  {v} ")
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="sample_data")
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(exist_ok=True)
    generate().to_csv(out / "retail_sales.csv", index=False)
    generate(messy=True).to_csv(out / "retail_sales_messy.csv", index=False)
    print("written", [p.name for p in out.iterdir()])
