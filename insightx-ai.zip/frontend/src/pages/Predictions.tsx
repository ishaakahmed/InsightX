import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../lib/api";
import { useDataset } from "../lib/dataset";
import { compact, num, pct } from "../lib/format";
import { Chart } from "../components/Chart";
import { ErrorBox, NoDataset, PageHeader, Section, Skeleton, Tabs, Unavailable } from "../components/ui";
import { cssVar } from "../lib/theme";

const NAMES: Record<string, string> = { naive: "Naive (last value)", seasonal_naive: "Seasonal naive", ets_level: "Exponential smoothing", ets_trend: "Damped trend", ets_seasonal: "Seasonal exp. smoothing" };

function Forecast({ id, caps }: { id: string; caps: any }) {
  const qc = useQueryClient(); const [metric, setMetric] = useState("revenue"); const [horizon, setHorizon] = useState(6); const [gran, setGran] = useState("month");
  const latest = useQuery({ queryKey: ["fc-latest", id], queryFn: () => api(`/datasets/${id}/ml/forecast/latest`), retry: false });
  const run = useMutation({ mutationFn: () => api(`/datasets/${id}/ml/forecast`, { method: "POST", body: { metric, horizon, granularity: gran } }), onSuccess: (d) => qc.setQueryData(["fc-latest", id], d) });
  const f = run.data ?? latest.data;
  const opt = (b: any) => {
    const hist = f.history.slice(-36); const fc = f.forecast; const x = [...hist.map((p: any) => p.date), ...fc.map((p: any) => p.date)]; const pad = (n: number) => Array(n).fill(null);
    const warn = cssVar("--warn"); const acc = cssVar("--accent");
    return { ...b, legend: { top: 0, right: 0, textStyle: { color: b.textStyle.color } }, xAxis: { ...b.xAxis, type: "category", data: x }, yAxis: { ...b.yAxis, type: "value", axisLabel: { ...b.yAxis.axisLabel, formatter: (v: number) => compact(v) } },
      series: [
        { name: "Actual", type: "line", showSymbol: false, lineStyle: { width: 2 }, data: [...hist.map((p: any) => p.value), ...pad(fc.length)] },
        { name: "Backtest", type: "line", showSymbol: true, symbolSize: 5, lineStyle: { type: "dotted", width: 1.5, color: acc }, itemStyle: { color: acc }, data: x.map((d) => f.backtest.find((p: any) => p.date === d)?.predicted ?? null), connectNulls: false },
        { name: "Lower", type: "line", stack: "band", showSymbol: false, lineStyle: { opacity: 0 }, data: [...pad(hist.length), ...fc.map((p: any) => p.lower)], tooltip: { show: false } },
        { name: "80% interval", type: "line", stack: "band", showSymbol: false, lineStyle: { opacity: 0 }, areaStyle: { color: warn, opacity: 0.18 }, data: [...pad(hist.length), ...fc.map((p: any) => p.upper - p.lower)] },
        { name: "Forecast", type: "line", showSymbol: true, symbolSize: 5, lineStyle: { type: "dashed", width: 2, color: warn }, itemStyle: { color: warn }, data: [...pad(hist.length - 1), hist[hist.length - 1].value, ...fc.map((p: any) => p.value)] },
      ] };
  };
  const models = f ? Object.entries(f.metrics.all_models as Record<string, any>).sort((a, b) => a[1].mae - b[1].mae) : [];
  return (
    <div className="space-y-4">
      <Section title="Sales forecast" sub="Models are scored by rolling-origin backtests and always compared with naive baselines">
        <div className="flex flex-wrap items-end gap-3">
          <label className="text-sm"><span className="mb-1 block text-muted">Metric</span><select className="input !w-auto" value={metric} onChange={(e) => setMetric(e.target.value)}><option value="revenue">Revenue</option>{caps.profit.available && <option value="profit">Profit</option>}<option value="quantity">Quantity</option></select></label>
          <label className="text-sm"><span className="mb-1 block text-muted">Periods</span><select className="input !w-auto" value={gran} onChange={(e) => setGran(e.target.value)}><option value="month">Months</option><option value="week">Weeks</option></select></label>
          <label className="text-sm"><span className="mb-1 block text-muted">Horizon</span><input type="number" min={1} max={24} className="input !w-24" value={horizon} onChange={(e) => setHorizon(Math.min(24, Math.max(1, +e.target.value || 1)))} /></label>
          <button className="btn-primary" disabled={run.isPending} onClick={() => run.mutate()}>{run.isPending ? "Training and evaluating…" : f ? "Re-run forecast" : "Run forecast"}</button>
        </div>
        {run.isError && <p role="alert" className="mt-3 text-sm text-down">{(run.error as Error).message}</p>}
      </Section>
      {latest.isLoading && !f ? <Skeleton h={320} /> : f && <>
        <Section title={`${f.metric} forecast`} sub={`${NAMES[f.model] ?? f.model} · next ${f.horizon} ${f.granularity}s · total ${compact(f.total_forecast)}`}><Chart height={340} label="Actual, backtest and forecast with 80% interval" option={opt} /></Section>
        <div className="grid gap-4 lg:grid-cols-3">
          <Section title="Verdict"><p className="text-sm">{f.verdict}</p>
            <dl className="mt-4 space-y-2 text-sm">{[["MAE", num(f.metrics.selected.mae)], ["RMSE", num(f.metrics.selected.rmse)], ["sMAPE", pct(f.metrics.selected.smape)], ["Backtest folds", String(f.evaluation.folds)], ["Backtest horizon", `${f.evaluation.horizon} ${f.granularity}s`]].map(([k, v]) => <div key={k} className="flex justify-between"><dt className="text-muted">{k}</dt><dd className="num font-medium">{v}</dd></div>)}</dl>
            {f.warnings?.length > 0 && <ul className="mt-3 space-y-1 text-xs text-warn">{f.warnings.map((w: string) => <li key={w}>{w}</li>)}</ul>}</Section>
          <Section className="lg:col-span-2" title="Model comparison" sub="Lower error is better. Baselines are the bar any model must beat."><table className="w-full"><thead><tr className="border-b border-line"><th className="th">Model</th><th className="th text-right">MAE</th><th className="th text-right">RMSE</th><th className="th text-right">sMAPE</th><th className="th" /></tr></thead>
            <tbody>{models.map(([k, m]) => <tr key={k} className="border-b border-line last:border-0"><td className="td font-medium">{NAMES[k] ?? k}{k.includes("naive") && <span className="ml-2 text-xs text-muted">baseline</span>}</td><td className="td num text-right">{num(m.mae)}</td><td className="td num text-right">{num(m.rmse)}</td><td className="td num text-right">{pct(m.smape)}</td><td className="td">{k === f.model && <span className="rounded-full bg-accent/10 px-2 py-0.5 text-xs font-medium text-accent">selected</span>}</td></tr>)}</tbody></table></Section>
        </div>
        <Section title="Forecast values"><div className="overflow-x-auto"><table className="w-full"><thead><tr className="border-b border-line"><th className="th">Period</th><th className="th text-right">Forecast</th><th className="th text-right">Lower (80%)</th><th className="th text-right">Upper (80%)</th></tr></thead><tbody>{f.forecast.map((p: any) => <tr key={p.date} className="border-b border-line last:border-0"><td className="td">{p.date}</td><td className="td num text-right font-medium">{num(p.value)}</td><td className="td num text-right text-muted">{num(p.lower)}</td><td className="td num text-right text-muted">{num(p.upper)}</td></tr>)}</tbody></table></div></Section></>}
    </div>);
}

function Anomalies({ id }: { id: string }) {
  const [metric, setMetric] = useState("revenue"); const [g, setG] = useState("day");
  const q = useQuery({ queryKey: ["anom", id, metric, g], queryFn: () => api(`/datasets/${id}/ml/anomalies`, { params: { metric, granularity: g } }) });
  const opt = (b: any) => { const flagged = new Map(q.data.anomalies.map((a: any) => [a.date, a])); return { ...b, xAxis: { ...b.xAxis, type: "category", data: q.data.series.map((p: any) => p.date) }, yAxis: { ...b.yAxis, type: "value", axisLabel: { ...b.yAxis.axisLabel, formatter: (v: number) => compact(v) } }, dataZoom: [{ type: "inside" }],
    series: [{ type: "line", showSymbol: false, lineStyle: { width: 1.2 }, data: q.data.series.map((p: any) => p.value) }, { type: "scatter", symbolSize: 9, itemStyle: { color: cssVar("--down") }, data: q.data.series.map((p: any) => (flagged.has(p.date) ? p.value : null)) }] }; };
  return <div className="space-y-4"><Section title="Anomaly detection" sub={q.data?.method} right={<div className="flex gap-2"><select aria-label="Metric" className="input !w-auto !py-1" value={metric} onChange={(e) => setMetric(e.target.value)}><option value="revenue">Revenue</option><option value="transactions">Transactions</option><option value="quantity">Quantity</option></select>
    <select aria-label="Granularity" className="input !w-auto !py-1" value={g} onChange={(e) => setG(e.target.value)}><option value="day">Daily</option><option value="week">Weekly</option><option value="month">Monthly</option></select></div>}>
    {q.isLoading ? <Skeleton h={300} /> : q.isError ? <ErrorBox error={q.error} retry={() => q.refetch()} /> : <><Chart height={300} label="Series with anomalies marked" option={opt} /><p className="mt-2 text-xs text-muted">{q.data.anomaly_count} of {num(q.data.points_checked)} periods flagged. {q.data.note}</p></>}</Section>
    {q.data?.anomalies.length > 0 && <Section title="Flagged periods"><div className="overflow-x-auto"><table className="w-full"><thead><tr className="border-b border-line">{["Date", "Direction", "Actual", "Expected", "Score", "Severity"].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead><tbody>{q.data.anomalies.slice(0, 15).map((a: any) => <tr key={a.date} className="border-b border-line last:border-0"><td className="td">{a.date}</td><td className={`td ${a.direction === "drop" ? "text-down" : "text-up"}`}>{a.direction}</td><td className="td num">{num(a.value)}</td><td className="td num text-muted">{num(a.expected)}</td><td className="td num">{a.z_score.toFixed(1)}</td><td className="td">{a.severity}</td></tr>)}</tbody></table></div></Section>}</div>;
}

function Segments({ id }: { id: string }) {
  const q = useQuery({ queryKey: ["seg", id], queryFn: () => api(`/datasets/${id}/ml/segmentation`, { method: "POST" }) });
  if (q.isLoading) return <Skeleton h={260} />; if (q.isError) return <ErrorBox error={q.error} retry={() => q.refetch()} />;
  const d = q.data;
  return <Section title="Customer segments" sub={`${d.k} segments · silhouette ${d.silhouette.toFixed(2)} · ${num(d.customers_scored)} customers`}><div className="overflow-x-auto"><table className="w-full"><thead><tr className="border-b border-line">{["Segment", "Customers", "Revenue share", "Avg spend", "Avg orders", "Days since last order"].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
    <tbody>{d.segments.map((s: any) => <tr key={s.segment} className="border-b border-line last:border-0"><td className="td font-medium">{s.name} <span className="font-normal text-muted">· {s.descriptor}</span></td><td className="td num">{pct(s.share_customers_pct)}</td><td className="td num">{pct(s.revenue_share_pct)}</td><td className="td num">{num(s.avg_monetary)}</td><td className="td num">{num(s.avg_frequency, 1)}</td><td className="td num">{num(s.avg_recency_days)}</td></tr>)}</tbody></table></div><p className="mt-3 text-xs text-muted">{d.method}</p></Section>;
}

export default function Predictions() {
  const { current, detail } = useDataset(); const [tab, setTab] = useState("Forecast");
  if (!current) return <NoDataset />; if (!detail) return <Skeleton h={200} />;
  const caps = detail.capabilities;
  return <><PageHeader title="Predictions" sub="Statistical models trained and evaluated on your data" />
    <Tabs tabs={["Forecast", "Anomalies", "Segments", "Churn"]} value={tab} onChange={setTab} />
    {tab === "Forecast" && (caps.forecast.available ? <Forecast id={current.id} caps={caps} /> : <Unavailable reason={caps.forecast.reason} />)}
    {tab === "Anomalies" && (caps.anomalies.available ? <Anomalies id={current.id} /> : <Unavailable reason={caps.anomalies.reason} />)}
    {tab === "Segments" && (caps.segmentation.available ? <Segments id={current.id} /> : <Unavailable reason={caps.segmentation.reason} />)}
    {tab === "Churn" && <div className="panel p-6 text-sm"><p className="font-medium">Churn prediction is not built yet</p><p className="mt-1 text-muted">It needs a labelled churn column or an agreed churn definition, plus time-based validation. It is planned after the core platform is stable.</p></div>}</>;
}
