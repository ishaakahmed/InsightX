import shutil
import uuid
from pathlib import Path

import pandas as pd
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models import (Alert, CleaningOperation, Conversation, Dataset, DatasetColumn, MLModel, Report, Simulation, User)
from app.services import alerts as alert_svc
from app.services import ingestion as I

SINGLETON_ROLES = {"date", "revenue", "cost", "profit", "quantity", "price", "customer_id", "order_id", "product", "region", "category"}
NUMERIC_ROLES = {"revenue", "cost", "profit", "quantity", "price"}


def dataset_dir(user_id: str, dataset_id: str) -> Path:
    return get_settings().storage_dir / user_id / dataset_id


def _id_columns_to_string(df: pd.DataFrame, roles: dict[str, str]) -> pd.DataFrame:
    for c, r in roles.items():
        if r in ("customer_id", "order_id") and pd.api.types.is_numeric_dtype(df[c]):
            df[c] = df[c].map(lambda v: None if pd.isna(v) else str(int(v)) if float(v).is_integer() else str(v))
    return df


def create_dataset(db: Session, user: User, name: str, filename: str, ext: str, raw_path: Path, size: int, ds_id: str) -> Dataset:
    df = I.load_raw(raw_path, ext)
    df = I.normalize_columns(df)
    df, types, consistency = I.infer_and_cast(df)
    roles = I.infer_roles(df, types)
    df = _id_columns_to_string(df, roles)
    for c, r in roles.items():
        if r in ("customer_id", "order_id") and types[c] in ("integer", "float"):
            types[c] = "category"
    profile, _, score = I.profile_frame(df, types, consistency)
    parquet = raw_path.parent / "data.parquet"
    df.to_parquet(parquet, index=False)
    ds = Dataset(id=ds_id, user_id=user.id, name=name, original_filename=filename[:300], file_type=ext, size_bytes=size,
                 raw_path=str(raw_path), parquet_path=str(parquet), row_count=len(df), column_count=df.shape[1],
                 status="ready", quality_score=score, profile=profile)
    for i, c in enumerate(df.columns):
        ds.columns.append(DatasetColumn(name=c, position=i, inferred_type=types[c], semantic_role=roles[c], stats=profile["columns_detail"][c]))
    ds.capabilities = I.compute_capabilities(df, roles)
    db.add(ds)
    db.commit()
    alert_svc.generate_alerts(db, ds)
    return ds


def reanalyze(db: Session, ds: Dataset, df: pd.DataFrame) -> None:
    """Re-profile after cleaning or role changes. Keeps user-confirmed roles."""
    types = {c.name: c.inferred_type for c in ds.columns if c.name in df.columns}
    ds.columns[:] = [c for c in ds.columns if c.name in df.columns]
    profile, _, score = I.profile_frame(df, types, {})
    for c in ds.columns:
        c.stats = profile["columns_detail"][c.name]
    roles = {c.name: c.semantic_role for c in ds.columns}
    ds.profile, ds.quality_score, ds.row_count, ds.column_count = profile, score, len(df), df.shape[1]
    ds.capabilities = I.compute_capabilities(df, roles)
    db.commit()
    alert_svc.generate_alerts(db, ds)


def delete_dataset(db: Session, ds: Dataset) -> None:
    for model in (Alert, CleaningOperation, MLModel, Simulation, Report):
        db.query(model).filter(model.dataset_id == ds.id).delete()
    for conv in db.query(Conversation).filter(Conversation.dataset_id == ds.id).all():
        db.delete(conv)
    db.delete(ds)
    db.commit()
    shutil.rmtree(Path(ds.raw_path).parent, ignore_errors=True)


def new_id() -> str:
    return str(uuid.uuid4())
