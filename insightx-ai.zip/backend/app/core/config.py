from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "InsightX AI"
    environment: str = "development"
    # SQLite for zero-setup local dev; Postgres in Docker/production via DATABASE_URL.
    database_url: str = "sqlite:///./insightx.db"
    storage_dir: Path = Path("./storage")
    secret_key: str = "dev-only-change-me-please-use-32+chars"
    access_token_minutes: int = 15
    refresh_token_days: int = 14
    cookie_secure: bool = False
    cors_origins: str = "http://localhost:5173"
    max_upload_mb: int = 50
    max_columns: int = 400
    max_rows: int = 2_000_000
    # AI is optional: without a key the analyst runs in deterministic offline mode.
    anthropic_api_key: str = ""
    llm_model: str = "claude-sonnet-4-6"
    llm_send_row_samples: bool = False


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    s.storage_dir.mkdir(parents=True, exist_ok=True)
    if s.environment == "production" and s.secret_key.startswith("dev-only"):
        raise RuntimeError("SECRET_KEY must be set in production")
    return s
