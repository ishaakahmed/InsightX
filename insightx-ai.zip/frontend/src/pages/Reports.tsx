import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { FileSpreadsheet, FileText } from "lucide-react";
import { api, download } from "../lib/api";
import { useDataset } from "../lib/dataset";
import { ErrorBox, NoDataset, PageHeader, Section, Skeleton, Unavailable } from "../components/ui";

export default function Reports() {
  const { current, detail } = useDataset(); const qc = useQueryClient(); const id = current?.id;
  const [title, setTitle] = useState("Business performance report"); const [from, setFrom] = useState(""); const [to, setTo] = useState(""); const [dlErr, setDlErr] = useState("");
  const list = useQuery({ queryKey: ["reports", id], queryFn: () => api<any[]>(`/datasets/${id}/reports`), enabled: !!id });
  const make = useMutation({ mutationFn: () => api(`/datasets/${id}/reports`, { method: "POST", body: { title, date_from: from || null, date_to: to || null } }), onSuccess: () => qc.invalidateQueries({ queryKey: ["reports", id] }) });
  if (!current) return <NoDataset />; if (!detail) return <Skeleton h={200} />;
  if (!detail.capabilities.kpis.available) return <><PageHeader title="Reports" /><Unavailable reason={detail.capabilities.kpis.reason} /></>;
  const dl = async (rid: string, fmt: string, t: string) => { setDlErr(""); try { await download(`/reports/${rid}/download?format=${fmt}`, `${t}.${fmt}`); } catch (e) { setDlErr((e as Error).message); } };
  return (
    <>
      <PageHeader title="Reports" sub="Executive summary, KPIs, trends, breakdowns, forecast and alerts, exported as PDF and Excel." />
      <div className="grid gap-4 lg:grid-cols-[22rem_1fr]">
        <Section title="New report"><div className="space-y-3">
          <div><label htmlFor="t" className="mb-1 block text-sm font-medium">Title</label><input id="t" className="input" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} /></div>
          <div className="grid grid-cols-2 gap-2"><div><label htmlFor="f" className="mb-1 block text-sm font-medium">From</label><input id="f" type="date" className="input" min={detail.date_range?.min} max={detail.date_range?.max} value={from} onChange={(e) => setFrom(e.target.value)} /></div>
            <div><label htmlFor="to" className="mb-1 block text-sm font-medium">To</label><input id="to" type="date" className="input" min={detail.date_range?.min} max={detail.date_range?.max} value={to} onChange={(e) => setTo(e.target.value)} /></div></div>
          <p className="text-xs text-muted">Leave dates empty to cover all data. KPIs are compared with the previous period of equal length. The summary text is generated from the computed numbers.</p>
          <button className="btn-primary w-full" disabled={make.isPending || !title.trim()} onClick={() => make.mutate()}>{make.isPending ? "Generating…" : "Generate report"}</button>
          {make.isError && <p role="alert" className="text-sm text-down">{(make.error as Error).message}</p>}</div></Section>
        <Section title="Generated reports">
          {list.isLoading ? <Skeleton h={120} /> : list.isError ? <ErrorBox error={list.error} /> : list.data?.length ? <ul className="divide-y divide-line">{list.data.map((r) => <li key={r.id} className="py-3"><div className="flex flex-wrap items-center justify-between gap-2"><div><p className="font-medium">{r.title}</p><p className="text-xs text-muted">{new Date(r.created_at).toLocaleString()} · {r.date_from ?? "start"} to {r.date_to ?? "end"}</p></div>
            <div className="flex gap-2"><button className="btn-ghost" onClick={() => dl(r.id, "pdf", r.title)}><FileText className="h-4 w-4" />PDF</button><button className="btn-ghost" onClick={() => dl(r.id, "xlsx", r.title)}><FileSpreadsheet className="h-4 w-4" />Excel</button></div></div>
            <p className="mt-2 text-sm text-muted">{r.executive_summary}</p></li>)}</ul> : <p className="text-sm text-muted">No reports yet. Generate one to see it here.</p>}
          {dlErr && <p role="alert" className="mt-2 text-sm text-down">{dlErr}</p>}</Section>
      </div>
    </>);
}
