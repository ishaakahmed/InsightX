from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.db import get_db
from app.deps import current_user, owned_dataset
from app.models import Conversation, Dataset, Message, User
from app.services import assistant as svc

router = APIRouter(tags=["assistant"])


class ChatBody(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    conversation_id: str | None = None


def _msg(m: Message) -> dict:
    return {"id": m.id, "role": m.role, "content": m.content, "evidence": m.evidence, "mode": m.mode, "created_at": m.created_at.isoformat()}


@router.post("/datasets/{dataset_id}/chat")
def chat(body: ChatBody, ds: Dataset = Depends(owned_dataset), user: User = Depends(current_user), db: Session = Depends(get_db)):
    conv = None
    if body.conversation_id:
        conv = db.get(Conversation, body.conversation_id)
        if not conv or conv.user_id != user.id or conv.dataset_id != ds.id:
            raise HTTPException(404, "Conversation not found")
    if not conv:
        conv = Conversation(user_id=user.id, dataset_id=ds.id, title=body.message[:80])
        db.add(conv)
        db.commit()
    history = [{"role": m.role, "content": m.content} for m in conv.messages]
    db.add(Message(conversation_id=conv.id, role="user", content=body.message))
    db.commit()
    result = svc.answer(db, ds, history, body.message)
    reply = Message(conversation_id=conv.id, role="assistant", content=result["content"], evidence=result["evidence"], mode=result["mode"])
    db.add(reply)
    db.commit()
    return {"conversation_id": conv.id, "message": _msg(reply)}


@router.get("/datasets/{dataset_id}/conversations")
def conversations(ds: Dataset = Depends(owned_dataset), user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(Conversation).filter(Conversation.dataset_id == ds.id, Conversation.user_id == user.id).order_by(Conversation.updated_at.desc()).limit(50).all()
    return [{"id": c.id, "title": c.title, "updated_at": c.updated_at.isoformat()} for c in rows]


@router.get("/conversations/{cid}")
def get_conversation(cid: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    c = db.get(Conversation, cid)
    if not c or c.user_id != user.id:
        raise HTTPException(404, "Conversation not found")
    return {"id": c.id, "title": c.title, "messages": [_msg(m) for m in c.messages]}


@router.delete("/conversations/{cid}", status_code=204)
def delete_conversation(cid: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    c = db.get(Conversation, cid)
    if not c or c.user_id != user.id:
        raise HTTPException(404, "Conversation not found")
    db.delete(c)
    db.commit()
