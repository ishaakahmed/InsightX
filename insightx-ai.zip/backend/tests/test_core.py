import io

import pandas as pd
import pytest

from tests.conftest import H

API = "/api/v1"


# ---------------- auth ----------------
def test_register_validation_and_login(client):
    assert client.post(f"{API}/auth/register", json={"email": "x@example.com", "password": "short"}).status_code == 422
    assert client.post(f"{API}/auth/register", json={"email": "x@example.com", "password": "alllowercase123"}).status_code == 422
    r = client.post(f"{API}/auth/register", json={"email": "login@example.com", "password": "Str0ngPassw0rd!"})
    assert r.status_code == 201 and "insightx_refresh" in r.cookies
    assert client.post(f"{API}/auth/register", json={"email": "login@example.com", "password": "Str0ngPassw0rd!"}).status_code == 409
    assert client.post(f"{API}/auth/login", json={"email": "login@example.com", "password": "wrongPassw0rd!"}).status_code == 401
    assert client.post(f"{API}/auth/login", json={"email": "login@example.com", "password": "Str0ngPassw0rd!"}).status_code == 200


def test_protected_routes_need_token(client):
    assert client.get(f"{API}/datasets").status_code == 401
    assert client.get(f"{API}/auth/me", headers={"Authorization": "Bearer garbage"}).status_code == 401


def test_refresh_rotation_and_csrf(client):
    c = client.__class__(client.app)
    r = c.post(f"{API}/auth/register", json={"email": "rot@example.com", "password": "Str0ngPassw0rd!"})
    old = r.cookies["insightx_refresh"]
    c.cookies.clear()
    assert c.post(f"{API}/auth/refresh", headers={"Cookie": f"insightx_refresh={old}"}).status_code == 403  # missing CSRF header
    ok = c.post(f"{API}/auth/refresh", headers={**H, "Cookie": f"insightx_refresh={old}"})
    assert ok.status_code == 200
    c.cookies.clear()
    assert c.post(f"{API}/auth/refresh", headers={**H, "Cookie": f"insightx_refresh={old}"}).status_code == 401  # reuse of a rotated token fails


def test_account_lockout(client):
    client.post(f"{API}/auth/register", json={"email": "lock@example.com", "password": "Str0ngPassw0rd!"})
    for _ in range(5):
        client.post(f"{API}/auth/login", json={"email": "lock@example.com", "password": "nope-Nope-123"})
    assert client.post(f"{API}/auth/login", json={"email": "lock@example.com", "password": "Str0ngPassw0rd!"}).status_code == 429


# ---------------- upload & ingestion ----------------
def test_upload_rejections(client, auth_a):
    def up(name, data):
        return client.post(f"{API}/datasets", headers=auth_a, files={"file": (name, io.BytesIO(data), "application/octet-stream")})
    assert up("evil.exe", b"MZ....").status_code == 400
    assert up("fake.xlsx", b"this is not a zip").status_code == 400
    assert up("empty.csv", b"").status_code == 400
    assert up("bin.csv", b"a,b\n\x00\x01\x02").status_code == 400
    assert up("headeronly.csv", b"a,b,c\n").status_code == 400
    assert up("../../etc/passwd.csv", b"a,b\n1,2\n3,4\n").status_code == 201  # path traversal in filename is harmless


def test_roles_detected(ds):
    roles = {c["name"]: c["role"] for c in ds["columns_detail"]}
    assert roles["Order Date"] == "date" and roles["Sales"] == "revenue" and roles["Cost"] == "cost"
    assert roles["Profit"] == "profit" and roles["Quantity"] == "quantity" and roles["Customer ID"] == "customer_id"
    assert roles["Product"] == "product" and roles["Region"] == "region" and roles["Category"] == "category" and roles["Order ID"] == "order_id"
    assert ds["capabilities"]["forecast"]["available"] and not ds["capabilities"]["churn"]["available"]


def test_idor_blocked(client, auth_b, ds):
    i = ds["id"]
    for path in (f"datasets/{i}", f"datasets/{i}/profile", f"datasets/{i}/preview", f"datasets/{i}/analytics/kpis", f"datasets/{i}/alerts", f"datasets/{i}/conversations"):
        assert client.get(f"{API}/{path}", headers=auth_b).status_code == 404, path
    assert client.delete(f"{API}/datasets/{i}", headers=auth_b).status_code == 404
    assert client.post(f"{API}/datasets/{i}/chat", headers=auth_b, json={"message": "hi"}).status_code == 404
    assert client.get(f"{API}/datasets", headers=auth_b).json() == [] or all(d["id"] != i for d in client.get(f"{API}/datasets", headers=auth_b).json())


# ---------------- analytics correctness vs pandas reference ----------------
def test_kpis_match_pandas(client, auth_a, ds, sample_df):
    k = client.get(f"{API}/datasets/{ds['id']}/analytics/kpis", headers=auth_a).json()
    cur = k["current"]
    assert cur["revenue"] == pytest.approx(sample_df["Sales"].sum(), rel=1e-9)
    assert cur["profit"] == pytest.approx(sample_df["Profit"].sum(), rel=1e-9)
    assert cur["transactions"] == sample_df["Order ID"].nunique()
    assert cur["customers"] == sample_df["Customer ID"].nunique()
    assert cur["margin_pct"] == pytest.approx(sample_df["Profit"].sum() / sample_df["Sales"].sum() * 100)


def test_period_comparison(client, auth_a, ds, sample_df):
    k = client.get(f"{API}/datasets/{ds['id']}/analytics/kpis", params={"date_from": "2026-01-01", "date_to": "2026-03-31"}, headers=auth_a).json()
    df = sample_df.assign(d=pd.to_datetime(sample_df["Order Date"]))
    cur = df[(df.d >= "2026-01-01") & (df.d <= "2026-03-31")]["Sales"].sum()
    prev = df[(df.d >= "2025-10-03") & (df.d <= "2025-12-31")]["Sales"].sum()  # equal-length (90 days) window before
    assert k["current"]["revenue"] == pytest.approx(cur)
    assert k["previous"]["revenue"] == pytest.approx(prev)
    assert k["change_pct"]["revenue"] == pytest.approx((cur - prev) / prev * 100)


def test_trend_and_breakdown_totals(client, auth_a, ds, sample_df):
    t = client.get(f"{API}/datasets/{ds['id']}/analytics/trend", params={"metric": "revenue", "granularity": "month"}, headers=auth_a).json()
    assert sum(p["value"] for p in t["points"]) == pytest.approx(sample_df["Sales"].sum())
    b = client.get(f"{API}/datasets/{ds['id']}/analytics/breakdown", params={"dimension": "region", "top": 50}, headers=auth_a).json()
    assert b["total"] == pytest.approx(sample_df["Sales"].sum())
    assert b["rows"][0]["name"] == sample_df.groupby("Region")["Sales"].sum().idxmax()


def test_invalid_inputs_rejected(client, auth_a, ds):
    base = f"{API}/datasets/{ds['id']}/analytics"
    assert client.get(f"{base}/kpis", params={"date_from": "01/02/2024"}, headers=auth_a).status_code == 422
    assert client.get(f"{base}/trend", params={"metric": "bogus"}, headers=auth_a).status_code == 422
    assert client.get(f"{base}/breakdown", params={"dimension": "nonexistent"}, headers=auth_a).status_code == 422


def test_root_cause_finds_west_decline(client, auth_a, ds):
    r = client.get(f"{API}/datasets/{ds['id']}/analytics/explain", params={"date_from": "2026-08-01", "date_to": "2026-09-30"}, headers=auth_a).json()
    regional = [d for d in r["top_drivers"] if d["dimension"] == "region"]
    assert any(d["name"] == "West" and d["change"] < 0 for d in regional)


# ---------------- preview / cleaning on messy data ----------------
@pytest.fixture(scope="module")
def messy(client, auth_a, tmp_path_factory):
    from scripts.generate_sample_data import generate
    p = tmp_path_factory.mktemp("m") / "messy.csv"
    generate(messy=True).to_csv(p, index=False)
    with open(p, "rb") as f:
        r = client.post(f"{API}/datasets", headers=auth_a, files={"file": ("messy.csv", f, "text/csv")})
    assert r.status_code == 201
    return r.json()


def test_messy_inference_and_quality(messy, ds):
    types = {c["name"]: c["type"] for c in messy["columns_detail"]}
    assert types["Sales"] in ("float", "integer")  # "$1,234.50" strings recovered as numeric
    assert messy["quality_score"] < ds["quality_score"]


def test_cleaning_workflow(client, auth_a, messy):
    i = messy["id"]
    dry = client.post(f"{API}/datasets/{i}/clean", headers=auth_a, json={"operation": "drop_duplicates", "dry_run": True}).json()
    assert dry["rows_after"] < dry["rows_before"]
    assert client.get(f"{API}/datasets/{i}", headers=auth_a).json()["rows"] == dry["rows_before"]  # dry run changes nothing
    done = client.post(f"{API}/datasets/{i}/clean", headers=auth_a, json={"operation": "drop_duplicates", "dry_run": False}).json()
    assert done["dataset"]["rows"] == dry["rows_after"]
    assert client.post(f"{API}/datasets/{i}/clean", headers=auth_a, json={"operation": "impute", "params": {"column": "Quantity", "strategy": "median"}, "dry_run": False}).status_code == 200
    assert client.post(f"{API}/datasets/{i}/clean", headers=auth_a, json={"operation": "rm_rf", "dry_run": False}).status_code == 422
    log = client.get(f"{API}/datasets/{i}/cleaning-log", headers=auth_a).json()
    assert [r["operation"] for r in log] == ["drop_duplicates", "impute"]


def test_preview_filter_sort(client, auth_a, ds):
    r = client.get(f"{API}/datasets/{ds['id']}/preview", params={"limit": 5, "sort": "Sales", "order": "desc", "filter": ["Region|eq|West"]}, headers=auth_a).json()
    assert len(r["rows"]) == 5 and all(row[r["columns"].index("Region")] == "West" for row in r["rows"])
    sales = [row[r["columns"].index("Sales")] for row in r["rows"]]
    assert sales == sorted(sales, reverse=True)
    assert client.get(f"{API}/datasets/{ds['id']}/preview", params={"filter": ["Bogus|eq|1"]}, headers=auth_a).status_code == 422


def test_role_change_validation(client, auth_a, ds):
    i = ds["id"]
    assert client.patch(f"{API}/datasets/{i}/columns/Region", headers=auth_a, json={"role": "revenue"}).status_code == 422  # text cannot be revenue
    assert client.patch(f"{API}/datasets/{i}/columns/Region", headers=auth_a, json={"role": "nonsense"}).status_code == 422
