import { useState } from "react";
import { NavLink, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { Bell, Bot, ChartLine, FileText, FlaskConical, LayoutDashboard, LogOut, Menu, Moon, Settings as Cog, Sparkles, Sun, Table2, X } from "lucide-react";
import { useAuth } from "./lib/auth";
import { useTheme } from "./lib/theme";
import { DatasetProvider, useDataset } from "./lib/dataset";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Datasets from "./pages/Datasets";
import Analytics from "./pages/Analytics";
import Predictions from "./pages/Predictions";
import Analyst from "./pages/Analyst";
import WhatIf from "./pages/WhatIf";
import Reports from "./pages/Reports";
import Alerts from "./pages/Alerts";
import Settings from "./pages/Settings";

const NAV = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard }, { to: "/datasets", label: "Datasets", icon: Table2 },
  { to: "/analytics", label: "Analytics", icon: ChartLine }, { to: "/predictions", label: "Predictions", icon: Sparkles },
  { to: "/analyst", label: "AI Analyst", icon: Bot }, { to: "/what-if", label: "What-if", icon: FlaskConical },
  { to: "/reports", label: "Reports", icon: FileText }, { to: "/alerts", label: "Alerts", icon: Bell }, { to: "/settings", label: "Settings", icon: Cog },
];

function DatasetSwitcher() {
  const { list, current, select } = useDataset();
  if (!list.length) return <span className="text-sm text-muted">No dataset</span>;
  return <label className="flex items-center gap-2 text-sm"><span className="text-muted">Dataset</span>
    <select className="input !w-auto max-w-[16rem] !py-1.5" value={current?.id} onChange={(e) => select(e.target.value)} aria-label="Active dataset">{list.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></label>;
}

function Shell() {
  const { user, logout } = useAuth(); const { theme, toggle } = useTheme(); const [open, setOpen] = useState(false); const loc = useLocation();
  const nav = (
    <nav className="flex flex-col gap-0.5 p-3" aria-label="Main">
      {NAV.map(({ to, label, icon: I }) => <NavLink key={to} to={to} end={to === "/"} onClick={() => setOpen(false)}
        className={({ isActive }) => `flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium ${isActive ? "bg-accent/10 text-accent" : "text-muted hover:bg-sunken hover:text-ink"}`}><I className="h-4 w-4" />{label}</NavLink>)}
    </nav>);
  return (
    <div className="flex h-full">
      <aside className="hidden w-56 shrink-0 flex-col border-r border-line bg-surface md:flex">
        <div className="flex h-14 items-center gap-2 border-b border-line px-5"><span className="grid h-7 w-7 place-items-center rounded-md bg-accent text-sm font-bold text-white">X</span><span className="font-semibold tracking-tight">InsightX AI</span></div>
        {nav}
      </aside>
      {open && <div className="fixed inset-0 z-40 md:hidden"><div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} /><aside className="absolute left-0 top-0 h-full w-60 bg-surface shadow-xl"><div className="flex h-14 items-center justify-between border-b border-line px-4"><span className="font-semibold">InsightX AI</span><button aria-label="Close menu" onClick={() => setOpen(false)}><X className="h-5 w-5" /></button></div>{nav}</aside></div>}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center justify-between gap-3 border-b border-line bg-surface px-4">
          <div className="flex items-center gap-3"><button className="md:hidden" aria-label="Open menu" onClick={() => setOpen(true)}><Menu className="h-5 w-5" /></button><DatasetSwitcher /></div>
          <div className="flex items-center gap-2"><span className="hidden text-sm text-muted sm:inline">{user?.display_name}</span>
            <button className="btn-ghost !p-2" onClick={toggle} aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}>{theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}</button>
            <button className="btn-ghost !p-2" onClick={logout} aria-label="Sign out"><LogOut className="h-4 w-4" /></button></div>
        </header>
        <main className="min-h-0 flex-1 overflow-y-auto p-4 md:p-6" key={loc.pathname}><div className="mx-auto max-w-[1280px]">
          <Routes>
            <Route path="/" element={<Dashboard />} /><Route path="/datasets" element={<Datasets />} /><Route path="/analytics" element={<Analytics />} />
            <Route path="/predictions" element={<Predictions />} /><Route path="/analyst" element={<Analyst />} /><Route path="/what-if" element={<WhatIf />} />
            <Route path="/reports" element={<Reports />} /><Route path="/alerts" element={<Alerts />} /><Route path="/settings" element={<Settings />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes></div></main>
      </div>
    </div>);
}

export default function App() {
  const { user, loading } = useAuth();
  if (loading) return <div className="grid h-full place-items-center text-sm text-muted">Loading…</div>;
  if (!user) return <Login />;
  return <DatasetProvider><Shell /></DatasetProvider>;
}
