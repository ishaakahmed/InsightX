import shutil
from typing import Literal

import pandas as pd
from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.db import get_db
from app.deps import current_user, owned_dataset
from app.models import CleaningOperation, Dataset, User
from app.services import analytics as A
from app.services import datasets as svc
from app.services import ingestion as I
from app.services.util import jsonable

router = APIRouter(prefix="/datasets", tags=["datasets"])
ROLES = svc.SINGLETON_ROLES | {"other"}


def _summary(ds: Dataset) -> dict:
    return {"id": ds.id, "name": ds.name, "original_filename": ds.original_filename, "rows": ds.row_count, "columns": ds.column_count,
            "status": ds.status, "quality_score": ds.quality_score, "created_at": ds.created_at.isoformat(), "size_bytes": ds.size_bytes}


def _detail(ds: Dataset) -> dict:
    return {**_summary(ds), "capabilities": ds.capabilities, "date_range": A.date_range(ds) if ds.capabilities.get("trends", {}).get("available") else None,
            "columns_detail": [{"name": c.name, "type": c.inferred_type, "role": c.semantic_role, "role_confirmed": c.role_confirmed, "stats": c.stats} for c in ds.columns]}


@router.post("", status_code=201)
async def upload(file: UploadFile = File(...), name: str = Form(""), user: User = Depends(current_user), db: Session = Depends(get_db)):
    s = get_settings()
    head = await file.read(8192)
    await file.seek(0)
    try:
        ext = I.validate_upload(file.filename or "", head, 1)  # extension + magic bytes first
    except I.IngestError as e:
        raise HTTPException(400, str(e))
    ds_id = svc.new_id()
    folder = svc.dataset_dir(user.id, ds_id)
    folder.mkdir(parents=True, exist_ok=True)
    raw = folder / f"raw.{ext}"  # generated name; the client filename is never used as a path
    size, limit = 0, s.max_upload_mb * 1024 * 1024
    try:
        with raw.open("wb") as out:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > limit:
                    raise I.IngestError(f"File exceeds the {s.max_upload_mb} MB limit.")
                out.write(chunk)
        I.validate_upload(file.filename or "", head, size)
        label = (name.strip() or (file.filename or "dataset").rsplit(".", 1)[0])[:200]
        ds = svc.create_dataset(db, user, label, file.filename or "upload", ext, raw, size, ds_id)
    except I.IngestError as e:
        shutil.rmtree(folder, ignore_errors=True)
        raise HTTPException(400, str(e))
    except Exception:
        shutil.rmtree(folder, ignore_errors=True)
        db.rollback()
        raise HTTPException(400, "The file could not be processed. Check that it is a valid CSV or Excel file with a header row.")
    return _detail(ds)


@router.get("")
def list_datasets(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(Dataset).filter(Dataset.user_id == user.id).order_by(Dataset.created_at.desc()).all()
    return [_summary(d) for d in rows]


@router.get("/{dataset_id}")
def get_dataset(ds: Dataset = Depends(owned_dataset)):
    return _detail(ds)


@router.delete("/{dataset_id}", status_code=204)
def delete(ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    svc.delete_dataset(db, ds)


class RoleBody(BaseModel):
    role: str


@router.patch("/{dataset_id}/columns/{column}")
def set_role(column: str, body: RoleBody, ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    if body.role not in ROLES:
        raise HTTPException(422, f"Role must be one of {sorted(ROLES)}")
    col = next((c for c in ds.columns if c.name == column), None)
    if not col:
        raise HTTPException(404, "Column not found")
    if body.role in svc.NUMERIC_ROLES and col.inferred_type not in ("integer", "float"):
        raise HTTPException(422, f"'{column}' is not numeric, so it cannot be used as {body.role}.")
    if body.role == "date" and col.inferred_type != "datetime":
        raise HTTPException(422, f"'{column}' was not recognised as a date column.")
    if body.role in svc.SINGLETON_ROLES:
        for other in ds.columns:
            if other.semantic_role == body.role and other is not col:
                other.semantic_role, other.role_confirmed = "other", False
    col.semantic_role, col.role_confirmed = body.role, True
    db.commit()
    svc.reanalyze(db, ds, A.read_frame(ds))
    return _detail(ds)


@router.get("/{dataset_id}/profile")
def profile(ds: Dataset = Depends(owned_dataset)):
    return ds.profile


@router.get("/{dataset_id}/quality")
def quality(ds: Dataset = Depends(owned_dataset)):
    return {"score": ds.quality_score, "breakdown": ds.profile.get("quality_breakdown"), "issues": ds.profile.get("issues", [])}


@router.get("/{dataset_id}/preview")
def preview(offset: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200), sort: str | None = None, order: Literal["asc", "desc"] = "asc",
            filter: list[str] = Query(default=[]), ds: Dataset = Depends(owned_dataset)):
    """Filters use 'column|op|value' with op in eq, ne, contains, gt, gte, lt, lte, isnull, notnull."""
    df = A.read_frame(ds)
    for f in filter:
        parts = f.split("|", 2)
        if len(parts) < 2 or parts[0] not in df.columns:
            raise HTTPException(422, f"Invalid filter '{f}'")
        col, op, val = parts[0], parts[1], parts[2] if len(parts) > 2 else ""
        s = df[col]
        try:
            if op == "isnull": m = s.isna()
            elif op == "notnull": m = s.notna()
            elif op == "contains": m = s.astype("string").str.contains(val, case=False, na=False, regex=False)
            elif op in ("eq", "ne", "gt", "gte", "lt", "lte"):
                v = pd.to_datetime(val) if pd.api.types.is_datetime64_any_dtype(s) else (float(val) if pd.api.types.is_numeric_dtype(s) else val)
                m = {"eq": s == v, "ne": s != v, "gt": s > v, "gte": s >= v, "lt": s < v, "lte": s <= v}[op]
            else:
                raise HTTPException(422, f"Unknown operator '{op}'")
        except (ValueError, TypeError):
            raise HTTPException(422, f"Invalid value for filter '{f}'")
        df = df[m]
    if sort:
        if sort not in df.columns:
            raise HTTPException(422, "Unknown sort column")
        df = df.sort_values(sort, ascending=order == "asc", na_position="last")
    total = len(df)
    page = df.iloc[offset:offset + limit]
    rows = [[jsonable(v) if not isinstance(v, str) else v for v in r] for r in page.astype(object).where(page.notna(), None).values.tolist()]
    return {"columns": list(df.columns), "rows": jsonable(rows), "total": total, "offset": offset, "limit": limit}


class CleanBody(BaseModel):
    operation: str
    params: dict = Field(default_factory=dict)
    dry_run: bool = True


@router.post("/{dataset_id}/clean")
def clean(body: CleanBody, ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    df = A.read_frame(ds)
    types = {c.name: c.inferred_type for c in ds.columns}
    try:
        out = I.apply_cleaning(df, body.operation, body.params, types)
    except I.IngestError as e:
        raise HTTPException(422, str(e))
    result = {"operation": body.operation, "rows_before": len(df), "rows_after": len(out), "cells_changed": int((out.fillna("§").astype(str).values != df.fillna("§").astype(str).values).sum()) if out.shape == df.shape else None,
              "dry_run": body.dry_run}
    if body.dry_run:
        return result
    seq = db.query(CleaningOperation).filter(CleaningOperation.dataset_id == ds.id).count() + 1
    out.to_parquet(ds.parquet_path, index=False)  # raw upload stays untouched on disk
    A._read_cached.cache_clear()
    db.add(CleaningOperation(dataset_id=ds.id, sequence=seq, operation=body.operation, params=body.params, rows_before=len(df), rows_after=len(out)))
    if body.operation == "drop_column":
        col = body.params["column"]
        ds.columns[:] = [c for c in ds.columns if c.name != col]
    db.commit()
    svc.reanalyze(db, ds, out)
    return {**result, "dataset": _detail(ds)}


@router.get("/{dataset_id}/cleaning-log")
def cleaning_log(ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    rows = db.query(CleaningOperation).filter(CleaningOperation.dataset_id == ds.id).order_by(CleaningOperation.sequence).all()
    return [{"sequence": r.sequence, "operation": r.operation, "params": r.params, "rows_before": r.rows_before, "rows_after": r.rows_after, "applied_at": r.applied_at.isoformat()} for r in rows]


class CompareBody(BaseModel):
    other_id: str


@router.post("/{dataset_id}/compare")
def compare(body: CompareBody, ds: Dataset = Depends(owned_dataset), user: User = Depends(current_user), db: Session = Depends(get_db)):
    other = db.get(Dataset, body.other_id)
    if not other or other.user_id != user.id:
        raise HTTPException(404, "Dataset not found")
    a_cols, b_cols = {c.name: c for c in ds.columns}, {c.name: c for c in other.columns}
    shared = [n for n in a_cols if n in b_cols]
    rows = []
    for n in shared:
        sa, sb = a_cols[n].stats, b_cols[n].stats
        row = {"column": n, "type_a": a_cols[n].inferred_type, "type_b": b_cols[n].inferred_type}
        for k in ("mean", "null_pct", "unique_count"):
            row[f"{k}_a"], row[f"{k}_b"] = sa.get(k), sb.get(k)
        rows.append(row)
    return {"a": _summary(ds), "b": _summary(other), "only_in_a": [n for n in a_cols if n not in b_cols], "only_in_b": [n for n in b_cols if n not in a_cols],
            "shared": rows, "quality": {"a": ds.quality_score, "b": other.quality_score}}
