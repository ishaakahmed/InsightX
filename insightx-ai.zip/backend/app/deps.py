from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.core.security import decode_access_token
from app.db import get_db
from app.models import Dataset, User


def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    auth = request.headers.get("authorization", "")
    token = auth[7:] if auth.lower().startswith("bearer ") else ""
    uid = decode_access_token(token) if token else None
    user = db.get(User, uid) if uid else None
    if not user or not user.is_active:
        raise HTTPException(401, "Not authenticated")
    return user


def owned_dataset(dataset_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)) -> Dataset:
    """Single choke point for dataset authorization. Returns 404 (not 403) to avoid leaking existence."""
    ds = db.get(Dataset, dataset_id)
    if not ds or ds.user_id != user.id:
        raise HTTPException(404, "Dataset not found")
    return ds
