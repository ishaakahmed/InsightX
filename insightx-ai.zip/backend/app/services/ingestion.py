"""File validation, loading, type inference, semantic column mapping, profiling, quality scoring, cleaning."""
import csv
import io
import re
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from app.core.config import get_settings
from app.services.util import jsonable

ALLOWED_EXT = {".csv", ".xlsx"}


class IngestError(ValueError):
    pass


# ---------- validation & loading ----------
def validate_upload(filename: str, head: bytes, size: int) -> str:
    s = get_settings()
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXT:
        raise IngestError("Only .csv and .xlsx files are supported.")
    if size == 0:
        raise IngestError("The file is empty.")
    if size > s.max_upload_mb * 1024 * 1024:
        raise IngestError(f"File exceeds the {s.max_upload_mb} MB limit.")
    if ext == ".xlsx" and not head.startswith(b"PK\x03\x04"):
        raise IngestError("File content does not match the .xlsx format.")
    if ext == ".csv" and b"\x00" in head:
        raise IngestError("File content does not look like a text CSV.")
    return ext.lstrip(".")


def _read_csv(path: Path) -> pd.DataFrame:
    raw = path.read_bytes()
    text = None
    for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise IngestError("Could not decode the file text encoding.")
    try:
        dialect = csv.Sniffer().sniff(text[:20000], delimiters=",;\t|")
        sep = dialect.delimiter
    except csv.Error:
        sep = ","
    return pd.read_csv(io.StringIO(text), sep=sep, low_memory=False, skipinitialspace=True)


def load_raw(path: Path, file_type: str) -> pd.DataFrame:
    s = get_settings()
    try:
        if file_type == "csv":
            df = _read_csv(path)
        else:
            df = pd.read_excel(path, engine="openpyxl", sheet_name=0)
    except IngestError:
        raise
    except Exception as e:  # malformed file
        raise IngestError(f"The file could not be parsed: {type(e).__name__}") from e
    if df.shape[1] == 0 or df.shape[0] == 0:
        raise IngestError("No data rows were found in the file.")
    if df.shape[1] > s.max_columns:
        raise IngestError(f"Too many columns ({df.shape[1]}); the limit is {s.max_columns}.")
    if df.shape[0] > s.max_rows:
        raise IngestError(f"Too many rows ({df.shape[0]}); the limit is {s.max_rows}.")
    return df


# ---------- type inference ----------
_NUM_CLEAN = re.compile(r"[,\s$€£₹%]|(?<=\d)_(?=\d)")


def _try_numeric(s: pd.Series) -> tuple[pd.Series | None, float]:
    cleaned = s.astype(str).str.replace(_NUM_CLEAN, "", regex=True).replace({"": None, "nan": None, "None": None, "NaN": None})
    num = pd.to_numeric(cleaned, errors="coerce")
    nn = s.notna() & (s.astype(str).str.strip() != "")
    if nn.sum() == 0:
        return None, 0.0
    return num, float(num[nn].notna().mean())


def _try_datetime(s: pd.Series) -> tuple[pd.Series | None, float]:
    nn = s.notna()
    if nn.sum() == 0:
        return None, 0.0
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        parsed = pd.to_datetime(s, errors="coerce", dayfirst=False, format="mixed")
    return parsed, float(parsed[nn].notna().mean())


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.dropna(how="all").dropna(axis=1, how="all").copy()
    seen: dict[str, int] = {}
    names = []
    for i, c in enumerate(df.columns):
        n = re.sub(r"\s+", " ", str(c)).strip() or f"column_{i + 1}"
        if n in seen:
            seen[n] += 1
            n = f"{n}_{seen[n]}"
        else:
            seen[n] = 0
        names.append(n)
    df.columns = names
    return df


def infer_and_cast(df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, str], dict[str, float]]:
    """Return typed frame, per-column type label and a per-column conversion-consistency ratio."""
    df = df.copy()
    types: dict[str, str] = {}
    consistency: dict[str, float] = {}
    for c in df.columns:
        s = df[c]
        if pd.api.types.is_bool_dtype(s):
            types[c] = "boolean"; consistency[c] = 1.0
        elif pd.api.types.is_datetime64_any_dtype(s):
            types[c] = "datetime"; consistency[c] = 1.0
        elif pd.api.types.is_numeric_dtype(s):
            types[c] = "integer" if pd.api.types.is_integer_dtype(s) or (s.dropna() % 1 == 0).all() else "float"
            consistency[c] = 1.0
        else:
            s = s.astype("string").str.strip()
            df[c] = s
            num, nr = _try_numeric(s)
            if num is not None and nr >= 0.9:
                df[c] = num
                types[c] = "integer" if (num.dropna() % 1 == 0).all() else "float"
                consistency[c] = nr
                continue
            dt, dr = (None, 0.0)
            if num is None or nr < 0.5:  # skip date parsing for obviously numeric text
                dt, dr = _try_datetime(s)
            if dt is not None and dr >= 0.9:
                df[c] = dt
                types[c] = "datetime"
                consistency[c] = dr
                continue
            uniq = s.nunique(dropna=True)
            types[c] = "category" if (uniq <= 60 or uniq / max(len(s), 1) < 0.3) else "text"
            consistency[c] = 1.0
            df[c] = s.astype(object).where(s.notna(), None)
    return df, types, consistency


# ---------- semantic column roles ----------
def _norm(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", name.lower()).strip()


_ROLE_RULES: list[tuple[str, list[tuple[str, int]], set[str]]] = [
    ("date", [("order date", 10), ("invoice date", 9), ("transaction date", 9), ("sale date", 9), ("date", 6), ("day", 3), ("time", 2), ("month", 2)], {"datetime"}),
    ("profit", [("profit", 10), ("net income", 6), ("earnings", 5)], {"integer", "float"}),
    ("cost", [("cogs", 10), ("cost", 9), ("expense", 6), ("expenditure", 5)], {"integer", "float"}),
    ("revenue", [("revenue", 10), ("net sales", 10), ("sales", 8), ("turnover", 8), ("total amount", 8), ("amount", 6), ("total", 4), ("income", 4), ("gmv", 8)], {"integer", "float"}),
    ("quantity", [("quantity", 10), ("qty", 10), ("units", 8), ("unit sold", 8), ("items", 3)], {"integer", "float"}),
    ("price", [("unit price", 10), ("price", 8), ("rate", 3)], {"integer", "float"}),
    ("order_id", [("order id", 10), ("invoice no", 9), ("invoice", 7), ("transaction id", 9), ("order no", 8), ("order", 4)], {"integer", "float", "category", "text"}),
    ("customer_id", [("customer id", 10), ("customerid", 10), ("customer no", 9), ("customer", 8), ("client", 6), ("buyer", 6), ("cust", 5), ("account", 3)], {"integer", "float", "category", "text"}),
    ("product", [("product name", 10), ("product", 9), ("item", 6), ("sku", 6), ("description", 5), ("article", 4)], {"category", "text"}),
    ("region", [("region", 10), ("country", 8), ("state", 7), ("territory", 7), ("market", 6), ("city", 6), ("zone", 5), ("area", 4)], {"category", "text"}),
    ("category", [("category", 10), ("segment", 7), ("department", 7), ("channel", 6), ("type", 4), ("class", 4), ("brand", 4)], {"category", "text"}),
]


def infer_roles(df: pd.DataFrame, types: dict[str, str]) -> dict[str, str]:
    roles = {c: "other" for c in df.columns}
    taken_roles: set[str] = set()
    for role, keywords, allowed in _ROLE_RULES:
        best, best_score = None, 0
        for c in df.columns:
            if roles[c] != "other" or types[c] not in allowed:
                continue
            n = _norm(c)
            score = 0
            for kw, w in keywords:
                if kw == n:
                    score = max(score, w + 3)
                elif re.search(rf"\b{re.escape(kw)}\b", n) or (len(kw) > 4 and kw in n):
                    score = max(score, w)
            # a "customer name"/"product name" style column beats id-like column for product/region
            if role in {"revenue", "cost", "profit"} and re.search(r"\b(discount|tax|rate|pct|percent|margin|id|no)\b", n):
                score = 0
            if score > best_score:
                best, best_score = c, score
        if best and best_score >= 4:
            roles[best] = role
            taken_roles.add(role)
    return roles


# ---------- profiling & quality ----------
def _col_stats(s: pd.Series, t: str) -> dict:
    n = len(s)
    nulls = int(s.isna().sum())
    d: dict = {"null_count": nulls, "null_pct": round(nulls / n * 100, 2) if n else 0.0, "unique_count": int(s.nunique(dropna=True))}
    if t in ("integer", "float"):
        x = pd.to_numeric(s, errors="coerce").dropna()
        if len(x):
            q1, med, q3 = x.quantile([0.25, 0.5, 0.75])
            iqr = q3 - q1
            outliers = int(((x < q1 - 3 * iqr) | (x > q3 + 3 * iqr)).sum()) if iqr > 0 else 0
            counts, edges = np.histogram(x, bins=min(12, max(3, int(np.sqrt(len(x))))))
            d.update(min=x.min(), max=x.max(), mean=x.mean(), median=med, std=x.std() if len(x) > 1 else 0.0,
                     q1=q1, q3=q3, outliers=outliers, sum=x.sum(),
                     histogram={"counts": counts.tolist(), "edges": edges.tolist()})
    elif t == "datetime":
        x = s.dropna()
        if len(x):
            d.update(min=x.min().date().isoformat(), max=x.max().date().isoformat())
    else:
        vc = s.value_counts(dropna=True).head(8)
        d["top_values"] = [{"value": str(k), "count": int(v)} for k, v in vc.items()]
    return jsonable(d)


def profile_frame(df: pd.DataFrame, types: dict[str, str], consistency: dict[str, float]) -> tuple[dict, dict, float]:
    n = len(df)
    col_stats = {c: _col_stats(df[c], types[c]) for c in df.columns}
    dup = int(df.duplicated().sum())
    cells = df.size or 1
    missing_cells = int(df.isna().sum().sum())
    completeness = 1 - missing_cells / cells
    uniqueness = 1 - dup / max(n, 1)
    consistency_score = float(np.mean([consistency.get(c, 1.0) for c in df.columns]))
    num_cols = [c for c in df.columns if types[c] in ("integer", "float")]
    out_cells = sum(col_stats[c].get("outliers", 0) for c in num_cols)
    num_cells = max(sum(n - col_stats[c]["null_count"] for c in num_cols), 1)
    outlier_ratio = out_cells / num_cells
    constant = [c for c in df.columns if col_stats[c]["unique_count"] <= 1]
    structure = 1 - len(constant) / max(df.shape[1], 1)
    breakdown = {
        "completeness": round(completeness * 100, 1),
        "uniqueness": round(uniqueness * 100, 1),
        "consistency": round(consistency_score * 100, 1),
        "outliers": round(max(0.0, 1 - min(outlier_ratio * 10, 1)) * 100, 1),
        "structure": round(structure * 100, 1),
    }
    weights = {"completeness": 0.4, "uniqueness": 0.2, "consistency": 0.2, "outliers": 0.1, "structure": 0.1}
    score = round(sum(breakdown[k] * w for k, w in weights.items()), 1)
    issues = []
    for c in df.columns:
        if col_stats[c]["null_pct"] >= 5:
            issues.append({"type": "missing_values", "column": c, "detail": f"{col_stats[c]['null_pct']}% missing"})
    if dup:
        issues.append({"type": "duplicates", "detail": f"{dup} duplicate rows ({dup / max(n, 1) * 100:.1f}%)"})
    for c in constant:
        issues.append({"type": "constant_column", "column": c, "detail": "Column has a single value"})
    for c in num_cols:
        if col_stats[c].get("outliers", 0):
            issues.append({"type": "outliers", "column": c, "detail": f"{col_stats[c]['outliers']} extreme values"})
    for c in df.columns:
        if consistency.get(c, 1.0) < 0.999:
            issues.append({"type": "mixed_types", "column": c, "detail": f"{(1 - consistency[c]) * 100:.1f}% of values did not match the detected type"})
    profile = {
        "rows": n, "columns": df.shape[1], "duplicate_rows": dup, "missing_cells": missing_cells,
        "columns_detail": col_stats, "quality_breakdown": breakdown, "issues": issues,
    }
    return jsonable(profile), jsonable(breakdown), score


def compute_capabilities(df: pd.DataFrame, roles: dict[str, str]) -> dict:
    by_role = {r: c for c, r in roles.items() if r != "other"}
    has = lambda *rs: all(r in by_role for r in rs)
    revenue = has("revenue") or has("price", "quantity")
    profit = has("profit") or (revenue and has("cost"))
    caps: dict = {}
    reason = lambda ok, msg: {"available": bool(ok), "reason": "" if ok else msg}
    caps["kpis"] = reason(revenue or has("quantity"), "Map a revenue (or price and quantity) column.")
    caps["trends"] = reason(has("date") and (revenue or has("quantity")), "Needs a date column and a revenue or quantity column.")
    caps["profit"] = reason(profit, "Needs a profit column, or revenue and cost columns.")
    caps["breakdowns"] = reason(revenue or has("quantity"), "Needs a revenue or quantity column.")
    span_ok, span_msg = False, "Needs a date column and a revenue or quantity column."
    if has("date") and (revenue or has("quantity")):
        d = pd.to_datetime(df[by_role["date"]], errors="coerce").dropna()
        months = (d.max().year - d.min().year) * 12 + d.max().month - d.min().month + 1 if len(d) else 0
        weeks = (d.max() - d.min()).days / 7 if len(d) else 0
        span_ok = months >= 12 or weeks >= 26
        span_msg = f"Needs at least 12 months or 26 weeks of history; found {months} months."
    caps["forecast"] = reason(span_ok, span_msg)
    caps["anomalies"] = reason(span_ok or caps["trends"]["available"], "Needs a date column and a revenue or quantity column.")
    caps["customers"] = reason(has("customer_id") and (revenue or has("quantity")), "Needs a customer column and a revenue or quantity column.")
    caps["segmentation"] = reason(has("customer_id", "date") and revenue, "Needs customer, date and revenue columns.")
    caps["simulation"] = reason(revenue, "Needs a revenue (or price and quantity) column.")
    caps["churn"] = {"available": False, "reason": "Churn prediction is not implemented yet."}
    return caps


# ---------- cleaning ----------
CLEAN_OPS = {"drop_duplicates", "drop_missing_rows", "impute", "trim_text", "drop_column"}


def apply_cleaning(df: pd.DataFrame, op: str, params: dict, types: dict[str, str]) -> pd.DataFrame:
    if op not in CLEAN_OPS:
        raise IngestError(f"Unknown cleaning operation '{op}'.")
    df = df.copy()
    cols = params.get("columns") or []
    for c in cols + ([params["column"]] if params.get("column") else []):
        if c not in df.columns:
            raise IngestError(f"Column '{c}' does not exist.")
    if op == "drop_duplicates":
        return df.drop_duplicates().reset_index(drop=True)
    if op == "drop_missing_rows":
        return df.dropna(subset=cols or None).reset_index(drop=True)
    if op == "trim_text":
        for c in cols or [c for c in df.columns if types.get(c) in ("category", "text")]:
            df[c] = df[c].map(lambda v: re.sub(r"\s+", " ", v).strip() if isinstance(v, str) else v)
        return df
    if op == "drop_column":
        return df.drop(columns=[params["column"]])
    if op == "impute":
        c, strat = params.get("column"), params.get("strategy", "median")
        if not c:
            raise IngestError("impute requires a column.")
        s = df[c]
        if strat in ("mean", "median"):
            if types.get(c) not in ("integer", "float"):
                raise IngestError(f"'{strat}' only applies to numeric columns.")
            df[c] = s.fillna(s.mean() if strat == "mean" else s.median())
        elif strat == "mode":
            m = s.mode(dropna=True)
            if len(m):
                df[c] = s.fillna(m.iloc[0])
        elif strat == "constant":
            if "value" not in params:
                raise IngestError("constant imputation requires a value.")
            v = params["value"]
            if types.get(c) in ("integer", "float"):
                v = float(v)
            df[c] = s.fillna(v)
        else:
            raise IngestError("Unknown imputation strategy.")
        return df
    return df
