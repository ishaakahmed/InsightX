export const num = (v: number | null | undefined, d = 0) => (v === null || v === undefined || Number.isNaN(v) ? "—" : v.toLocaleString("en-IN", { maximumFractionDigits: d, minimumFractionDigits: d }));
export const compact = (v: number | null | undefined) => {
  if (v === null || v === undefined) return "—";
  const a = Math.abs(v);
  if (a >= 1e7) return (v / 1e7).toFixed(2) + " Cr";
  if (a >= 1e5) return (v / 1e5).toFixed(2) + " L";
  if (a >= 1e3) return (v / 1e3).toFixed(1) + "K";
  return v.toFixed(0);
};
export const pct = (v: number | null | undefined, d = 1, sign = false) => (v === null || v === undefined ? "—" : `${sign && v > 0 ? "+" : ""}${v.toFixed(d)}%`);
export const ymd = (d: Date) => d.toISOString().slice(0, 10);
