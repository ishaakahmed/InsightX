from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.db import get_db
from app.deps import owned_dataset
from app.models import Alert, Dataset, MLModel, Simulation
from app.services import alerts as alert_svc
from app.services import analytics as A
from app.services import forecasting as F
from app.services import simulation as S

router = APIRouter(prefix="/datasets/{dataset_id}", tags=["analysis"])


def _guard(ds: Dataset, cap: str):
    c = ds.capabilities.get(cap, {})
    if not c.get("available"):
        raise HTTPException(422, c.get("reason") or f"'{cap}' is not available for this dataset.")


def _valid_date(v: str | None) -> str | None:
    if v is None:
        return None
    try:
        date.fromisoformat(v)
    except ValueError:
        raise HTTPException(422, "Dates must use YYYY-MM-DD.")
    return v


def _run(fn, *a, **k):
    try:
        return fn(*a, **k)
    except A.AnalyticsError as e:
        raise HTTPException(422, str(e))


@router.get("/analytics/kpis")
def kpis(date_from: str | None = None, date_to: str | None = None, ds: Dataset = Depends(owned_dataset)):
    _guard(ds, "kpis")
    return _run(A.kpis, ds, _valid_date(date_from), _valid_date(date_to))


@router.get("/analytics/trend")
def trend(metric: str = "revenue", granularity: str = "month", date_from: str | None = None, date_to: str | None = None, ds: Dataset = Depends(owned_dataset)):
    _guard(ds, "trends")
    return _run(A.trend, ds, metric, granularity, _valid_date(date_from), _valid_date(date_to))


@router.get("/analytics/breakdown")
def breakdown(dimension: str, metric: str = "revenue", top: int = Query(10, ge=1, le=50), date_from: str | None = None, date_to: str | None = None, ds: Dataset = Depends(owned_dataset)):
    _guard(ds, "breakdowns")
    return _run(A.breakdown, ds, dimension, metric, top, _valid_date(date_from), _valid_date(date_to))


@router.get("/analytics/correlation")
def correlation(ds: Dataset = Depends(owned_dataset)):
    return _run(A.correlation, ds)


@router.get("/analytics/customers")
def customers(ds: Dataset = Depends(owned_dataset)):
    _guard(ds, "customers")
    return _run(A.customers, ds)


@router.get("/analytics/explain")
def explain(metric: str = "revenue", date_from: str | None = None, date_to: str | None = None, ds: Dataset = Depends(owned_dataset)):
    _guard(ds, "kpis")
    return _run(A.root_cause, ds, _valid_date(date_from), _valid_date(date_to), metric)


@router.get("/analytics/date-range")
def date_range(ds: Dataset = Depends(owned_dataset)):
    return A.date_range(ds)


def _store(db: Session, ds: Dataset, task: str, algorithm: str, target: str, metrics: dict, result: dict, config: dict):
    m = MLModel(dataset_id=ds.id, task=task, algorithm=algorithm, target=target, metrics=metrics, result=result, config=config)
    db.add(m)
    db.commit()
    return m


class ForecastBody(BaseModel):
    metric: str = "revenue"
    horizon: int = Field(6, ge=1, le=24)
    granularity: str = "month"


@router.post("/ml/forecast")
def forecast(body: ForecastBody, ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    _guard(ds, "forecast")
    r = _run(F.forecast, ds, body.metric, body.horizon, body.granularity)
    m = _store(db, ds, "forecast", r["model"], body.metric, r["metrics"], r, body.model_dump())
    return {"model_id": m.id, **r}


@router.get("/ml/forecast/latest")
def latest_forecast(ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    m = db.query(MLModel).filter(MLModel.dataset_id == ds.id, MLModel.task == "forecast").order_by(MLModel.created_at.desc()).first()
    if not m:
        raise HTTPException(404, "No forecast has been run for this dataset yet.")
    return {"model_id": m.id, "created_at": m.created_at.isoformat(), **m.result}


@router.get("/ml/anomalies")
def anomalies(metric: str = "revenue", granularity: str = "day", ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    _guard(ds, "anomalies")
    if granularity not in ("day", "week", "month"):
        raise HTTPException(422, "granularity must be day, week or month")
    r = _run(F.anomalies, ds, metric, granularity)
    _store(db, ds, "anomaly", "stl_mad", metric, {"count": r["anomaly_count"]}, {k: v for k, v in r.items() if k != "series"}, {"granularity": granularity})
    return r


@router.post("/ml/segmentation")
def segmentation(ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    _guard(ds, "segmentation")
    r = _run(A.segmentation, ds)
    _store(db, ds, "segmentation", "rfm_kmeans", "customer", {"silhouette": r["silhouette"], "k": r["k"]}, r, {})
    return r


@router.get("/ml/models")
def models(ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    rows = db.query(MLModel).filter(MLModel.dataset_id == ds.id).order_by(MLModel.created_at.desc()).limit(30).all()
    return [{"id": m.id, "task": m.task, "algorithm": m.algorithm, "target": m.target, "metrics": m.metrics, "created_at": m.created_at.isoformat()} for m in rows]


class SimBody(BaseModel):
    name: str = Field("Scenario", max_length=120)
    price_change_pct: float = Field(0, ge=-90, le=500)
    volume_change_pct: float = Field(0, ge=-90, le=500)
    unit_cost_change_pct: float = Field(0, ge=-90, le=500)
    fixed_cost_change: float = 0
    price_elasticity: float = Field(0, ge=-10, le=5)
    date_from: str | None = None
    date_to: str | None = None
    save: bool = False


@router.post("/simulate")
def simulate(body: SimBody, ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    _guard(ds, "simulation")
    a = body.model_dump(exclude={"name", "date_from", "date_to", "save"})
    r = _run(S.simulate, ds, a, _valid_date(body.date_from), _valid_date(body.date_to))
    if body.save:
        db.add(Simulation(dataset_id=ds.id, name=body.name, assumptions=a, outcome={k: r[k] for k in ("baseline", "scenario", "delta")}))
        db.commit()
    return r


@router.get("/simulations")
def simulations(ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    rows = db.query(Simulation).filter(Simulation.dataset_id == ds.id).order_by(Simulation.created_at.desc()).limit(30).all()
    return [{"id": s.id, "name": s.name, "assumptions": s.assumptions, "outcome": s.outcome, "created_at": s.created_at.isoformat()} for s in rows]


@router.get("/alerts")
def alerts(status: str = "open", ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    q = db.query(Alert).filter(Alert.dataset_id == ds.id)
    if status != "all":
        q = q.filter(Alert.status == status)
    return [{"id": a.id, "rule_type": a.rule_type, "severity": a.severity, "message": a.message, "evidence": a.evidence, "status": a.status, "created_at": a.created_at.isoformat()} for a in q.order_by(Alert.created_at.desc()).all()]


@router.post("/alerts/refresh")
def refresh_alerts(ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    return {"count": len(alert_svc.generate_alerts(db, ds))}


class AlertPatch(BaseModel):
    status: str = Field(pattern="^(open|acknowledged|resolved)$")


@router.patch("/alerts/{alert_id}")
def patch_alert(alert_id: str, body: AlertPatch, ds: Dataset = Depends(owned_dataset), db: Session = Depends(get_db)):
    a = db.get(Alert, alert_id)
    if not a or a.dataset_id != ds.id:
        raise HTTPException(404, "Alert not found")
    a.status = body.status
    db.commit()
    return {"id": a.id, "status": a.status}
